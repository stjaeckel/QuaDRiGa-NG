clear all
close all
clc


CarrierFreq_Hz = 5.0e9; % Hz
tap_spacing_s = 10e-9;
observation_time = 1; %seconds
update_rate = 0.01; % seconds
speed_station_kmh = 1.2; % km/h
speed_env_kmh = 0.089; % TGac default
n_floors = 0;
uplink = 0;
n_subpath = 20;
Doppler_effect = 0; 
seed = 100; 

spacing = 0.50; % lambda
ntx = 8;
nrx = 8;

ap_array = quadriga_lib.arrayant_generate('ula', 30, CarrierFreq_Hz, [], [], [], 1, ntx, [], [], spacing);
sta_array = quadriga_lib.arrayant_generate('ula', 30, CarrierFreq_Hz, [], [], [], 1, nrx, [], [], spacing);

ap_pos = [ 15, 1 ; 25, 1 ];

x = 1:2:39;
y = 3:2:9;
sta_pos = [repmat(x,1,numel(y))', reshape(repmat(y,numel(x),1),[],1)];

m=1;
for n = 1:size(sta_pos,1)
    R = sta_pos(n,:) - ap_pos(m,:) ;
    Dist_m = norm(R);
    offset_angle_AP = atan2(R(2),R(1)) * 180/pi - 90;
    offset_angle_STA = 0;
    offset_angles = [offset_angle_AP,offset_angle_AP,0,0]';

    ch = quadriga_lib.get_channels_ieee_indoor(ap_array, sta_array, 'B', CarrierFreq_Hz, ...
        tap_spacing_s, 1, observation_time, update_rate, speed_station_kmh, speed_env_kmh, ...
        Dist_m, n_floors, uplink, offset_angles, n_subpath, Doppler_effect, seed);

end








