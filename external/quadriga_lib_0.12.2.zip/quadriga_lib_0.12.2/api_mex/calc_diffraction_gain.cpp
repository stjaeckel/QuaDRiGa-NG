// SPDX-License-Identifier: Apache-2.0
// Copyright (C) 2022-2026 Stephan Jaeckel (http://quadriga-lib.org)
// Part of quadriga-lib — see LICENSE for terms.

#include "mex.h"
#include "quadriga_tools.hpp"
#include "mex_helper_functions.hpp"

/*!SECTION
Site-specific simulation tools
SECTION!*/

/*!MD
# CALC_DIFFRACTION_GAIN
Calculate diffraction gain for multiple TX-RX pairs using a 3D triangular mesh

- Estimates diffraction gain by evaluating Fresnel ellipsoid obstruction; each TX-RX path is divided
  into `n_path` elliptic-arc paths (controlled by `lod`), each approximated by `n_seg` line segments
- Segment attenuation is combined via weighted summation calibrated to 2D UTD coefficients,
  generalized to arbitrary 3D shapes
- Optional sub-mesh indexing (see [[triangle_mesh_segmentation]]) accelerates computation by skipping
  triangles whose bounding box does not intersect the TX-RX path
- For a detailed description of the material model see <a href="http://quadriga-lib.org/formats.html">Data Formats</a>

## Usage:
```
[ gain, xprmat, coord ] = quadriga_lib.calc_diffraction_gain( orig, dest, mesh, mtl_ind, mtl_prop, ...
    center_freq, lod, verbose, sub_mesh_index, use_kernel, gpu_id, scalar_mode, thin_slab_threshold, ...
    apply_fspl, apply_phase );
```

## Inputs:
- **`orig`** — TX positions; `[n_pos, 3]`
- **`dest`** — RX positions; `[n_pos, 3]`
- **`mesh`** — Triangle vertices, each row `{X1,Y1,Z1,X2,Y2,Z2,X3,Y3,Z3}`; `[n_mesh, 9]`
- **`mtl_ind`** — 1-based material index per face (0 = no material; the `csv_ind` output of [[obj_file_read]]); `[n_mesh]`
- **`mtl_prop`** — Material properties as a struct; each field is one column (the `csv_prop` output of
  [[obj_file_read]]); each field holds a vector of length `n_mtl`
- **`center_freq`** — Center frequency in Hz. In scalar mode this is the true acoustic frequency;
  it is converted internally to the EM-equivalent frequency used by the core
- **`lod`** — Level of detail (0–6), controls `n_path` and `n_seg`; see [[generate_diffraction_paths]]; default: 2
- **`verbose`** — Verbosity level; default: 0 (no output)
- **`sub_mesh_index`** — 1-based sub-mesh index for acceleration; see [[triangle_mesh_segmentation]];  `[n_mesh, 1]`;
  default: `[]` (not using sub-meshes)
- **`use_kernel`** — Kernel selection: 0 = auto, 1 = GENERIC, 2 = AVX2, 3 = CUDA; error if unavailable; default: 0
- **`gpu_id`** — CUDA device ID; ignored for non-CUDA kernels; default: 0
- **`scalar_mode`** — If `true`, uses scalar transmission (TE-only reflection coefficient,
  energy-conservation transmission) instead of EM TE/TM averaging. Default `false` (EM mode).
- **`thin_slab_threshold`** — Thin-slab (Fabry-Pérot) resolve threshold; 0 = resolve always (default), 
  1 = resolve never, see [[ray_state_update]]
- **`apply_fspl`** — If `true`, folds the geometric spreading loss into `gain`, making it an absolute
  propagation gain instead of a value relative to FSPL. The reference distance is the direct TX-RX
  distance, matching the `path_length` used by [[qrt_file_read]] for a
  transmission-only path. EM mode: `32.45 + 20*log10(f_GHz) + 20*log10(d_m)` dB; scalar mode:
  `20*log10(d_m) + alpha(f)*d_m` dB, with `alpha` from ISO 9613-1 at T = 20 °C, RH = 50 %, p = 1 atm; default: `false`
- **`apply_phase`** — If `true`, multiplies `xprmat` by the propagation phase `exp(-j*2*pi*d/lambda)`
  using the same direct TX-RX distance. The wavelength follows from `center_freq` and the medium wave
  speed (speed of light in EM mode, speed of sound in scalar mode). The term has unit magnitude, so
  `xprmat` stays normalized. This is the phase [[get_channels_spherical]] would otherwise add from
  `path_length`; default: `false`

## Outputs:
- **`gain`** — Diffraction gain per TX-RX pair, linear power scale; `[n_pos, 1]`. Relative to FSPL by
  default (bounded by 0 and 1), absolute propagation gain when `apply_fspl = true`
- **`xprmat`** — Normalized polarization transfer matrix: the amplitude carries no path gain (max column
  power is 1), only the relative polarization coupling and phase; `gain` holds the power. EM mode:
  interleaved complex, col-major `[ReVV ImVV ReHV ImHV ReVH ImVH ReHH ImHH]`; `[8, n_pos]`; scalar mode:
  scalar pressure coefficient `[Re Im]`; `[2, n_pos]`
- **`coord`** — Diffracted path coordinates excluding endpoints; `[3, n_seg-1, n_pos]`

## See also:
- [[generate_diffraction_paths]] (controls path/segment count via `lod`)
- [[triangle_mesh_segmentation]] (generates `sub_mesh_index`)
- [[obj_file_read]] (defines `mtl_prop` format)
- [[qrt_file_read]] (same path-loss model, used by `apply_fspl`)
- [[get_channels_spherical]] (applies the same propagation phase as `apply_phase`)
MD!*/

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    if (nrhs < 6 || nrhs > 15)
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Wrong number of input arguments.");

    if (nlhs > 3)
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Too many output arguments.");

    // Load inputs (cast to double if needed)
    const arma::mat orig = qd_mex_get_Mat<double>(prhs[0]);
    const arma::mat dest = qd_mex_get_Mat<double>(prhs[1]);
    const arma::mat mesh = qd_mex_get_Mat<double>(prhs[2]);
    const arma::uvec mtl_ind = qd_mex_get_Col<arma::uword>(prhs[3]);

    // Material properties: MATLAB struct -> std::unordered_map<std::string, std::vector<double>>
    auto mtl_prop = qd_mex_struct2map<double>(prhs[4]);

    double center_freq = qd_mex_get_scalar<double>(prhs[5], "center_frequency", 1.0e9);
    int lod = (nrhs < 7) ? 2 : qd_mex_get_scalar<int>(prhs[6], "lod", 2);
    int verbose = (nrhs < 8) ? 0 : qd_mex_get_scalar<int>(prhs[7], "verbose", 0);
    arma::u32_vec sub_mesh_index = (nrhs < 9) ? arma::u32_vec() : qd_mex_get_Col<unsigned>(prhs[8], true);

    if (!sub_mesh_index.empty() && arma::any(sub_mesh_index == 0))
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Entries in 'sub_mesh_index' cannot be 0 (1-based index).");
    else // Convert to 0-based
        sub_mesh_index -= 1;

    int use_kernel = (nrhs < 10) ? 0 : qd_mex_get_scalar<int>(prhs[9], "use_kernel", 0);
    int gpu_id = (nrhs < 11) ? 0 : qd_mex_get_scalar<int>(prhs[10], "gpu_id", 0);
    bool scalar_mode = (nrhs < 12) ? false : qd_mex_get_scalar<bool>(prhs[11], "scalar_mode", false);
    double thin_slab_threshold = (nrhs < 13) ? 0.0 : qd_mex_get_scalar<double>(prhs[12], "thin_slab_threshold", 0.0);
    bool apply_fspl = (nrhs < 14) ? false : qd_mex_get_scalar<bool>(prhs[13], "apply_fspl", false);
    bool apply_phase = (nrhs < 15) ? false : qd_mex_get_scalar<bool>(prhs[14], "apply_phase", false);

    // Scalar mode: the public API takes true acoustic Hz, the core works in EM-equivalent Hz
    // (c_light / f_eq == acoustic wavelength). Must match qd_atmospheric_absorption.hpp.
    const double center_freq_core = scalar_mode ? center_freq * (3.0e8 / 343.0) : center_freq;

    arma::uword n_pos = orig.n_rows;
    arma::uword n_seg = 0;
    if (lod == 1 || lod == 2)
        n_seg = 2;
    else if (lod == 3)
        n_seg = 3;
    else if (lod == 4)
        n_seg = 4;
    else if (lod == 5 || lod == 6)
        n_seg = 1;

    // Initialize output containers
    arma::vec gain;
    arma::mat xprmat;
    arma::cube coord;

    if (nlhs > 0)
        plhs[0] = qd_mex_init_output(&gain, n_pos);

    if (nlhs > 1)
        plhs[1] = qd_mex_init_output(&xprmat, (scalar_mode ? 2 : 8), n_pos);

    if (nlhs > 2)
        plhs[2] = qd_mex_init_output(&coord, 3, n_seg, n_pos);

    arma::vec *p_gain = gain.empty() ? nullptr : &gain;
    arma::mat *p_xprmat = xprmat.empty() ? nullptr : &xprmat;
    arma::cube *p_coord = coord.empty() ? nullptr : &coord;
    arma::u32_vec *p_sub_mesh_index = sub_mesh_index.empty() ? nullptr : &sub_mesh_index;

    CALL_QD(quadriga_lib::calc_diffraction_gain(orig, dest, mesh, mtl_ind, mtl_prop,
                                                center_freq_core, lod, p_gain, p_xprmat, p_coord, verbose,
                                                p_sub_mesh_index, use_kernel, gpu_id, scalar_mode,
                                                thin_slab_threshold, apply_fspl, apply_phase));
}