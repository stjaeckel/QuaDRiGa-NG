// SPDX-License-Identifier: Apache-2.0
// Copyright (C) 2022-2026 Stephan Jaeckel (http://quadriga-lib.org)
// Part of quadriga-lib — see LICENSE for terms.

#include <stdexcept>
#include <cstring>   // std::memcpy
#include <iomanip>   // std::setprecision
#include <algorithm> // std::replace
#include <iostream>

#include "quadriga_arrayant.hpp"

/*!SECTION
Channel generation functions
SECTION!*/

/*!MD
# get_channels_irs
Calculate MIMO channel coefficients for IRS-assisted communication

- Computes channel coefficients and delays from two path segments: TX → IRS and IRS → RX
- IRS is modeled as a passive array; phase shifts are defined via its coupling matrix; codebook entry selected by `i_irs`
- Polarization coupling is applied via the 8-row transfer matrices `M_1`, `M_2` (interleaved Re/Im for VV, VH, HV, HH components)
- Output paths `n_path_irs` are all combinations of segment 1 and segment 2 paths that exceed `threshold_dB`
- If `active_path` is provided, it overrides `threshold_dB` for path selection
- Optional `irs_array_2` provides a separate IRS antenna pattern for the RX-facing side (asymmetric IRS)
- Setting `center_frequency = 0.0` disables phase computation

## Declaration:
```
std::vector<bool> quadriga_lib::get_channels_irs(
    const quadriga_lib::arrayant<dtype> *tx_array,
    const quadriga_lib::arrayant<dtype> *rx_array,
    const quadriga_lib::arrayant<dtype> *irs_array,
    dtype Tx, dtype Ty, dtype Tz,
    dtype Tb, dtype Tt, dtype Th,
    dtype Rx, dtype Ry, dtype Rz,
    dtype Rb, dtype Rt, dtype Rh,
    dtype Ix, dtype Iy, dtype Iz,
    dtype Ib, dtype It, dtype Ih,
    const arma::Mat<dtype> *fbs_pos_1,
    const arma::Mat<dtype> *lbs_pos_1,
    const arma::Col<dtype> *path_gain_1,
    const arma::Col<dtype> *path_length_1,
    const arma::Mat<dtype> *M_1,
    const arma::Mat<dtype> *fbs_pos_2,
    const arma::Mat<dtype> *lbs_pos_2,
    const arma::Col<dtype> *path_gain_2,
    const arma::Col<dtype> *path_length_2,
    const arma::Mat<dtype> *M_2,
    arma::Cube<dtype> *coeff_re,
    arma::Cube<dtype> *coeff_im,
    arma::Cube<dtype> *delay,
    arma::uword i_irs = 0,
    dtype threshold_dB = -140.0,
    dtype center_frequency = 0.0,
    bool use_absolute_delays = false,
    arma::Cube<dtype> *aod = nullptr,
    arma::Cube<dtype> *eod = nullptr,
    arma::Cube<dtype> *aoa = nullptr,
    arma::Cube<dtype> *eoa = nullptr,
    const quadriga_lib::arrayant<dtype> *irs_array_2 = nullptr,
    const std::vector<bool> *active_path = nullptr);
```

## Inputs:
- **`tx_array`** — Transmit antenna array with `n_tx` elements; see [[arrayant]]
- **`rx_array`** — Receive antenna array with `n_rx` elements; see [[arrayant]]
- **`irs_array`** — IRS antenna array (TX-facing side) with `n_irs` elements; see [[arrayant]]
- **`Tx, Ty, Tz`** — Transmitter position in Cartesian coordinates
- **`Tb, Tt, Th`** — Transmitter orientation as Euler angles (bank, tilt, heading)
- **`Rx, Ry, Rz`** — Receiver position in Cartesian coordinates
- **`Rb, Rt, Rh`** — Receiver orientation as Euler angles (bank, tilt, heading)
- **`Ix, Iy, Iz`** — IRS position in Cartesian coordinates
- **`Ib, It, Ih`** — IRS orientation as Euler angles (bank, tilt, heading)
- **`fbs_pos_1`** — First-bounce scatterer positions for TX → IRS paths; `[3, n_path_1]`
- **`lbs_pos_1`** — Last-bounce scatterer positions for TX → IRS paths; `[3, n_path_1]`
- **`path_gain_1`** — Path gains in linear scale for TX → IRS paths; `[n_path_1]`
- **`path_length_1`** — Total path lengths from TX to IRS phase center; `[n_path_1]`
- **`M_1`** — Polarization transfer matrix for TX → IRS paths, interleaved (ReVV, ImVV, ReVH, ImVH, ReHV, ImHV, ReHH, ImHH); `[8, n_path_1]`
- **`fbs_pos_2`** — First-bounce scatterer positions for IRS → RX paths; `[3, n_path_2]`
- **`lbs_pos_2`** — Last-bounce scatterer positions for IRS → RX paths; `[3, n_path_2]`
- **`path_gain_2`** — Path gains in linear scale for IRS → RX paths; `[n_path_2]`
- **`path_length_2`** — Total path lengths from IRS to RX phase center; `[n_path_2]`
- **`M_2`** — Polarization transfer matrix for IRS → RX paths, interleaved (ReVV, ImVV, ReVH, ImVH, ReHV, ImHV, ReHH, ImHH); `[8, n_path_2]`
- **`i_irs`** *(optional)* — IRS codebook port index
- **`threshold_dB`** *(optional)* — Gain threshold in dB; path combinations below this are discarded
- **`center_frequency`** *(optional)* — Center frequency; set to `0` to skip phase computation
- **`use_absolute_delays`** *(optional)* — If `true`, delays include the LOS component
- **`irs_array_2`** *(optional)* — Second IRS antenna array for the RX-facing side; enables asymmetric IRS patterns; see [[arrayant]]
- **`active_path`** *(optional)* — Bitmask selecting active path pairs; overrides `threshold_dB`; `[n_path_1 * n_path_2]`

## Outputs:
- **`coeff_re`** — Real part of channel coefficients; `[n_rx, n_tx, n_path_irs]`
- **`coeff_im`** — Imaginary part of channel coefficients; `[n_rx, n_tx, n_path_irs]`
- **`delay`** — Propagation delays in seconds; `[n_rx, n_tx, n_path_irs]`
- **`aod`** *(optional)* — Azimuth of departure; `[n_rx, n_tx, n_path_irs]`
- **`eod`** *(optional)* — Elevation of departure; `[n_rx, n_tx, n_path_irs]`
- **`aoa`** *(optional)* — Azimuth of arrival; `[n_rx, n_tx, n_path_irs]`
- **`eoa`** *(optional)* — Elevation of arrival; `[n_rx, n_tx, n_path_irs]`

## Returns:
- Boolean mask of length `n_path_1 * n_path_2` indicating which path combinations were included in the output

## See also:
- [[combine_irs_coord]] (coordinate setup for IRS geometry)
- [[get_channels_spherical]] (single-segment spherical-wave channel)
- [[get_channels_planar]] (single-segment planar-wave channel)
- [[arrayant]] (antenna array class)
MD!*/

// Calculate channels for Intelligent Reflective Surfaces (IRS)
template <typename dtype>
std::vector<bool> quadriga_lib::get_channels_irs(const arrayant<dtype> *tx_array, const arrayant<dtype> *rx_array, const arrayant<dtype> *irs_array,
                                                 dtype Tx, dtype Ty, dtype Tz, dtype Tb, dtype Tt, dtype Th,
                                                 dtype Rx, dtype Ry, dtype Rz, dtype Rb, dtype Rt, dtype Rh,
                                                 dtype Ix, dtype Iy, dtype Iz, dtype Ib, dtype It, dtype Ih,
                                                 const arma::Mat<dtype> *fbs_pos_1, const arma::Mat<dtype> *lbs_pos_1,
                                                 const arma::Col<dtype> *path_gain_1, const arma::Col<dtype> *path_length_1, const arma::Mat<dtype> *M_1,
                                                 const arma::Mat<dtype> *fbs_pos_2, const arma::Mat<dtype> *lbs_pos_2,
                                                 const arma::Col<dtype> *path_gain_2, const arma::Col<dtype> *path_length_2, const arma::Mat<dtype> *M_2,
                                                 arma::Cube<dtype> *coeff_re, arma::Cube<dtype> *coeff_im, arma::Cube<dtype> *delay,
                                                 arma::uword i_irs, dtype threshold_dB, dtype center_frequency, bool use_absolute_delays,
                                                 arma::Cube<dtype> *aod, arma::Cube<dtype> *eod, arma::Cube<dtype> *aoa, arma::Cube<dtype> *eoa,
                                                 const arrayant<dtype> *irs_array_2, const std::vector<bool> *active_path)
{

    // Check if IRS array is valid
    if (irs_array == nullptr)
        throw std::invalid_argument("IRS array cannot be NULL");

    std::string error_message = irs_array->is_valid();
    if (error_message.length() != 0)
    {
        error_message = "IRS array: " + error_message;
        throw std::invalid_argument(error_message.c_str());
    }

    if (irs_array->coupling_re.n_cols == 0ULL)
        throw std::invalid_argument("IRS must have a Coupling matrix containing the IRS weights (phase shifts) for each element.");

    if (i_irs >= irs_array->coupling_re.n_cols)
        throw std::invalid_argument("IRS codebook index out of bound.");

    // Do we need to calculate the angles?
    bool calc_angles = aod != nullptr || eod != nullptr || aoa != nullptr || eoa != nullptr;

    // Construst IRS array with only the desired weight vector
    arma::uword n_azimuth_irs = irs_array->e_theta_re.n_cols;
    arma::uword n_elevation_irs = irs_array->e_theta_re.n_rows;
    arma::uword n_elements_irs = irs_array->e_theta_re.n_slices;

    quadriga_lib::arrayant<dtype> irs;
    irs.e_theta_re = arma::Cube<dtype>(const_cast<dtype *>(irs_array->e_theta_re.memptr()), n_elevation_irs, n_azimuth_irs, n_elements_irs, false, true);
    irs.e_theta_im = arma::Cube<dtype>(const_cast<dtype *>(irs_array->e_theta_im.memptr()), n_elevation_irs, n_azimuth_irs, n_elements_irs, false, true);
    irs.e_phi_re = arma::Cube<dtype>(const_cast<dtype *>(irs_array->e_phi_re.memptr()), n_elevation_irs, n_azimuth_irs, n_elements_irs, false, true);
    irs.e_phi_im = arma::Cube<dtype>(const_cast<dtype *>(irs_array->e_phi_im.memptr()), n_elevation_irs, n_azimuth_irs, n_elements_irs, false, true);
    irs.azimuth_grid = arma::Col<dtype>(const_cast<dtype *>(irs_array->azimuth_grid.memptr()), n_azimuth_irs, false, true);
    irs.elevation_grid = arma::Col<dtype>(const_cast<dtype *>(irs_array->elevation_grid.memptr()), n_elevation_irs, false, true);

    if (irs_array->element_pos.n_cols != n_elements_irs)
        irs.element_pos.zeros(3ULL, n_elements_irs);
    else
        irs.element_pos = arma::Mat<dtype>(const_cast<dtype *>(irs_array->element_pos.memptr()), 3ULL, n_elements_irs, false, true);

    irs.coupling_re = arma::Mat<dtype>(const_cast<dtype *>(irs_array->coupling_re.colptr(i_irs)), n_elements_irs, 1ULL, false, true);
    if (irs_array->coupling_im.n_rows != n_elements_irs)
        irs.coupling_im.zeros(n_elements_irs, 1ULL);
    else
        irs.coupling_im = arma::Mat<dtype>(const_cast<dtype *>(irs_array->coupling_im.colptr(i_irs)), n_elements_irs, 1ULL, false, true);

    if (center_frequency > dtype(1.0e-5))
        irs.center_frequency = center_frequency;
    irs.read_only = true;

    // Calculate the channel coefficients of the first segment from the TX to the IRS
    arma::Cube<dtype> coeff_re_1, coeff_im_1, delay_1, aod_1, eod_1;
    if (calc_angles)
    {
        quadriga_lib::get_channels_spherical<dtype>(tx_array, &irs, Tx, Ty, Tz, Tb, Tt, Th, Ix, Iy, Iz, Ib, It, Ih, fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1,
                                                    &coeff_re_1, &coeff_im_1, &delay_1, center_frequency, true, false, &aod_1, &eod_1);
    }
    else
    {
        quadriga_lib::get_channels_spherical<dtype>(tx_array, &irs, Tx, Ty, Tz, Tb, Tt, Th, Ix, Iy, Iz, Ib, It, Ih, fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1,
                                                    &coeff_re_1, &coeff_im_1, &delay_1, center_frequency, true, false);
    }

    // Update the IRS array for the second segment
    if (irs_array_2 != nullptr)
    {
        std::string error_message = irs_array_2->is_valid();
        if (error_message.length() != 0)
        {
            error_message = "IRS array 2: " + error_message;
            throw std::invalid_argument(error_message.c_str());
        }

        if (irs_array_2->e_theta_re.n_slices != n_elements_irs)
            throw std::invalid_argument("IRS 2 must have the same number of elements as IRS 1");

        if (irs_array_2->coupling_re.n_cols != irs_array->coupling_re.n_cols)
            throw std::invalid_argument("IRS 2 must have a Coupling matrix of the same size as of IRS 1.");

        n_azimuth_irs = irs_array_2->e_theta_re.n_cols;
        n_elevation_irs = irs_array_2->e_theta_re.n_rows;

        irs.e_theta_re = arma::Cube<dtype>(const_cast<dtype *>(irs_array_2->e_theta_re.memptr()), n_elevation_irs, n_azimuth_irs, n_elements_irs, false, true);
        irs.e_theta_im = arma::Cube<dtype>(const_cast<dtype *>(irs_array_2->e_theta_im.memptr()), n_elevation_irs, n_azimuth_irs, n_elements_irs, false, true);
        irs.e_phi_re = arma::Cube<dtype>(const_cast<dtype *>(irs_array_2->e_phi_re.memptr()), n_elevation_irs, n_azimuth_irs, n_elements_irs, false, true);
        irs.e_phi_im = arma::Cube<dtype>(const_cast<dtype *>(irs_array_2->e_phi_im.memptr()), n_elevation_irs, n_azimuth_irs, n_elements_irs, false, true);
        irs.azimuth_grid = arma::Col<dtype>(const_cast<dtype *>(irs_array_2->azimuth_grid.memptr()), n_azimuth_irs, false, true);
        irs.elevation_grid = arma::Col<dtype>(const_cast<dtype *>(irs_array_2->elevation_grid.memptr()), n_elevation_irs, false, true);

        if (irs_array_2->element_pos.n_cols != n_elements_irs)
            irs.element_pos.zeros(3ULL, n_elements_irs);
        else
            irs.element_pos = arma::Mat<dtype>(const_cast<dtype *>(irs_array_2->element_pos.memptr()), 3ULL, n_elements_irs, false, true);

        irs.coupling_re = arma::Mat<dtype>(const_cast<dtype *>(irs_array_2->coupling_re.colptr(i_irs)), n_elements_irs, 1ULL, false, true);
        if (irs_array_2->coupling_im.n_rows != n_elements_irs)
            irs.coupling_im.zeros(n_elements_irs, 1ULL);
        else
            irs.coupling_im = arma::Mat<dtype>(const_cast<dtype *>(irs_array_2->coupling_im.colptr(i_irs)), n_elements_irs, 1ULL, false, true);
    }

    // Calculate channel coefficients of the second segment from the IRS to the RX
    arma::Cube<dtype> coeff_re_2, coeff_im_2, delay_2, aoa_2, eoa_2;
    if (calc_angles)
    {
        quadriga_lib::get_channels_spherical<dtype>(&irs, rx_array, Ix, Iy, Iz, Ib, It, Ih, Rx, Ry, Rz, Rb, Rt, Rh, fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2,
                                                    &coeff_re_2, &coeff_im_2, &delay_2, center_frequency, true, false, nullptr, nullptr, &aoa_2, &eoa_2);
    }
    else
    {
        quadriga_lib::get_channels_spherical<dtype>(&irs, rx_array, Ix, Iy, Iz, Ib, It, Ih, Rx, Ry, Rz, Rb, Rt, Rh, fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2,
                                                    &coeff_re_2, &coeff_im_2, &delay_2, center_frequency, true, false);
    }

    // Calculate the LOS delay between TX and RX
    dtype los_delay = dtype(0.0);
    if (!use_absolute_delays)
    {
        dtype x = Rx - Tx, y = Ry - Ty, z = Rz - Tz;
        los_delay = std::sqrt(x * x + y * y + z * z);
        los_delay *= dtype(3.335640951981520e-09); // 1/C
    }

    // Combine the two channel segments
    arma::uword n_path_1 = coeff_re_1.n_slices;
    arma::uword n_path_2 = coeff_re_2.n_slices;
    arma::uword n_path = n_path_1 * n_path_2;
    arma::uword n_tx = coeff_re_1.n_cols;
    arma::uword n_rx = coeff_re_2.n_rows;

    arma::Cube<dtype> coeff_re_local(n_rx, n_tx, n_path, arma::fill::none);
    arma::Cube<dtype> coeff_im_local(n_rx, n_tx, n_path, arma::fill::none);
    arma::Cube<dtype> delay_local(n_rx, n_tx, n_path, arma::fill::none);

    arma::Cube<dtype> aod_local, eod_local, aoa_local, eoa_local;
    if (calc_angles)
    {
        aod_local.set_size(n_rx, n_tx, n_path);
        eod_local.set_size(n_rx, n_tx, n_path);
        aoa_local.set_size(n_rx, n_tx, n_path);
        eoa_local.set_size(n_rx, n_tx, n_path);
    }

    dtype threshold = (dtype)std::pow<double>(10.0, 0.1 * (double)threshold_dB);
    std::vector<bool> keep_path(n_path, false);

    // Do we have a path whichlist?
    bool use_threshold = active_path == nullptr;
    if (!use_threshold && active_path->size() != n_path)
        throw std::invalid_argument("Optional input 'active_path' does not have the correct number of elements.");

    arma::uword i_path = 0ULL, j_path = 0ULL;
    for (arma::uword i_path_1 = 0ULL; i_path_1 < n_path_1; ++i_path_1)
    {
        dtype *c1r = coeff_re_1.slice_memptr(i_path_1);
        dtype *c1i = coeff_im_1.slice_memptr(i_path_1);
        dtype *d1 = delay_1.slice_memptr(i_path_1);
        dtype *p_aod_1 = calc_angles ? aod_1.slice_memptr(i_path_1) : nullptr;
        dtype *p_eod_1 = calc_angles ? eod_1.slice_memptr(i_path_1) : nullptr;

        for (arma::uword i_path_2 = 0ULL; i_path_2 < n_path_2; ++i_path_2)
        {
            dtype *c2r = coeff_re_2.slice_memptr(i_path_2);
            dtype *c2i = coeff_im_2.slice_memptr(i_path_2);
            dtype *d2 = delay_2.slice_memptr(i_path_2);
            dtype *p_aoa_2 = calc_angles ? aoa_2.slice_memptr(i_path_2) : nullptr;
            dtype *p_eoa_2 = calc_angles ? eoa_2.slice_memptr(i_path_2) : nullptr;

            dtype *cr = coeff_re_local.slice_memptr(i_path);
            dtype *ci = coeff_im_local.slice_memptr(i_path);
            dtype *dl = delay_local.slice_memptr(i_path);
            dtype *p_aod = calc_angles ? aod_local.slice_memptr(i_path) : nullptr;
            dtype *p_eod = calc_angles ? eod_local.slice_memptr(i_path) : nullptr;
            dtype *p_aoa = calc_angles ? aoa_local.slice_memptr(i_path) : nullptr;
            dtype *p_eoa = calc_angles ? eoa_local.slice_memptr(i_path) : nullptr;

            dtype pow = dtype(0.0);
            for (arma::uword i_tx = 0ULL; i_tx < n_tx; ++i_tx)
            {
                dtype a = c1r[i_tx], b = c1i[i_tx], dd1 = d1[i_tx];
                for (arma::uword i_rx = 0ULL; i_rx < n_rx; ++i_rx)
                {
                    dtype c = c2r[i_rx], d = c2i[i_rx];
                    dtype re = a * c - b * d;
                    dtype im = a * d + b * c;

                    arma::uword i = i_tx * n_rx + i_rx;
                    cr[i] = re, ci[i] = im;
                    dl[i] = dd1 + d2[i_rx] - los_delay;

                    re = re * re + im * im;
                    pow = (re > pow) ? re : pow;

                    if (calc_angles)
                    {
                        p_aod[i] = p_aod_1[i_tx];
                        p_eod[i] = p_eod_1[i_tx];
                        p_aoa[i] = p_aoa_2[i_rx];
                        p_eoa[i] = p_eoa_2[i_rx];
                    }
                }
            }

            bool keep_this_path = use_threshold ? pow > threshold : active_path->at(j_path);
            i_path = keep_this_path ? i_path + 1ULL : i_path;
            keep_path[j_path] = keep_this_path;
            ++j_path;
        }
    }

    // Write to output
    coeff_re->set_size(n_rx, n_tx, i_path);
    coeff_im->set_size(n_rx, n_tx, i_path);
    delay->set_size(n_rx, n_tx, i_path);

    arma::uword n_bytes = n_rx * n_tx * i_path * sizeof(dtype);
    std::memcpy(coeff_re->memptr(), coeff_re_local.memptr(), n_bytes);
    std::memcpy(coeff_im->memptr(), coeff_im_local.memptr(), n_bytes);
    std::memcpy(delay->memptr(), delay_local.memptr(), n_bytes);

    if (aod != nullptr)
    {
        aod->set_size(n_rx, n_tx, i_path);
        std::memcpy(aod->memptr(), aod_local.memptr(), n_bytes);
    }

    if (eod != nullptr)
    {
        eod->set_size(n_rx, n_tx, i_path);
        std::memcpy(eod->memptr(), eod_local.memptr(), n_bytes);
    }

    if (aoa != nullptr)
    {
        aoa->set_size(n_rx, n_tx, i_path);
        std::memcpy(aoa->memptr(), aoa_local.memptr(), n_bytes);
    }

    if (eoa != nullptr)
    {
        eoa->set_size(n_rx, n_tx, i_path);
        std::memcpy(eoa->memptr(), eoa_local.memptr(), n_bytes);
    }

    return keep_path;
}

template std::vector<bool> quadriga_lib::get_channels_irs(const arrayant<float> *tx_array, const arrayant<float> *rx_array, const arrayant<float> *irs_array,
                                                          float Tx, float Ty, float Tz, float Tb, float Tt, float Th,
                                                          float Rx, float Ry, float Rz, float Rb, float Rt, float Rh,
                                                          float Ix, float Iy, float Iz, float Ib, float It, float Ih,
                                                          const arma::Mat<float> *fbs_pos_1, const arma::Mat<float> *lbs_pos_1,
                                                          const arma::Col<float> *path_gain_1, const arma::Col<float> *path_length_1, const arma::Mat<float> *M_1,
                                                          const arma::Mat<float> *fbs_pos_2, const arma::Mat<float> *lbs_pos_2,
                                                          const arma::Col<float> *path_gain_2, const arma::Col<float> *path_length_2, const arma::Mat<float> *M_2,
                                                          arma::Cube<float> *coeff_re, arma::Cube<float> *coeff_im, arma::Cube<float> *delay,
                                                          arma::uword i_irs, float threshold_dB, float center_frequency, bool use_absolute_delays,
                                                          arma::Cube<float> *aod, arma::Cube<float> *eod, arma::Cube<float> *aoa, arma::Cube<float> *eoa,
                                                          const arrayant<float> *irs_array_2, const std::vector<bool> *active_path);

template std::vector<bool> quadriga_lib::get_channels_irs(const arrayant<double> *tx_array, const arrayant<double> *rx_array, const arrayant<double> *irs_array,
                                                          double Tx, double Ty, double Tz, double Tb, double Tt, double Th,
                                                          double Rx, double Ry, double Rz, double Rb, double Rt, double Rh,
                                                          double Ix, double Iy, double Iz, double Ib, double It, double Ih,
                                                          const arma::Mat<double> *fbs_pos_1, const arma::Mat<double> *lbs_pos_1,
                                                          const arma::Col<double> *path_gain_1, const arma::Col<double> *path_length_1, const arma::Mat<double> *M_1,
                                                          const arma::Mat<double> *fbs_pos_2, const arma::Mat<double> *lbs_pos_2,
                                                          const arma::Col<double> *path_gain_2, const arma::Col<double> *path_length_2, const arma::Mat<double> *M_2,
                                                          arma::Cube<double> *coeff_re, arma::Cube<double> *coeff_im, arma::Cube<double> *delay,
                                                          arma::uword i_irs, double threshold_dB, double center_frequency, bool use_absolute_delays,
                                                          arma::Cube<double> *aod, arma::Cube<double> *eod, arma::Cube<double> *aoa, arma::Cube<double> *eoa,
                                                          const arrayant<double> *irs_array_2, const std::vector<bool> *active_path);