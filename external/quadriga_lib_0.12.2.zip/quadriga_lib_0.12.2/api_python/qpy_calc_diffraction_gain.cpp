// SPDX-License-Identifier: Apache-2.0
// Copyright (C) 2022-2026 Stephan Jaeckel (http://quadriga-lib.org)
// Part of quadriga-lib — see LICENSE for terms.

#include "python_arma_adapter.hpp"
#include "quadriga_lib.hpp"

/*!SECTION
Site-specific simulation tools
SECTION!*/

/*!MD
# calc_diffraction_gain
Calculate diffraction gain for multiple TX-RX pairs using a 3D triangular mesh

- Estimates diffraction gain by evaluating Fresnel ellipsoid obstruction; each TX-RX path is divided
  into `n_path` elliptic-arc paths (controlled by `lod`), each approximated by `n_seg` line segments
- Segment attenuation is combined via weighted summation calibrated to 2D UTD coefficients,
  generalized to arbitrary 3D shapes
- Optional sub-mesh indexing (see [[triangle_mesh_segmentation]]) accelerates computation by skipping
  triangles whose bounding box does not intersect the TX-RX path
- For a detailed description of the material model see
  <a href="http://quadriga-lib.org/formats.html">Data Formats</a> section

## Usage:
```
# Output as tuple
data = quadriga_lib.RTtools.calc_diffraction_gain( orig, dest, mesh, mtl_ind, mtl_prop, \
    center_frequency, lod, verbose, sub_mesh_index, use_kernel, gpu_id, scalar_mode, \
    thin_slab_threshold, apply_fspl, apply_phase )

# Unpacked outputs
gain, xprmat, coord = quadriga_lib.RTtools.calc_diffraction_gain( orig, dest, mesh, mtl_ind, mtl_prop, \
    center_frequency, lod, verbose, sub_mesh_index, use_kernel, gpu_id, scalar_mode, \
    thin_slab_threshold, apply_fspl, apply_phase )
```

## Inputs:
- **`orig`** — TX positions; `(n_pos, 3)`
- **`dest`** — RX positions; `(n_pos, 3)`
- **`mesh`** — Triangle vertices, each row `[X1,Y1,Z1,X2,Y2,Z2,X3,Y3,Z3]`; `(n_mesh, 9)`
- **`mtl_ind`** — 1-based material index per face (0 = no material; the `csv_ind` output of [[obj_file_read]]); `(n_mesh,)`
- **`mtl_prop`** — Material properties as a `dict`; each key is one column (the `csv_prop` output of [[obj_file_read]]) mapping to a 1D array of length `n_mtl`
- **`center_frequency`** — Center frequency
- **`lod`** — Level of detail (0–6), controls `n_path` and `n_seg`; see [[generate_diffraction_paths]]; default: 2
- **`verbose`** — Verbosity level; default: 0
- **`sub_mesh_index`** — 0-based sub-mesh index for acceleration; see [[triangle_mesh_segmentation]]; `(n_mesh,)` or `None`; default: `None`
- **`use_kernel`** — Kernel selection: 0 = auto, 1 = GENERIC, 2 = AVX2, 3 = CUDA; error if unavailable; default: 0
- **`gpu_id`** — CUDA device ID; ignored for non-CUDA kernels; default: 0
- **`scalar_mode`** — If `True`, uses scalar transmission (TE-only reflection coefficient,
  energy-conservation transmission) instead of EM TE/TM averaging; default: `False`
- **`thin_slab_threshold`** — Thin-slab (Fabry-Pérot) resolve threshold; 0 = resolve always, 1 = resolve
  never; see [[ray_state_update]]; default: 0
- **`apply_fspl`** — If `True`, folds the geometric spreading loss into `gain`, making it an absolute
  propagation gain instead of a value relative to FSPL. The reference distance is the direct TX-RX
  distance, matching the `path_length` used by [[qrt_file_read]] for a
  transmission-only path. EM mode: `32.45 + 20*log10(f_GHz) + 20*log10(d_m)` dB; scalar mode:
  `20*log10(d_m) + alpha(f)*d_m` dB, with `alpha` from ISO 9613-1 at T = 20 °C, RH = 50 %, p = 1 atm.;
  default: `False`
- **`apply_phase`** — If `True`, multiplies `xprmat` by the propagation phase `exp(-j*2*pi*d/lambda)`
  using the same direct TX-RX distance. The wavelength follows from `center_frequency` and the medium
  wave speed (speed of light in EM mode, speed of sound in scalar mode). The term has unit magnitude,
  so `xprmat` stays normalized. This is the phase [[get_channels_spherical]] would otherwise add from
  `path_length`; default: `False`

## Outputs:
- **`gain`** — Diffraction gain per TX-RX pair, linear power scale; `(n_pos,)`. Relative to FSPL by
  default (bounded by 0 and 1), absolute propagation gain when `apply_fspl = True`
- **`xprmat`** — Normalized polarization transfer matrix: the amplitude carries no path gain (max column
  power is 1), only the relative polarization coupling and phase; `gain` holds the power. EM mode:
  interleaved complex, column-major `[ReVV ImVV ReHV ImHV ReVH ImVH ReHH ImHH]`, `(8, n_pos)`; scalar
  mode: scalar pressure coefficient `[Re Im]`, `(2, n_pos)`
- **`coord`** — Diffracted path coordinates excluding endpoints; `(3, n_seg-1, n_pos)`

## See also:
- [[generate_diffraction_paths]] (controls path/segment count via `lod`)
- [[triangle_mesh_segmentation]] (generates `sub_mesh_index`)
- [[obj_file_read]] (defines the material format)
- [[qrt_file_read]] (same path-loss model, used by `apply_fspl`)
- [[get_channels_spherical]] (applies the same propagation phase as `apply_phase`)
MD!*/

py::tuple calc_diffraction_gain(const py::array_t<double> &orig,
                                const py::array_t<double> &dest,
                                const py::array_t<double> &mesh,
                                const py::handle &mtl_ind,
                                const py::handle &mtl_prop,
                                double center_freq,
                                int lod,
                                int verbose,
                                const py::handle &sub_mesh_index,
                                int use_kernel,
                                int gpu_id,
                                bool scalar_mode,
                                double thin_slab_threshold,
                                bool apply_fspl,
                                bool apply_phase)
{
    const auto orig_a = qd_python_numpy2arma_Mat<double>(orig, true);
    const auto dest_a = qd_python_numpy2arma_Mat<double>(dest, true);
    const auto mesh_a = qd_python_numpy2arma_Mat<double>(mesh, true);
    const auto mtl_ind_a = qd_python_numpy2arma_Col<arma::uword>(mtl_ind, true);
    const auto mtl_prop_map = qd_python_dict2map<double>(mtl_prop);
    const auto sub_mesh_index_a = qd_python_numpy2arma_Col<unsigned>(sub_mesh_index, true);

    arma::uword n_pos = orig_a.n_rows;
    arma::uword n_seg = 0;
    if (lod == 1 || lod == 2)
        n_seg = 2;
    else if (lod == 3)
        n_seg = 3;
    else if (lod == 4)
        n_seg = 4;
    else if (lod == 5 || lod == 6)
        n_seg = 1;

    // Pre-allocate outputs in Python memory and map Armadillo wrappers to them
    arma::vec gain;
    arma::mat xprmat;
    arma::cube coord;
    auto gain_p = qd_python_init_output(n_pos, &gain);
    auto xprmat_p = qd_python_init_output((scalar_mode ? 2 : 8), n_pos, &xprmat);
    auto coord_p = qd_python_init_output(3, n_seg, n_pos, &coord);

    // Resolve optional pointer
    const arma::u32_vec *p_sub_mesh_index = sub_mesh_index_a.empty() ? nullptr : &sub_mesh_index_a;

    // Scalar mode: the public API takes true acoustic Hz, the core works in EM-equivalent Hz
    // (c_light / f_eq == acoustic wavelength). Must match qd_atmospheric_absorption.hpp.
    const double center_freq_core = scalar_mode ? center_freq * (3.0e8 / 343.0) : center_freq;

    quadriga_lib::calc_diffraction_gain<double>(orig_a, dest_a, mesh_a, mtl_ind_a, mtl_prop_map,
                                                center_freq_core, lod, &gain, &xprmat, &coord, verbose,
                                                p_sub_mesh_index, use_kernel, gpu_id, scalar_mode,
                                                thin_slab_threshold, apply_fspl, apply_phase);

    return py::make_tuple(gain_p, xprmat_p, coord_p);
}

// pybind11 declaration:
// m.def("calc_diffraction_gain", &calc_diffraction_gain,
//       py::arg("orig"),
//       py::arg("dest"),
//       py::arg("mesh"),
//       py::arg("mtl_ind"),
//       py::arg("mtl_prop"),
//       py::arg("center_frequency"),
//       py::arg("lod") = 2,
//       py::arg("verbose") = 0,
//       py::arg("sub_mesh_index") = py::none(),
//       py::arg("use_kernel") = 0,
//       py::arg("gpu_id") = 0,
//       py::arg("scalar_mode") = false,
//       py::arg("thin_slab_threshold") = 0.0,
//       py::arg("apply_fspl") = false,
//       py::arg("apply_phase") = false);