/*!SECTION
Download
SECTION!*/

/*!SECTION_DESC
- **Latest Stable Version (Source Code)**<br>
  <a href="download/quadriga_lib-0.9.0.zip">quadriga_lib-0.9.0.zip</a>
SECTION_DESC!*/
