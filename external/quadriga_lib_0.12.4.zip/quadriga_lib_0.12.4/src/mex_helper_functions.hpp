// SPDX-License-Identifier: Apache-2.0
// Copyright (C) 2022-2026 Stephan Jaeckel (http://quadriga-lib.org)
// Part of quadriga-lib — see LICENSE for terms.

#ifndef mex_helper_H
#define mex_helper_H

#include "mex.h"
#include <string>
#include <armadillo>
#include <utility> // for std::move
#include <cstring> // For std::memcopy
#include <any>
#include <string>
#include <type_traits>
#include <array>
#include <limits>

// Macro to redirect any exception to stderr
#define CALL_QD(expr)                                              \
    do                                                             \
    {                                                              \
        try                                                        \
        {                                                          \
            expr;                                                  \
        }                                                          \
        catch (const std::exception &ex)                           \
        {                                                          \
            mexErrMsgIdAndTxt("quadriga_lib:CPPerror", ex.what()); \
        }                                                          \
    } while (0)

// Helper: check if MATLAB array type matches the requested C++ dtype
template <typename dtype>
inline bool qd_mex_type_matches(const mxArray *input)
{
    if constexpr (std::is_same_v<dtype, double>)
        return mxIsDouble(input);
    else if constexpr (std::is_same_v<dtype, float>)
        return mxIsSingle(input);
    else if constexpr (std::is_same_v<dtype, int>)
        return mxIsClass(input, "int32");
    else if constexpr (std::is_same_v<dtype, unsigned>)
        return mxIsClass(input, "uint32");
    else if constexpr (std::is_same_v<dtype, long long>)
        return mxIsClass(input, "int64");
    else if constexpr (std::is_same_v<dtype, unsigned long long>)
        return mxIsClass(input, "uint64");
    else
        return false;
}

// Helper: Map C++ type to MATLAB class ID
template <typename dtype>
inline mxClassID qd_mex_class_id()
{
    if constexpr (std::is_same_v<dtype, double>)
        return mxDOUBLE_CLASS;
    else if constexpr (std::is_same_v<dtype, float>)
        return mxSINGLE_CLASS;
    else if constexpr (std::is_same_v<dtype, int>)
        return mxINT32_CLASS;
    else if constexpr (std::is_same_v<dtype, unsigned>)
        return mxUINT32_CLASS;
    else if constexpr (std::is_same_v<dtype, long long>)
        return mxINT64_CLASS;
    else if constexpr (std::is_same_v<dtype, unsigned long long>)
        return mxUINT64_CLASS;
    else
        static_assert(!std::is_same_v<dtype, dtype>, "Unsupported dtype for qd_mex_init_output");
}

// Helper: true if the value v (MATLAB type stype) can be converted to dtype without loss. For integer targets
// (except bool) this rejects NaN, Inf, fractional values and values outside the range of dtype; integer sources
// are checked against the range only. Floating-point and bool targets accept every value.
template <typename dtype, typename stype>
inline bool qd_mex_fits(stype v)
{
    if constexpr (std::is_same_v<dtype, stype> || !std::is_integral_v<dtype> || std::is_same_v<dtype, bool>)
        return true;
    else if constexpr (std::is_floating_point_v<stype>)
    {
        // max + 1 = 2^digits and min = -2^digits (signed) or 0 are exact in double
        constexpr double hi = 2.0 * (double)(std::numeric_limits<dtype>::max() / 2 + 1);
        constexpr double lo = std::is_signed_v<dtype> ? -hi : 0.0;
        const double x = (double)v;
        return x >= lo && x < hi && x == (double)(dtype)x; // NaN fails the comparisons; the cast is in range
    }
    else if constexpr (std::is_signed_v<stype> && !std::is_signed_v<dtype>)
        return v >= 0 && (unsigned long long)v <= (unsigned long long)std::numeric_limits<dtype>::max();
    else if constexpr (std::is_signed_v<stype>)
        return (long long)v >= (long long)std::numeric_limits<dtype>::min() &&
               (long long)v <= (long long)std::numeric_limits<dtype>::max();
    else
        return (unsigned long long)v <= (unsigned long long)std::numeric_limits<dtype>::max();
}

// Helper: convert one value to dtype; sets "bad" if it does not fit (see qd_mex_fits) and returns 0 in that case
template <typename dtype, typename stype>
inline dtype qd_mex_cast(stype v, bool &bad)
{
    const bool ok = qd_mex_fits<dtype, stype>(v);
    bad |= !ok;
    return ok ? (dtype)v : dtype(0);
}

// Helper: error for integer input that does not fit dtype, e.g. "Input 'x' must be an integer from 0 to 4294967295."
template <typename dtype>
inline void qd_mex_integer_error(const std::string &var_name, bool scalar)
{
    const std::string range = "from " + std::to_string(std::numeric_limits<dtype>::min()) +
                              " to " + std::to_string(std::numeric_limits<dtype>::max()) + ".";
    std::string msg;
    if (scalar)
        msg = (var_name.empty() ? std::string("Input") : "Input '" + var_name + "'") + " must be an integer " + range;
    else
        msg = (var_name.empty() ? std::string("Entries") : "Entries in '" + var_name + "'") + " must be integers " + range;
    mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "%s", msg.c_str());
}

// Helper: reject complex and sparse input, and input with more than max_dims dimensions
// (mxGetData of a sparse array holds only the non-zero values, so it cannot be read as a dense array)
inline void qd_mex_check_input(const mxArray *input, const std::string &var_name = "", size_t max_dims = 4)
{
    if (mxIsComplex(input))
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Complex datatypes are not supported.");
    if (mxIsSparse(input))
    {
        if (var_name.empty())
            mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Sparse inputs are not supported.");
        const std::string msg = "Input '" + var_name + "' is sparse; sparse inputs are not supported.";
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "%s", msg.c_str());
    }
    if ((size_t)mxGetNumberOfDimensions(input) > max_dims)
    {
        const std::string msg = var_name.empty()
                                    ? "Inputs with more than " + std::to_string(max_dims) + " dimensions are not supported."
                                    : "Input '" + var_name + "' has more than " + std::to_string(max_dims) + " dimensions.";
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "%s", msg.c_str());
    }
}

// Helper: Read up to 4 dimensions from a MATLAB array. Missing dims default to 1.
// Returns {d1, d2, d3, d4, n_data}. Rejects complex and sparse input and input with more than 4 dimensions.
inline std::array<size_t, 5> qd_mex_get_dims(const mxArray *input, const std::string &var_name = "")
{
    qd_mex_check_input(input, var_name, 4);
    size_t n_dim = (size_t)mxGetNumberOfDimensions(input);
    const mwSize *dims = mxGetDimensions(input);
    size_t d1 = (size_t)dims[0];
    size_t d2 = (size_t)dims[1];
    size_t d3 = n_dim < 3 ? 1 : (size_t)dims[2];
    size_t d4 = n_dim < 4 ? 1 : (size_t)dims[3];
    return {d1, d2, d3, d4, d1 * d2 * d3 * d4};
}

// Helper for qd_mex_get_scalar: reads the first element and casts it to <dtype>; sets "bad" when the value
// does not fit an integer type (see qd_mex_fits); returns default_value for empty input
template <typename dtype>
inline dtype qd_mex_read_scalar(const mxArray *input, const std::string &var_name, dtype default_value, bool &bad)
{
    // Set default value in case of empty input
    if (mxGetNumberOfElements(input) == 0)
        return default_value;

    qd_mex_check_input(input, var_name); // Rejects complex and sparse input

    // Assign the MATLAB data to the correct pointer; integer classes are read without a detour through double
    if (mxIsDouble(input))
        return qd_mex_cast<dtype>(*(const double *)mxGetData(input), bad);
    else if (mxIsSingle(input))
        return qd_mex_cast<dtype>(*(const float *)mxGetData(input), bad);
    else if (mxIsClass(input, "uint32"))
        return qd_mex_cast<dtype>(*(const unsigned *)mxGetData(input), bad);
    else if (mxIsClass(input, "int32"))
        return qd_mex_cast<dtype>(*(const int *)mxGetData(input), bad);
    else if (mxIsClass(input, "uint64"))
        return qd_mex_cast<dtype>(*(const unsigned long long *)mxGetData(input), bad);
    else if (mxIsClass(input, "int64"))
        return qd_mex_cast<dtype>(*(const long long *)mxGetData(input), bad);
    else if (mxIsClass(input, "logical"))
        return qd_mex_cast<dtype>(*(const bool *)mxGetData(input), bad);
    else if (var_name.empty())
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported data type.");
    else
    {
        std::string error_message = "Input '" + var_name + "' has an unsupported data type.";
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", error_message.c_str());
    }

    return default_value;
}

// Read a scalar input from MATLAB and convert it to a desired c++ output type
// - Casts to <dtype>; returns default_value for empty input
// - Integer types (except bool) need an integer value in their range: NaN, Inf, fractional, negative (unsigned) or
//   too large values raise an error
// - Rejects complex and sparse input
template <typename dtype>
inline dtype qd_mex_get_scalar(const mxArray *input, std::string var_name, dtype default_value)
{
    bool bad = false;
    const dtype value = qd_mex_read_scalar<dtype>(input, var_name, default_value, bad);
    if (bad)
        qd_mex_integer_error<dtype>(var_name, true);
    return value;
}

// Overload without default value: returns NaN for empty input; only for floating-point types, integer and bool
// types must state their default
template <typename dtype>
inline dtype qd_mex_get_scalar(const mxArray *input, std::string var_name = "")
{
    static_assert(std::is_floating_point_v<dtype>, "qd_mex_get_scalar: integer and bool types need a default value.");
    return qd_mex_get_scalar<dtype>(input, var_name, dtype(NAN));
}

// Read the seed of a random number generator: -1 (random) or 0 ... 2^63-1
// - int64 and uint64 inputs are read without a detour through double, so that large seeds keep their value
// - Returns -1 for empty input
inline long long qd_mex_get_seed(const mxArray *input, const std::string &var_name = "seed")
{
    bool bad = false;
    const long long seed = qd_mex_read_scalar<long long>(input, var_name, -1LL, bad);
    if (bad || seed < -1LL)
    {
        const std::string msg = "Input '" + var_name + "' must be an integer from -1 to " +
                                std::to_string(std::numeric_limits<long long>::max()) + ".";
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "%s", msg.c_str());
    }
    return seed;
}

// Read a string input from MATLAB and convert it to a std::string
// - Returns default_value (e.g. "") for empty input
inline std::string qd_mex_get_string(const mxArray *input, std::string default_value = "")
{
    if (input == nullptr)
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Input must be a string (character array)");

    if (mxGetNumberOfElements(input) == 0)
        return default_value;

    if (!mxIsClass(input, "char"))
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Input must be a string (character array)");

    auto chr = mxArrayToString(input);
    std::string data = std::string(chr);
    mxFree(chr);

    return data;
}

// The reinterpret functions use the MATLAB data in place. Complex arrays are rejected (qd_mex_get_dims): their
// data is stored interleaved or in two blocks, depending on the host, and cannot be read as a real array. Sparse
// arrays store only their non-zero values and are rejected as well.

// Reinterpret MATLAB Array to Armadillo Column Vector
template <typename dtype>
inline arma::Col<dtype> qd_mex_reinterpret_Col(const mxArray *input, bool create_copy = false, const std::string &var_name = "")
{
    auto [d1, d2, d3, d4, n_data] = qd_mex_get_dims(input, var_name); // Rejects complex, sparse and 5-D input

    if (n_data == 0)
        return arma::Col<dtype>();

    return arma::Col<dtype>((dtype *)mxGetData(input), n_data, create_copy, !create_copy);
}

// Reinterpret MATLAB Array to Armadillo Matrix
template <typename dtype>
inline arma::Mat<dtype> qd_mex_reinterpret_Mat(const mxArray *input, bool create_copy = false, const std::string &var_name = "")
{
    auto [d1, d2, d3, d4, n_data] = qd_mex_get_dims(input, var_name); // Rejects complex, sparse and 5-D input

    if (n_data == 0)
        return arma::Mat<dtype>();

    return arma::Mat<dtype>((dtype *)mxGetData(input), d1, d2 * d3 * d4, create_copy, !create_copy);
}

// Reinterpret MATLAB Array to Armadillo Cube
template <typename dtype>
inline arma::Cube<dtype> qd_mex_reinterpret_Cube(const mxArray *input, bool create_copy = false, const std::string &var_name = "")
{
    auto [d1, d2, d3, d4, n_data] = qd_mex_get_dims(input, var_name); // Rejects complex, sparse and 5-D input

    if (n_data == 0)
        return arma::Cube<dtype>();

    return arma::Cube<dtype>((dtype *)mxGetData(input), d1, d2, d3 * d4, create_copy, !create_copy);
}

template <typename dtype>
inline std::vector<arma::Cube<dtype>> qd_mex_reinterpret_CubeVec(const mxArray *input, bool create_copy = false, const std::string &var_name = "")
{
    auto [d1, d2, d3, d4, n_data] = qd_mex_get_dims(input, var_name); // Rejects complex, sparse and 5-D input
    if (n_data == 0)
        return {};

    dtype *data = (dtype *)mxGetData(input);
    const size_t stride = d1 * d2 * d3;
    std::vector<arma::Cube<dtype>> output;
    output.reserve(d4); // prevent later reallocation of aliasing cubes
    for (size_t i = 0; i < d4; ++i)
        output.emplace_back(data + i * stride, d1, d2, d3, create_copy, !create_copy);

    return output;
}

// Converts input to <std::any>
// - Contained types: scalar native c++, arma::Col, arma::Row, arma::Mat, arma::Cube
// - Inputs with more than 3 dimensions are rejected (a cube is the largest type)
// - Empty inputs read to empty outputs
// - Input datatypes are maintained
// - Does not copy data
// - See also: quadriga_lib::any_type_id
inline std::any qd_mex_anycast(const mxArray *input, std::string var_name = "", bool create_copy = false)
{
    qd_mex_check_input(input, var_name, 3); // Rejects complex and sparse input, and more than 3 dimensions

    size_t n_dim = (size_t)mxGetNumberOfDimensions(input); // Number of dimensions - either 2 or 3
    const mwSize *dims = mxGetDimensions(input);           // Read number of elements elements per dimension
    size_t d1 = (size_t)dims[0];                           // Number of elements on first dimension
    size_t d2 = (size_t)dims[1];                           // Number of elements on second dimension
    size_t d34 = n_dim < 3 ? 1 : (size_t)dims[2];          // Number of elements on third dimension
    size_t n_data = d1 * d2 * d34;

    if (n_data == 0) // Return empty
        return std::any();

    // Generate pointers for the 6 supported MATLAB data types
    if (mxIsDouble(input))
    {
        if (d1 == 1 && d2 == 1 && d34 == 1)
            return *(double *)mxGetData(input);
        else if (d1 != 1 && d2 == 1 && d34 == 1)
            return arma::Col<double>((double *)mxGetData(input), n_data, create_copy, !create_copy);
        else if (d1 == 1 && d2 != 1 && d34 == 1)
            return arma::Mat<double>((double *)mxGetData(input), 1, n_data, create_copy, !create_copy);
        else if (d34 != 1)
            return arma::Cube<double>((double *)mxGetData(input), d1, d2, d34, create_copy, !create_copy);
        else
            return arma::Mat<double>((double *)mxGetData(input), d1, d2 * d34, create_copy, !create_copy);
    }
    if (mxIsSingle(input))
    {
        if (d1 == 1 && d2 == 1 && d34 == 1)
            return *(float *)mxGetData(input);
        else if (d1 != 1 && d2 == 1 && d34 == 1)
            return arma::Col<float>((float *)mxGetData(input), n_data, create_copy, !create_copy);
        else if (d1 == 1 && d2 != 1 && d34 == 1)
            return arma::Mat<float>((float *)mxGetData(input), 1, n_data, create_copy, !create_copy);
        else if (d34 != 1)
            return arma::Cube<float>((float *)mxGetData(input), d1, d2, d34, create_copy, !create_copy);
        else
            return arma::Mat<float>((float *)mxGetData(input), d1, d2 * d34, create_copy, !create_copy);
    }
    if (mxIsClass(input, "uint32"))
    {
        if (d1 == 1 && d2 == 1 && d34 == 1)
            return *(unsigned *)mxGetData(input);
        else if (d1 != 1 && d2 == 1 && d34 == 1)
            return arma::Col<unsigned>((unsigned *)mxGetData(input), n_data, create_copy, !create_copy);
        else if (d1 == 1 && d2 != 1 && d34 == 1)
            return arma::Mat<unsigned>((unsigned *)mxGetData(input), 1, n_data, create_copy, !create_copy);
        else if (d34 != 1)
            return arma::Cube<unsigned>((unsigned *)mxGetData(input), d1, d2, d34, create_copy, !create_copy);
        else
            return arma::Mat<unsigned>((unsigned *)mxGetData(input), d1, d2 * d34, create_copy, !create_copy);
    }
    if (mxIsClass(input, "int32"))
    {
        if (d1 == 1 && d2 == 1 && d34 == 1)
            return *(int *)mxGetData(input);
        else if (d1 != 1 && d2 == 1 && d34 == 1)
            return arma::Col<int>((int *)mxGetData(input), n_data, create_copy, !create_copy);
        else if (d1 == 1 && d2 != 1 && d34 == 1)
            return arma::Mat<int>((int *)mxGetData(input), 1, n_data, create_copy, !create_copy);
        else if (d34 != 1)
            return arma::Cube<int>((int *)mxGetData(input), d1, d2, d34, create_copy, !create_copy);
        else
            return arma::Mat<int>((int *)mxGetData(input), d1, d2 * d34, create_copy, !create_copy);
    }
    if (mxIsClass(input, "uint64"))
    {
        if (d1 == 1 && d2 == 1 && d34 == 1)
            return *(unsigned long long *)mxGetData(input);
        else if (d1 != 1 && d2 == 1 && d34 == 1)
            return arma::Col<unsigned long long>((unsigned long long *)mxGetData(input), n_data, create_copy, !create_copy);
        else if (d1 == 1 && d2 != 1 && d34 == 1)
            return arma::Mat<unsigned long long>((unsigned long long *)mxGetData(input), 1, n_data, create_copy, !create_copy);
        else if (d34 != 1)
            return arma::Cube<unsigned long long>((unsigned long long *)mxGetData(input), d1, d2, d34, create_copy, !create_copy);
        else
            return arma::Mat<unsigned long long>((unsigned long long *)mxGetData(input), d1, d2 * d34, create_copy, !create_copy);
    }
    if (mxIsClass(input, "int64"))
    {
        if (d1 == 1 && d2 == 1 && d34 == 1)
            return *(long long *)mxGetData(input);
        else if (d1 != 1 && d2 == 1 && d34 == 1)
            return arma::Col<long long>((long long *)mxGetData(input), n_data, create_copy, !create_copy);
        else if (d1 == 1 && d2 != 1 && d34 == 1)
            return arma::Mat<long long>((long long *)mxGetData(input), 1, n_data, create_copy, !create_copy);
        else if (d34 != 1)
            return arma::Cube<long long>((long long *)mxGetData(input), d1, d2, d34, create_copy, !create_copy);
        else
            return arma::Mat<long long>((long long *)mxGetData(input), d1, d2 * d34, create_copy, !create_copy);
    }

    // Throw error if type is not supported
    if (var_name.empty())
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported data type.");
    else
    {
        std::string error_message = "Input '" + var_name + "' has an unsupported data type.";
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", error_message.c_str());
    }

    return std::any();
}

// Copy-convert MATLAB array data into a pre-allocated C++ buffer.
// Dispatches on the input's MATLAB type; casts each element to `dtype`. For integer types, NaN, Inf, fractional and
// out-of-range values raise an error after the copy.
template <typename dtype>
inline void qd_mex_copy_convert(const mxArray *input, dtype *ptr, size_t n_data,
                                const std::string &var_name = "")
{
    bool bad = false; // Set when a value does not fit an integer dtype (NaN, Inf, fraction, out of range)
    auto copy = [&](auto *src)
    {
        bool b = false;
        for (size_t m = 0; m < n_data; ++m)
            ptr[m] = qd_mex_cast<dtype>(src[m], b);
        bad = b;
    };
    if (qd_mex_type_matches<double>(input))
        copy((const double *)mxGetData(input));
    else if (qd_mex_type_matches<float>(input))
        copy((const float *)mxGetData(input));
    else if (qd_mex_type_matches<unsigned>(input))
        copy((const unsigned *)mxGetData(input));
    else if (qd_mex_type_matches<int>(input))
        copy((const int *)mxGetData(input));
    else if (qd_mex_type_matches<unsigned long long>(input))
        copy((const unsigned long long *)mxGetData(input));
    else if (qd_mex_type_matches<long long>(input))
        copy((const long long *)mxGetData(input));
    else
    {
        std::string msg = var_name.empty() ? "Unsupported data type." : "Input '" + var_name + "' has an unsupported data type.";
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", msg.c_str());
    }
    if (bad)
        qd_mex_integer_error<dtype>(var_name, false);
}

// Reads input and converts it to desired C++ type, creates a copy of the input
template <typename dtype>
inline arma::Col<dtype> qd_mex_typecast_Col(const mxArray *input, std::string var_name = "", size_t n_elem = 0)
{
    auto [d1, d2, d3, d4, n_data] = qd_mex_get_dims(input, var_name);
    if (n_data == 0)
        return arma::Col<dtype>();
    if (n_elem != 0 && n_data != n_elem)
    {
        std::string msg = var_name.empty() ? "Incorrect number of elements." : "Input '" + var_name + "' has incorrect number of elements.";
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", msg.c_str());
    }
    arma::Col<dtype> output(n_data, arma::fill::none);
    qd_mex_copy_convert<dtype>(input, output.memptr(), n_data, var_name);
    return output;
}

template <typename dtype>
inline arma::Mat<dtype> qd_mex_typecast_Mat(const mxArray *input, std::string var_name = "")
{
    auto [d1, d2, d3, d4, n_data] = qd_mex_get_dims(input, var_name);
    if (n_data == 0)
        return arma::Mat<dtype>();
    arma::Mat<dtype> output(d1, d2 * d3 * d4, arma::fill::none);
    qd_mex_copy_convert<dtype>(input, output.memptr(), n_data, var_name);
    return output;
}

template <typename dtype>
inline arma::Cube<dtype> qd_mex_typecast_Cube(const mxArray *input, std::string var_name = "")
{
    auto [d1, d2, d3, d4, n_data] = qd_mex_get_dims(input, var_name);
    if (n_data == 0)
        return arma::Cube<dtype>();
    arma::Cube<dtype> output(d1, d2, d3 * d4, arma::fill::none);
    qd_mex_copy_convert<dtype>(input, output.memptr(), n_data, var_name);
    return output;
}

template <typename dtype>
inline std::vector<arma::Cube<dtype>> qd_mex_typecast_CubeVec(const mxArray *input, std::string var_name = "")
{
    auto [d1, d2, d3, d4, n_data] = qd_mex_get_dims(input, var_name);
    if (n_data == 0)
        return {};

    std::vector<arma::Cube<dtype>> output;
    output.reserve(d4);
    for (size_t i = 0; i < d4; ++i)
        output.emplace_back(d1, d2, d3, arma::fill::none);

    const size_t stride = d1 * d2 * d3;
    bool bad = false; // Set when a value does not fit an integer dtype (NaN, Inf, fraction, out of range)
    auto copy = [&](auto *src)
    {
        bool b = false;
        for (size_t i = 0; i < d4; ++i)
        {
            dtype *dst = output[i].memptr();
            const auto *s = src + i * stride;
            for (size_t m = 0; m < stride; ++m)
                dst[m] = qd_mex_cast<dtype>(s[m], b);
        }
        bad = b;
    };

    if (qd_mex_type_matches<double>(input))
        copy((const double *)mxGetData(input));
    else if (qd_mex_type_matches<float>(input))
        copy((const float *)mxGetData(input));
    else if (qd_mex_type_matches<unsigned>(input))
        copy((const unsigned *)mxGetData(input));
    else if (qd_mex_type_matches<int>(input))
        copy((const int *)mxGetData(input));
    else if (qd_mex_type_matches<unsigned long long>(input))
        copy((const unsigned long long *)mxGetData(input));
    else if (qd_mex_type_matches<long long>(input))
        copy((const long long *)mxGetData(input));
    else
    {
        std::string msg = var_name.empty() ? "Unsupported data type." : "Input '" + var_name + "' has an unsupported data type.";
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", msg.c_str());
    }
    if (bad)
        qd_mex_integer_error<dtype>(var_name, false);

    return output;
}

// Quick input converters; var_name is used in error messages
template <typename dtype>
inline arma::Col<dtype> qd_mex_get_Col(const mxArray *input, bool copy = false, const std::string &var_name = "")
{
    return (qd_mex_type_matches<dtype>(input) && !copy)
               ? qd_mex_reinterpret_Col<dtype>(input, false, var_name)
               : qd_mex_typecast_Col<dtype>(input, var_name);
}

template <typename dtype>
inline arma::Mat<dtype> qd_mex_get_Mat(const mxArray *input, bool copy = false, const std::string &var_name = "")
{
    return (qd_mex_type_matches<dtype>(input) && !copy)
               ? qd_mex_reinterpret_Mat<dtype>(input, false, var_name)
               : qd_mex_typecast_Mat<dtype>(input, var_name);
}

template <typename dtype>
inline arma::Cube<dtype> qd_mex_get_Cube(const mxArray *input, bool copy = false, const std::string &var_name = "")
{
    return (qd_mex_type_matches<dtype>(input) && !copy)
               ? qd_mex_reinterpret_Cube<dtype>(input, false, var_name)
               : qd_mex_typecast_Cube<dtype>(input, var_name);
}

template <typename dtype>
inline std::vector<arma::Cube<dtype>> qd_mex_get_CubeVec(const mxArray *input, bool copy = false, const std::string &var_name = "")
{
    return (qd_mex_type_matches<dtype>(input) && !copy)
               ? qd_mex_reinterpret_CubeVec<dtype>(input, false, var_name)
               : qd_mex_typecast_CubeVec<dtype>(input, var_name);
}

// Read a MATLAB cell array of strings (or a single char string) into a std::vector<std::string>
// - Every cell element must be a char array; unset elements (cell(1,1)) and other types raise an error
inline std::vector<std::string> qd_mex_get_strings(const mxArray *input, const std::string &var_name = "")
{
    std::vector<std::string> out;
    if (input == nullptr || mxIsEmpty(input))
        return out;

    if (mxIsChar(input)) // single string -> one entry
    {
        out.push_back(qd_mex_get_string(input));
        return out;
    }

    if (!mxIsCell(input))
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Object/material names must be a cell array of strings.");

    size_t n = mxGetNumberOfElements(input);
    out.reserve(n);
    for (size_t i = 0; i < n; ++i)
    {
        const mxArray *element = mxGetCell(input, (mwIndex)i); // NULL for unset elements in MATLAB
        if (element == nullptr || !mxIsChar(element))
        {
            const std::string msg = "Cell element " + std::to_string(i + 1) +
                                    (var_name.empty() ? std::string("") : " of '" + var_name + "'") + " is not a string.";
            mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "%s", msg.c_str());
        }
        out.push_back(qd_mex_get_string(element));
    }

    return out;
}

// Creates an mxArray based on the armadillo input type, copies content
template <typename dtype>
inline mxArray *qd_mex_copy2matlab(const dtype *input) // Scalar
{
    // Get classID from dtype
    mxClassID classID;
    if (typeid(dtype).name() == typeid(float).name())
        classID = mxSINGLE_CLASS;
    else if (typeid(dtype).name() == typeid(double).name())
        classID = mxDOUBLE_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned).name())
        classID = mxUINT32_CLASS;
    else if (typeid(dtype).name() == typeid(int).name())
        classID = mxINT32_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned long long).name())
        classID = mxUINT64_CLASS;
    else if (typeid(dtype).name() == typeid(long long).name())
        classID = mxINT64_CLASS;
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported datatype.");

    mxArray *output = mxCreateNumericMatrix(1, 1, classID, mxREAL);
    std::memcpy((dtype *)mxGetData(output), input, sizeof(dtype));
    return output;
}

template <typename dtype>
inline mxArray *qd_mex_copy2matlab(const arma::Row<dtype> *input) // Row Vector
{
    mxClassID classID;
    if (typeid(dtype).name() == typeid(float).name())
        classID = mxSINGLE_CLASS;
    else if (typeid(dtype).name() == typeid(double).name())
        classID = mxDOUBLE_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned).name())
        classID = mxUINT32_CLASS;
    else if (typeid(dtype).name() == typeid(int).name())
        classID = mxINT32_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned long long).name())
        classID = mxUINT64_CLASS;
    else if (typeid(dtype).name() == typeid(long long).name())
        classID = mxINT64_CLASS;
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported datatype.");

    mxArray *output = mxCreateNumericMatrix(1, (mwSize)input->n_elem, classID, mxREAL);
    std::memcpy((dtype *)mxGetData(output), input->memptr(), sizeof(dtype) * input->n_elem);
    return output;
}

template <typename dtype>
inline mxArray *qd_mex_copy2matlab(const arma::Col<dtype> *input, // Column Vector
                                   bool transpose = false,        // Transpose output
                                   size_t ns = 0,                 // Number of elements in output
                                   const size_t *is = nullptr)    // List of elements to copy, 0-based
{
    mxClassID classID;
    if (typeid(dtype).name() == typeid(float).name())
        classID = mxSINGLE_CLASS;
    else if (typeid(dtype).name() == typeid(double).name())
        classID = mxDOUBLE_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned).name())
        classID = mxUINT32_CLASS;
    else if (typeid(dtype).name() == typeid(int).name())
        classID = mxINT32_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned long long).name())
        classID = mxUINT64_CLASS;
    else if (typeid(dtype).name() == typeid(long long).name())
        classID = mxINT64_CLASS;
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported datatype.");

    if (input->empty())
        return mxCreateNumericMatrix(0, 0, classID, mxREAL);

    ns = ns == 0 ? input->n_elem : ns;
    mxArray *output = transpose ? mxCreateNumericMatrix(1, (mwSize)ns, classID, mxREAL)
                                : mxCreateNumericMatrix((mwSize)ns, 1, classID, mxREAL);
    dtype *ptr_o = (dtype *)mxGetData(output);
    const dtype *ptr_i = input->memptr();

    if (is == nullptr) // Copy all that fit, further output elements stay zero
        std::memcpy(ptr_o, ptr_i, sizeof(dtype) * (ns < input->n_elem ? ns : input->n_elem));
    else // Copy selected
        for (size_t i = 0ULL; i < ns; ++i)
            ptr_o[i] = is[i] >= input->n_elem ? *ptr_i : ptr_i[is[i]];

    return output;
}

template <typename dtype>
inline mxArray *qd_mex_copy2matlab(const arma::Mat<dtype> *input, // Matrix
                                   size_t ns = 0,                 // Number of columns in output
                                   const size_t *is = nullptr)    // List of columns to copy, 0-based
{
    mxClassID classID;
    if (typeid(dtype).name() == typeid(float).name())
        classID = mxSINGLE_CLASS;
    else if (typeid(dtype).name() == typeid(double).name())
        classID = mxDOUBLE_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned).name())
        classID = mxUINT32_CLASS;
    else if (typeid(dtype).name() == typeid(int).name())
        classID = mxINT32_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned long long).name())
        classID = mxUINT64_CLASS;
    else if (typeid(dtype).name() == typeid(long long).name())
        classID = mxINT64_CLASS;
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported datatype.");

    if (input->empty())
        return mxCreateNumericMatrix(0, 0, classID, mxREAL);

    size_t m = input->n_rows;          // Rows
    ns = ns == 0 ? input->n_cols : ns; // Output columns
    mxArray *output = mxCreateNumericMatrix((mwSize)m, (mwSize)ns, classID, mxREAL);
    dtype *ptr = (dtype *)mxGetData(output);

    if (is == nullptr) // Copy all columns that fit, further output columns stay zero
        std::memcpy(ptr, input->memptr(), sizeof(dtype) * m * (ns < input->n_cols ? ns : input->n_cols));
    else // Copy selected
        for (size_t i = 0ULL; i < ns; ++i)
        {
            size_t k = is[i] >= input->n_cols ? 0ULL : is[i];
            std::memcpy(&ptr[i * m], input->colptr(k), sizeof(dtype) * m);
        }

    return output;
}

template <typename dtype>
inline mxArray *qd_mex_copy2matlab(const arma::Cube<dtype> *input, // Cube
                                   size_t ns = 0,                  // Number of columns in output
                                   const size_t *is = nullptr)     // List of columns to copy, 0-based
{
    mxClassID classID;
    if (typeid(dtype).name() == typeid(float).name())
        classID = mxSINGLE_CLASS;
    else if (typeid(dtype).name() == typeid(double).name())
        classID = mxDOUBLE_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned).name())
        classID = mxUINT32_CLASS;
    else if (typeid(dtype).name() == typeid(int).name())
        classID = mxINT32_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned long long).name())
        classID = mxUINT64_CLASS;
    else if (typeid(dtype).name() == typeid(long long).name())
        classID = mxINT64_CLASS;
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported datatype.");

    if (input->empty())
        return mxCreateNumericMatrix(0, 0, classID, mxREAL);

    size_t m = input->n_rows * input->n_cols; // Rows and columns
    ns = ns == 0 ? input->n_slices : ns;      // Slices
    mwSize dims[3] = {(mwSize)input->n_rows, (mwSize)input->n_cols, (mwSize)ns};
    mxArray *output = mxCreateNumericArray(3, dims, classID, mxREAL);
    dtype *ptr = (dtype *)mxGetData(output);

    if (is == nullptr) // Copy all slices that fit, further output slices stay zero
        std::memcpy(ptr, input->memptr(), sizeof(dtype) * m * (ns < input->n_slices ? ns : input->n_slices));
    else // Copy selected
        for (size_t i = 0ULL; i < ns; ++i)
        {
            size_t k = is[i] >= input->n_slices ? 0ULL : is[i];
            std::memcpy(&ptr[i * m], input->slice_memptr(k), sizeof(dtype) * m);
        }

    return output;
}

inline mxArray *qd_mex_copy2matlab(const std::vector<std::string> *strings)
{
    size_t n_obj = strings->size();
    auto *cellArray = mxCreateCellMatrix((mwSize)n_obj, 1);
    for (size_t i = 0; i < n_obj; ++i)
    {
        auto *mxStr = mxCreateString(strings->at(i).c_str());
        mxSetCell(cellArray, i, mxStr);
    }
    return cellArray;
}

inline mxArray *qd_mex_copy2matlab(const std::vector<bool> *bools)
{
    if (!bools)
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Null std::vector<bool> pointer.");

    const size_t n_obj = bools->size();

    if (n_obj == 0)
        return mxCreateLogicalMatrix(0, 0);

    mxArray *out = mxCreateLogicalMatrix((mwSize)n_obj, 1);
    mxLogical *dst = mxGetLogicals(out);

    for (size_t i = 0; i < n_obj; ++i)
        dst[i] = (*bools)[i] ? 1 : 0;

    return out;
}

// Creates an mxArray based on a vector of armadillo input types
// - adds one additional dimension, e.g. arma::Cube --> MATLAB 4D
// - optional input: reading order of vector elements
// - copies data
// - zero-padding of missing data
// - returns empty Matrix object is vector is empty
template <typename dtype>
inline mxArray *qd_mex_vector2matlab(const std::vector<arma::Col<dtype>> *input,
                                     size_t ns = 0,
                                     const size_t *is = nullptr, dtype padding = (dtype)0)
{
    // Get classID from dtype
    mxClassID classID;
    if (typeid(dtype).name() == typeid(float).name())
        classID = mxSINGLE_CLASS;
    else if (typeid(dtype).name() == typeid(double).name())
        classID = mxDOUBLE_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned).name())
        classID = mxUINT32_CLASS;
    else if (typeid(dtype).name() == typeid(int).name())
        classID = mxINT32_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned long long).name())
        classID = mxUINT64_CLASS;
    else if (typeid(dtype).name() == typeid(long long).name())
        classID = mxINT64_CLASS;
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported datatype.");

    if (input->empty())
        return mxCreateNumericMatrix(0, 0, classID, mxREAL);

    bool use_padding = padding != (dtype)0;

    // Get maximum input data dimensions
    size_t m = 0ULL;
    for (auto &v : *input)
        m = v.n_rows > m ? v.n_rows : m;
    ns = ns == 0ULL ? input->size() : ns;

    mxArray *output = mxCreateNumericMatrix((mwSize)m, (mwSize)ns, classID, mxREAL);
    dtype *ptr = (dtype *)mxGetData(output);

    // Copy data; without "is", snapshots after the last input element stay zero (or "padding")
    for (size_t i = 0ULL; i < ns; ++i)
    {
        if (is == nullptr && i >= input->size())
        {
            if (use_padding)
                for (dtype *p = &ptr[i * m]; p < &ptr[(i + 1) * m]; ++p)
                    *p = padding;
            continue;
        }
        size_t k = (is == nullptr) ? i : (is[i] >= input->size() ? 0ULL : is[i]);
        size_t r = input->at(k).n_rows;

        if (use_padding && r != m)
            for (dtype *p = &ptr[i * m]; p < &ptr[(i + 1) * m]; ++p)
                *p = padding;

        std::memcpy(&ptr[i * m], input->at(k).memptr(), sizeof(dtype) * r);
    }

    return output;
}

template <typename dtype>
inline mxArray *qd_mex_vector2matlab(const std::vector<arma::Mat<dtype>> *input,
                                     size_t ns = 0,
                                     const size_t *is = nullptr,
                                     dtype padding = (dtype)0)
{
    // Get classID from dtype
    mxClassID classID;
    if (typeid(dtype).name() == typeid(float).name())
        classID = mxSINGLE_CLASS;
    else if (typeid(dtype).name() == typeid(double).name())
        classID = mxDOUBLE_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned).name())
        classID = mxUINT32_CLASS;
    else if (typeid(dtype).name() == typeid(int).name())
        classID = mxINT32_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned long long).name())
        classID = mxUINT64_CLASS;
    else if (typeid(dtype).name() == typeid(long long).name())
        classID = mxINT64_CLASS;
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported datatype.");

    if (input->empty())
        return mxCreateNumericMatrix(0, 0, classID, mxREAL);

    bool use_padding = padding != (dtype)0;

    // Get maximum input data dimensions
    size_t n_rows = 0ULL, n_cols = 0ULL;
    for (auto &v : *input)
        n_rows = v.n_rows > n_rows ? v.n_rows : n_rows,
        n_cols = v.n_cols > n_cols ? v.n_cols : n_cols;

    size_t m = n_rows * n_cols;
    ns = ns == 0ULL ? input->size() : ns;

    mwSize dims[3] = {(mwSize)n_rows, (mwSize)n_cols, (mwSize)ns};
    mxArray *output = mxCreateNumericArray(3, dims, classID, mxREAL);
    dtype *ptr = (dtype *)mxGetData(output);

    // Copy data; without "is", snapshots after the last input element stay zero (or "padding")
    for (size_t i = 0ULL; i < ns; ++i)
    {
        if (is == nullptr && i >= input->size())
        {
            if (use_padding)
                for (dtype *p = &ptr[i * m]; p < &ptr[(i + 1) * m]; ++p)
                    *p = padding;
            continue;
        }
        size_t k = (is == nullptr) ? i : (is[i] >= input->size() ? 0ULL : is[i]);
        size_t r = input->at(k).n_rows, c = input->at(k).n_cols;

        if (use_padding && r * c != m)
            for (dtype *p = &ptr[i * m]; p < &ptr[(i + 1) * m]; ++p)
                *p = padding;

        if (r == n_rows)
            std::memcpy(&ptr[i * m], input->at(k).memptr(), sizeof(dtype) * r * c);
        else // Copy column by column
            for (size_t ic = 0ULL; ic < c; ++ic)
                std::memcpy(&ptr[i * m + ic * n_rows],
                            input->at(k).colptr(ic), sizeof(dtype) * r);
    }

    return output;
}

template <typename dtype>
inline mxArray *qd_mex_vector2matlab(const std::vector<arma::Cube<dtype>> *input,
                                     size_t ns = 0,
                                     const size_t *is = nullptr,
                                     dtype padding = (dtype)0)
{
    // Get classID from dtype
    mxClassID classID;
    if (typeid(dtype).name() == typeid(float).name())
        classID = mxSINGLE_CLASS;
    else if (typeid(dtype).name() == typeid(double).name())
        classID = mxDOUBLE_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned).name())
        classID = mxUINT32_CLASS;
    else if (typeid(dtype).name() == typeid(int).name())
        classID = mxINT32_CLASS;
    else if (typeid(dtype).name() == typeid(unsigned long long).name())
        classID = mxUINT64_CLASS;
    else if (typeid(dtype).name() == typeid(long long).name())
        classID = mxINT64_CLASS;
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported datatype.");

    if (input->empty())
        return mxCreateNumericMatrix(0, 0, classID, mxREAL);

    bool use_padding = padding != (dtype)0;

    // Get maximum input data dimensions
    size_t n_rows = 0ULL, n_cols = 0ULL, n_slices = 0ULL;
    for (auto &v : *input)
        n_rows = v.n_rows > n_rows ? v.n_rows : n_rows,
        n_cols = v.n_cols > n_cols ? v.n_cols : n_cols,
        n_slices = v.n_slices > n_slices ? v.n_slices : n_slices;

    size_t m = n_rows * n_cols * n_slices;
    ns = ns == 0ULL ? input->size() : ns;

    mwSize dims[4] = {(mwSize)n_rows, (mwSize)n_cols, (mwSize)n_slices, (mwSize)ns};
    mxArray *output = mxCreateNumericArray(4, dims, classID, mxREAL);
    dtype *ptr = (dtype *)mxGetData(output);

    // Copy data; without "is", snapshots after the last input element stay zero (or "padding")
    for (size_t i = 0ULL; i < ns; ++i)
    {
        if (is == nullptr && i >= input->size())
        {
            if (use_padding)
                for (dtype *p = &ptr[i * m]; p < &ptr[(i + 1) * m]; ++p)
                    *p = padding;
            continue;
        }
        size_t k = (is == nullptr) ? i : (is[i] >= input->size() ? 0ULL : is[i]);
        size_t r = input->at(k).n_rows, c = input->at(k).n_cols, s = input->at(k).n_slices;

        if (use_padding && r * c * s != m)
            for (dtype *p = &ptr[i * m]; p < &ptr[(i + 1) * m]; ++p)
                *p = padding;

        if (r == n_rows && c == n_cols)
            std::memcpy(&ptr[i * m], input->at(k).memptr(), sizeof(dtype) * r * c * s);
        else // Copy column by column
            for (size_t is = 0ULL; is < s; ++is)
                for (size_t ic = 0ULL; ic < c; ++ic)
                    std::memcpy(&ptr[i * m + is * n_rows * n_cols + ic * n_rows],
                                input->at(k).slice_colptr(is, ic), sizeof(dtype) * r);
    }

    return output;
}

// Creates a std::vector of armadillo types from mxArray
// - e.g. MATLAB --> std::vector<arma::Col<dtype>>
// - vec_dim = Dimension used for std::vector, 0-based
// - Data on other dimensions are vectorized and casted to <dtype>; integer dtypes need integer values in range
// - Rejects complex and sparse input, and input with more than 4 dimensions; var_name is used in error messages
template <typename dtype>
std::vector<arma::Col<dtype>> qd_mex_matlab2vector_Col(const mxArray *input, size_t vec_dim, const std::string &var_name = "")
{
    // Rejects complex and sparse input, and input with more than 4 dimensions
    auto [d1, d2, d3, d4, n_data] = qd_mex_get_dims(input, var_name);

    if (n_data == 0) // Return empty std::vector
        return std::vector<arma::Col<dtype>>();

    // Generate pointers for the 6 supported MATLAB data types
    double *ptr_d = nullptr;
    float *ptr_f = nullptr;
    unsigned *ptr_ui = nullptr;
    int *ptr_i = nullptr;
    unsigned long long *ptr_ull = nullptr;
    long long *ptr_ll = nullptr;

    // Assign the MATLAB data to the correct pointer
    unsigned T = 0; // Type ID of input type
    if (mxIsDouble(input))
        T = 1, ptr_d = (double *)mxGetData(input);
    else if (mxIsSingle(input))
        T = 2, ptr_f = (float *)mxGetData(input);
    else if (mxIsClass(input, "uint32"))
        T = 3, ptr_ui = (unsigned *)mxGetData(input);
    else if (mxIsClass(input, "int32"))
        T = 4, ptr_i = (int *)mxGetData(input);
    else if (mxIsClass(input, "uint64"))
        T = 5, ptr_ull = (unsigned long long *)mxGetData(input);
    else if (mxIsClass(input, "int64"))
        T = 6, ptr_ll = (long long *)mxGetData(input);
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported data type.");

    // Convert data to armadillo output; "bad" is set when a value does not fit an integer dtype
    bool bad = false;
    auto output = std::vector<arma::Col<dtype>>();
    if (vec_dim == 0)
        for (size_t n = 0; n < d1; ++n)
        {
            auto tmp = arma::Col<dtype>(d2 * d3 * d4, arma::fill::none);
            dtype *ptr = tmp.memptr();
            if (T == 1)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_d[m * d1 + n], bad);
            else if (T == 2)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_f[m * d1 + n], bad);
            else if (T == 3)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ui[m * d1 + n], bad);
            else if (T == 4)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_i[m * d1 + n], bad);
            else if (T == 5)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ull[m * d1 + n], bad);
            else if (T == 6)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ll[m * d1 + n], bad);
            output.push_back(tmp);
        }
    else if (vec_dim == 1)
        for (size_t n = 0; n < d2; ++n)
        {
            auto tmp = arma::Col<dtype>(d1 * d3 * d4, arma::fill::none);
            dtype *ptr = tmp.memptr();
            if (T == 1)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_d[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 2)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_f[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 3)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_ui[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 4)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_i[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 5)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_ull[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 6)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_ll[m34 * d2 * d1 + n * d1 + m1], bad);
            output.push_back(tmp);
        }
    else if (vec_dim == 2)
        for (size_t n = 0; n < d3; ++n)
        {
            auto tmp = arma::Col<dtype>(d1 * d2 * d4, arma::fill::none);
            dtype *ptr = tmp.memptr();
            if (T == 1)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_d[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 2)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_f[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 3)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_ui[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 4)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_i[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 5)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_ull[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 6)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_ll[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            output.push_back(tmp);
        }
    else if (vec_dim == 3)
        for (size_t n = 0; n < d4; ++n)
        {
            auto tmp = arma::Col<dtype>(d1 * d2 * d3, arma::fill::none);
            dtype *ptr = tmp.memptr();
            if (T == 1)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_d[n * d3 * d2 * d1 + m], bad);
            else if (T == 2)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_f[n * d3 * d2 * d1 + m], bad);
            else if (T == 3)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ui[n * d3 * d2 * d1 + m], bad);
            else if (T == 4)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_i[n * d3 * d2 * d1 + m], bad);
            else if (T == 5)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ull[n * d3 * d2 * d1 + m], bad);
            else if (T == 6)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ll[n * d3 * d2 * d1 + m], bad);
            output.push_back(tmp);
        }
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Armadillo object dimensions must be 0,1,2 or 3");

    if (bad)
        qd_mex_integer_error<dtype>(var_name, false);

    return output;
}

// Creates a std::vector of armadillo types from mxArray
// - e.g. MATLAB --> std::vector<arma::Mat<dtype>>
// - Same conversion and input checks as qd_mex_matlab2vector_Col
template <typename dtype>
std::vector<arma::Mat<dtype>> qd_mex_matlab2vector_Mat(const mxArray *input, size_t vec_dim, const std::string &var_name = "")
{
    // Rejects complex and sparse input, and input with more than 4 dimensions
    auto [d1, d2, d3, d4, n_data] = qd_mex_get_dims(input, var_name);

    if (n_data == 0) // Return empty std::vector
        return std::vector<arma::Mat<dtype>>();

    // Generate pointers for the 6 supported MATLAB data types
    double *ptr_d = nullptr;
    float *ptr_f = nullptr;
    unsigned *ptr_ui = nullptr;
    int *ptr_i = nullptr;
    unsigned long long *ptr_ull = nullptr;
    long long *ptr_ll = nullptr;

    // Assign the MATLAB data to the correct pointer
    unsigned T = 0; // Type ID of input type
    if (mxIsDouble(input))
        T = 1, ptr_d = (double *)mxGetData(input);
    else if (mxIsSingle(input))
        T = 2, ptr_f = (float *)mxGetData(input);
    else if (mxIsClass(input, "uint32"))
        T = 3, ptr_ui = (unsigned *)mxGetData(input);
    else if (mxIsClass(input, "int32"))
        T = 4, ptr_i = (int *)mxGetData(input);
    else if (mxIsClass(input, "uint64"))
        T = 5, ptr_ull = (unsigned long long *)mxGetData(input);
    else if (mxIsClass(input, "int64"))
        T = 6, ptr_ll = (long long *)mxGetData(input);
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported data type.");

    // Convert data to armadillo output; "bad" is set when a value does not fit an integer dtype
    bool bad = false;
    auto output = std::vector<arma::Mat<dtype>>();
    if (vec_dim == 0)
        for (size_t n = 0; n < d1; ++n)
        {
            auto tmp = arma::Mat<dtype>(d2, d3 * d4, arma::fill::none);
            dtype *ptr = tmp.memptr();
            if (T == 1)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_d[m * d1 + n], bad);
            else if (T == 2)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_f[m * d1 + n], bad);
            else if (T == 3)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ui[m * d1 + n], bad);
            else if (T == 4)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_i[m * d1 + n], bad);
            else if (T == 5)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ull[m * d1 + n], bad);
            else if (T == 6)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ll[m * d1 + n], bad);
            output.push_back(tmp);
        }
    else if (vec_dim == 1)
        for (size_t n = 0; n < d2; ++n)
        {
            auto tmp = arma::Mat<dtype>(d1, d3 * d4, arma::fill::none);
            dtype *ptr = tmp.memptr();
            if (T == 1)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_d[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 2)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_f[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 3)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_ui[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 4)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_i[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 5)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_ull[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 6)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_ll[m34 * d2 * d1 + n * d1 + m1], bad);
            output.push_back(tmp);
        }
    else if (vec_dim == 2)
        for (size_t n = 0; n < d3; ++n)
        {
            auto tmp = arma::Mat<dtype>(d1, d2 * d4, arma::fill::none);
            dtype *ptr = tmp.memptr();
            if (T == 1)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_d[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 2)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_f[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 3)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_ui[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 4)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_i[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 5)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_ull[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 6)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_ll[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            output.push_back(tmp);
        }
    else if (vec_dim == 3)
        for (size_t n = 0; n < d4; ++n)
        {
            auto tmp = arma::Mat<dtype>(d1, d2 * d3, arma::fill::none);
            dtype *ptr = tmp.memptr();
            if (T == 1)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_d[n * d3 * d2 * d1 + m], bad);
            else if (T == 2)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_f[n * d3 * d2 * d1 + m], bad);
            else if (T == 3)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ui[n * d3 * d2 * d1 + m], bad);
            else if (T == 4)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_i[n * d3 * d2 * d1 + m], bad);
            else if (T == 5)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ull[n * d3 * d2 * d1 + m], bad);
            else if (T == 6)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ll[n * d3 * d2 * d1 + m], bad);
            output.push_back(tmp);
        }
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Armadillo object dimensions must be 0,1,2 or 3");

    if (bad)
        qd_mex_integer_error<dtype>(var_name, false);

    return output;
}

// Creates a std::vector of armadillo types from mxArray
// - e.g. MATLAB --> std::vector<arma::Cube<dtype>>
// - Same conversion and input checks as qd_mex_matlab2vector_Col
template <typename dtype>
std::vector<arma::Cube<dtype>> qd_mex_matlab2vector_Cube(const mxArray *input, size_t vec_dim, const std::string &var_name = "")
{
    // Rejects complex and sparse input, and input with more than 4 dimensions
    auto [d1, d2, d3, d4, n_data] = qd_mex_get_dims(input, var_name);

    if (n_data == 0) // Return empty std::vector
        return std::vector<arma::Cube<dtype>>();

    // Generate pointers for the 6 supported MATLAB data types
    double *ptr_d = nullptr;
    float *ptr_f = nullptr;
    unsigned *ptr_ui = nullptr;
    int *ptr_i = nullptr;
    unsigned long long *ptr_ull = nullptr;
    long long *ptr_ll = nullptr;

    // Assign the MATLAB data to the correct pointer
    unsigned T = 0; // Type ID of input type
    if (mxIsDouble(input))
        T = 1, ptr_d = (double *)mxGetData(input);
    else if (mxIsSingle(input))
        T = 2, ptr_f = (float *)mxGetData(input);
    else if (mxIsClass(input, "uint32"))
        T = 3, ptr_ui = (unsigned *)mxGetData(input);
    else if (mxIsClass(input, "int32"))
        T = 4, ptr_i = (int *)mxGetData(input);
    else if (mxIsClass(input, "uint64"))
        T = 5, ptr_ull = (unsigned long long *)mxGetData(input);
    else if (mxIsClass(input, "int64"))
        T = 6, ptr_ll = (long long *)mxGetData(input);
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported data type.");

    // Convert data to armadillo output; "bad" is set when a value does not fit an integer dtype
    bool bad = false;
    auto output = std::vector<arma::Cube<dtype>>();
    if (vec_dim == 0)
        for (size_t n = 0; n < d1; ++n)
        {
            auto tmp = arma::Cube<dtype>(d2, d3, d4, arma::fill::none);
            dtype *ptr = tmp.memptr();
            if (T == 1)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_d[m * d1 + n], bad);
            else if (T == 2)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_f[m * d1 + n], bad);
            else if (T == 3)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ui[m * d1 + n], bad);
            else if (T == 4)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_i[m * d1 + n], bad);
            else if (T == 5)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ull[m * d1 + n], bad);
            else if (T == 6)
                for (size_t m = 0; m < d2 * d3 * d4; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ll[m * d1 + n], bad);
            output.push_back(tmp);
        }
    else if (vec_dim == 1)
        for (size_t n = 0; n < d2; ++n)
        {
            auto tmp = arma::Cube<dtype>(d1, d3, d4, arma::fill::none);
            dtype *ptr = tmp.memptr();
            if (T == 1)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_d[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 2)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_f[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 3)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_ui[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 4)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_i[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 5)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_ull[m34 * d2 * d1 + n * d1 + m1], bad);
            else if (T == 6)
                for (size_t m34 = 0; m34 < d3 * d4; ++m34)
                    for (size_t m1 = 0; m1 < d1; ++m1)
                        ptr[m34 * d1 + m1] = qd_mex_cast<dtype>(ptr_ll[m34 * d2 * d1 + n * d1 + m1], bad);
            output.push_back(tmp);
        }
    else if (vec_dim == 2)
        for (size_t n = 0; n < d3; ++n)
        {
            auto tmp = arma::Cube<dtype>(d1, d2, d4, arma::fill::none);
            dtype *ptr = tmp.memptr();
            if (T == 1)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_d[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 2)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_f[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 3)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_ui[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 4)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_i[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 5)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_ull[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            else if (T == 6)
                for (size_t m4 = 0; m4 < d4; ++m4)
                    for (size_t m12 = 0; m12 < d1 * d2; ++m12)
                        ptr[m4 * d2 * d1 + m12] = qd_mex_cast<dtype>(ptr_ll[m4 * d3 * d2 * d1 + n * d2 * d1 + m12], bad);
            output.push_back(tmp);
        }
    else if (vec_dim == 3)
        for (size_t n = 0; n < d4; ++n)
        {
            auto tmp = arma::Cube<dtype>(d1, d2, d3, arma::fill::none);
            dtype *ptr = tmp.memptr();
            if (T == 1)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_d[n * d3 * d2 * d1 + m], bad);
            else if (T == 2)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_f[n * d3 * d2 * d1 + m], bad);
            else if (T == 3)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ui[n * d3 * d2 * d1 + m], bad);
            else if (T == 4)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_i[n * d3 * d2 * d1 + m], bad);
            else if (T == 5)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ull[n * d3 * d2 * d1 + m], bad);
            else if (T == 6)
                for (size_t m = 0; m < d1 * d2 * d3; ++m)
                    ptr[m] = qd_mex_cast<dtype>(ptr_ll[n * d3 * d2 * d1 + m], bad);
            output.push_back(tmp);
        }
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Armadillo object dimensions must be 0,1,2 or 3");

    if (bad)
        qd_mex_integer_error<dtype>(var_name, false);

    return output;
}

// Converts input to a std::vector<bool>
inline std::vector<bool> qd_mex_matlab2vector_Bool(const mxArray *input, const std::string &var_name = "")
{
    std::vector<bool> output;

    qd_mex_check_input(input, var_name, (size_t)-1); // Rejects complex and sparse input; any number of dimensions

    const size_t n_data = (size_t)mxGetNumberOfElements(input);
    if (n_data == 0) // Return empty
        return output;

    output.reserve(n_data);

    // Shortcut for logical arrays
    if (mxIsLogical(input))
    {
        const mxLogical *data = mxGetLogicals(input);
        for (size_t m = 0; m < n_data; ++m)
            output.push_back(data[m] != 0);
        return output;
    }

    // Generate pointers for the supported MATLAB data types
    double *ptr_d = nullptr;
    float *ptr_f = nullptr;
    unsigned *ptr_ui = nullptr;
    int *ptr_i = nullptr;
    unsigned long long *ptr_ull = nullptr;
    long long *ptr_ll = nullptr;

    // Assign the MATLAB data to the correct pointer
    unsigned T = 0; // Type ID of input type
    if (mxIsDouble(input))
        T = 1, ptr_d = (double *)mxGetData(input);
    else if (mxIsSingle(input))
        T = 2, ptr_f = (float *)mxGetData(input);
    else if (mxIsClass(input, "uint32"))
        T = 3, ptr_ui = (unsigned *)mxGetData(input);
    else if (mxIsClass(input, "int32"))
        T = 4, ptr_i = (int *)mxGetData(input);
    else if (mxIsClass(input, "uint64"))
        T = 5, ptr_ull = (unsigned long long *)mxGetData(input);
    else if (mxIsClass(input, "int64"))
        T = 6, ptr_ll = (long long *)mxGetData(input);
    else
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Unsupported data type.");

    // Convert types
    if (T == 1)
        for (size_t m = 0; m < n_data; ++m)
            output.push_back(ptr_d[m] != 0.0);
    else if (T == 2)
        for (size_t m = 0; m < n_data; ++m)
            output.push_back(ptr_f[m] != 0.0f);
    else if (T == 3)
        for (size_t m = 0; m < n_data; ++m)
            output.push_back(ptr_ui[m] != 0U);
    else if (T == 4)
        for (size_t m = 0; m < n_data; ++m)
            output.push_back(ptr_i[m] != 0);
    else if (T == 5)
        for (size_t m = 0; m < n_data; ++m)
            output.push_back(ptr_ull[m] != 0ULL);
    else if (T == 6)
        for (size_t m = 0; m < n_data; ++m)
            output.push_back(ptr_ll[m] != 0LL);

    return output;
}

// Creates an mxArray based on the armadillo type, Initializes mxArray and reinterprets armadillo object
template <typename dtype>
inline mxArray *qd_mex_init_output(arma::Row<dtype> *input, size_t n_elem) // 1D Row Vector
{
    mxArray *output = mxCreateNumericMatrix(1, n_elem, qd_mex_class_id<dtype>(), mxREAL);
    input->~Row();
    ::new (input) arma::Row<dtype>((dtype *)mxGetData(output), n_elem, false, true);
    return output;
}

template <typename dtype>
inline mxArray *qd_mex_init_output(arma::Col<dtype> *input, size_t n_elem, bool transpose = false) // 1D Column Vector
{
    mxArray *output = transpose ? mxCreateNumericMatrix(1, n_elem, qd_mex_class_id<dtype>(), mxREAL)
                                : mxCreateNumericMatrix(n_elem, 1, qd_mex_class_id<dtype>(), mxREAL);
    input->~Col();
    ::new (input) arma::Col<dtype>((dtype *)mxGetData(output), n_elem, false, true);
    return output;
}

template <typename dtype>
inline mxArray *qd_mex_init_output(arma::Mat<dtype> *input, size_t n_rows, size_t n_cols) // 2D
{
    mxArray *output = mxCreateNumericMatrix(n_rows, n_cols, qd_mex_class_id<dtype>(), mxREAL);
    input->~Mat();
    ::new (input) arma::Mat<dtype>((dtype *)mxGetData(output), n_rows, n_cols, false, true);
    return output;
}

template <typename dtype>
inline mxArray *qd_mex_init_output(arma::Cube<dtype> *input, size_t n_rows, size_t n_cols, size_t n_slices) // 3D
{
    mwSize dims[3] = {(mwSize)n_rows, (mwSize)n_cols, (mwSize)n_slices};
    mxArray *output = mxCreateNumericArray(3, dims, qd_mex_class_id<dtype>(), mxREAL);
    input->~Cube();
    ::new (input) arma::Cube<dtype>((dtype *)mxGetData(output), n_rows, n_cols, n_slices, false, true);
    return output;
}

template <typename dtype>
inline mxArray *qd_mex_init_output(std::vector<arma::Cube<dtype>> *input,
                                   size_t n_rows, size_t n_cols, size_t n_slices, size_t n_cubes) // 4D
{
    mwSize dims[4] = {(mwSize)n_rows, (mwSize)n_cols, (mwSize)n_slices, (mwSize)n_cubes};
    mxArray *output = mxCreateNumericArray(4, dims, qd_mex_class_id<dtype>(), mxREAL);
    dtype *data = (dtype *)mxGetData(output);
    const size_t stride = n_rows * n_cols * n_slices;

    input->clear();
    input->reserve(n_cubes); // critical: avoid any later reallocation
    for (size_t i = 0; i < n_cubes; ++i)
        input->emplace_back(data + i * stride, n_rows, n_cols, n_slices, false, true);

    return output;
}

// Make an empty struct
inline mxArray *qd_mex_make_struct(const std::vector<std::string> &fields, size_t N = 1)
{
    mxArray *output;
    if (fields.empty())
    {
        mwSize dims[2] = {0, 0};
        output = mxCreateStructArray(2, dims, 0, NULL);
    }
    else
    {
        std::vector<const char *> field_names;
        for (const auto &str : fields)
            field_names.push_back(str.c_str());

        mwSize dims[2] = {1, (mwSize)N}; // Creates a 1xN struct array
        output = mxCreateStructArray(2, dims, (int)field_names.size(), field_names.data());
    }
    return output;
}

inline void qd_mex_set_field(mxArray *strct, const std::string &field, mxArray *data, size_t n = 0)
{
    mxSetField(strct, n, field.c_str(), data);
}

inline bool qd_mex_has_field(const mxArray *strct, const std::string &field)
{
    if (!mxIsStruct(strct))
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Input must be a struct.");
    return mxGetField(strct, 0, field.c_str()) != nullptr;
}

inline mxArray *qd_mex_get_field(const mxArray *strct, const std::string &field, size_t n = 0)
{
    if (!mxIsStruct(strct))
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", "Input must be a struct.");

    size_t n_elem = (size_t)mxGetNumberOfElements(strct);
    if (n >= n_elem)
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", ("Struct index " + std::to_string(n) + " out of range (size " + std::to_string(n_elem) + ").").c_str());

    mxArray *data = mxGetField(strct, (mwIndex)n, field.c_str());
    if (data == nullptr)
        mexErrMsgIdAndTxt("quadriga_lib:CPPerror", ("Field '" + field + "' not found at index " + std::to_string(n) + "!").c_str());
    return data;
}

// Convert std::unordered_map<std::string, std::vector<dtype>> to a 1x1 MATLAB struct.
// Each map key becomes a field; each value vector becomes a column vector [n_mtl, 1].
// Field order follows 'field_order' when given (e.g. the CSV column order); otherwise the
// map's iteration order is used. An empty map yields an empty struct.
template <typename dtype>
inline mxArray *qd_mex_map2struct(const std::unordered_map<std::string, std::vector<dtype>> &map,
                                  const std::vector<std::string> &field_order = {})
{
    // Decide field order: explicit list (filtered to keys present), else map iteration order
    std::vector<std::string> fields;
    fields.reserve(map.size());
    if (!field_order.empty())
    {
        for (const auto &k : field_order)
            if (map.find(k) != map.end())
                fields.push_back(k);
    }
    else
        for (const auto &kv : map)
            fields.push_back(kv.first);

    mxClassID classID = qd_mex_class_id<dtype>();
    mxArray *output = qd_mex_make_struct(fields, 1); // 1x1 struct, one field per key

    for (const auto &key : fields)
    {
        const std::vector<dtype> &vec = map.at(key);
        mxArray *col = mxCreateNumericMatrix((mwSize)vec.size(), vec.empty() ? 0 : 1, classID, mxREAL);
        if (!vec.empty())
            std::memcpy((dtype *)mxGetData(col), vec.data(), sizeof(dtype) * vec.size());
        qd_mex_set_field(output, key, col);
    }

    return output;
}

// Convert a 1x1 MATLAB struct to std::unordered_map<std::string, std::vector<dtype>>.
// Each field becomes a key; the field data (any numeric class) is read as a flat vector
// and cast to dtype. All fields must have the same number of elements (n_mtl); a mismatch
// throws. A non-struct input or an empty struct yields an empty map.
template <typename dtype>
inline std::unordered_map<std::string, std::vector<dtype>> qd_mex_struct2map(const mxArray *strct)
{
    std::unordered_map<std::string, std::vector<dtype>> map;
    if (strct == nullptr || !mxIsStruct(strct))
        return map;

    int n_fields = mxGetNumberOfFields(strct);
    if (n_fields == 0)
        return map;

    size_t n_mtl = 0;
    bool n_mtl_set = false;
    for (int f = 0; f < n_fields; ++f)
    {
        const char *name = mxGetFieldNameByNumber(strct, f);
        const mxArray *data = mxGetFieldByNumber(strct, 0, f);
        if (data == nullptr)
            continue;

        auto [d1, d2, d3, d4, n_data] = qd_mex_get_dims(data, name);

        if (!n_mtl_set)
            n_mtl = n_data, n_mtl_set = true;
        else if (n_data != n_mtl)
            mexErrMsgIdAndTxt("quadriga_lib:CPPerror", ("Material property field '" + std::string(name) +
                               "' has " + std::to_string(n_data) + " elements, expected " +
                               std::to_string(n_mtl) + " (all fields must have the same length).").c_str());

        std::vector<dtype> vec(n_data);
        if (n_data != 0)
            qd_mex_copy_convert<dtype>(data, vec.data(), n_data, name);
        map[std::string(name)] = std::move(vec);
    }

    return map;
}

#endif
