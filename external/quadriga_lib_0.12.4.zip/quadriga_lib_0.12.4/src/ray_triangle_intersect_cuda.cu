// SPDX-License-Identifier: Apache-2.0
// Copyright (C) 2022-2026 Stephan Jaeckel (http://quadriga-lib.org)
// Part of quadriga-lib — see LICENSE for terms.

// CUDA variant of qd_RTI — Möller–Trumbore ray-triangle intersection

#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <stdexcept>
#include <algorithm>
#include <type_traits>
#include <vector>

#include <cub/cub.cuh>

// Compile-time diagnostics. Build with -DRTI_DEBUG=1 (or set it to 1 here) to
// print batch sizing, memory budget, and per-batch queue statistics to stdout.
#ifndef RTI_DEBUG
#define RTI_DEBUG 0
#endif

#if RTI_DEBUG
#include <cstdio>
#define RTI_DBG(...)                    \
    do                                  \
    {                                   \
        printf("RTI-DBG " __VA_ARGS__); \
        fflush(stdout);                 \
    } while (0)
#else
#define RTI_DBG(...) \
    do               \
    {                \
    } while (0)
#endif

#include "cuda_common.hpp" // replaces local CUDA_CHECK + cuda_runtime.h
#include "quadriga_lib_cuda_functions.hpp"

namespace
{ // ---------------------------------------------------------------

    // ============================================================================
    // Constants
    // ============================================================================

    static constexpr int BLOCK_SIZE = 256;
    static_assert(BLOCK_SIZE % 32 == 0, "BLOCK_SIZE must be a multiple of 32 (warp size)");

    // Conservative estimate for average AABB hits per ray (used for queue sizing)
    static constexpr int EST_AVG_HITS = 10;

#if RTI_DEBUG
    // Report free device memory at a named point in the call
    static inline void RTI_dbg_mem(const char *tag)
    {
        size_t f = 0, t = 0;
        cudaMemGetInfo(&f, &t);
        RTI_DBG("[%s] free=%zu MB / total=%zu MB\n", tag, f >> 20, t >> 20);
    }
#else
    static inline void RTI_dbg_mem(const char *) {}
#endif

    // Sentinel for packed FBS/SBS: t=1.0f (no hit), face=UINT32_MAX
    static constexpr uint64_t PACKED_SENTINEL = (uint64_t(0x3F800000u) << 32) | uint64_t(0xFFFFFFFFu);

    // ============================================================================
    // Device helper: pack/unpack float+face into uint64 for atomicMin
    // ============================================================================

    __device__ __forceinline__
        uint64_t
        RTI_pack_hit(float t, uint32_t face_idx)
    {
        // IMPORTANT: t must already be clamped with fmaxf(t, 0.0f)
        // to prevent negative zero from breaking the comparison.
        return ((uint64_t)__float_as_uint(t) << 32) | (uint64_t)face_idx;
    }

    __device__ __forceinline__ float RTI_unpack_t(uint64_t packed)
    {
        return __uint_as_float((uint32_t)(packed >> 32));
    }

    __device__ __forceinline__
        uint32_t
        RTI_unpack_face(uint64_t packed)
    {
        return (uint32_t)(packed & 0xFFFFFFFFu);
    }

    // ============================================================================
    // Device helper: warp-level queue compaction
    // ============================================================================

    __device__ __forceinline__ void RTI_enqueue_warp(bool has_hit, uint32_t ray_idx, uint16_t aabb_idx,
                                                     uint32_t *__restrict__ wq_ray, uint16_t *__restrict__ wq_aabb,
                                                     uint32_t *__restrict__ queue_tail, uint32_t queue_capacity)
    {
        // All 32 lanes MUST execute this — invalid threads pass has_hit=false
        uint32_t hit_mask = __ballot_sync(0xFFFFFFFF, has_hit);
        if (hit_mask == 0u)
            return;

        uint32_t lane = threadIdx.x & 31u;
        uint32_t count = __popc(hit_mask);
        uint32_t warp_base;

        if (lane == 0u)
            warp_base = atomicAdd(queue_tail, count);
        warp_base = __shfl_sync(0xFFFFFFFF, warp_base, 0);

        uint32_t local_offset = __popc(hit_mask & ((1u << lane) - 1u));
        if (has_hit)
        {
            uint32_t pos = warp_base + local_offset;
            if (pos < queue_capacity) // guard against overflow — dropped writes are re-done
            {
                wq_ray[pos] = ray_idx;
                wq_aabb[pos] = aabb_idx;
            }
        }
    }

    // ============================================================================
    // Kernel 0: RTI_init_per_ray_state
    // ============================================================================

    __global__ void RTI_init_per_ray_state(
        uint64_t *__restrict__ fbs_packed,
        uint64_t *__restrict__ sbs_packed,
        uint32_t *__restrict__ hit_cnt_atomic,
        uint32_t *__restrict__ queue_tail,
        uint32_t n_ray_batch)
    {
        uint32_t ray_idx = blockIdx.x * blockDim.x + threadIdx.x;
        if (ray_idx >= n_ray_batch)
            return; // safe — no warp-level ops

        fbs_packed[ray_idx] = PACKED_SENTINEL;
        sbs_packed[ray_idx] = PACKED_SENTINEL;
        hit_cnt_atomic[ray_idx] = 0u;

        if (ray_idx == 0u)
            *queue_tail = 0u;
    }

    // ============================================================================
    // Kernel 1: RTI_aabb_test_and_enqueue
    // Slab test with NaN-safe ordered comparisons (no fminf/fmaxf).
    // ============================================================================

    __global__ void RTI_aabb_test_and_enqueue(
        // Ray data (batch)
        const float *__restrict__ d_Ox, const float *__restrict__ d_Oy, const float *__restrict__ d_Oz,
        const float *__restrict__ d_Dx, const float *__restrict__ d_Dy, const float *__restrict__ d_Dz,
        uint32_t n_ray_batch,
        // AABB bounds (scene)
        const float *__restrict__ Xmin, const float *__restrict__ Xmax,
        const float *__restrict__ Ymin, const float *__restrict__ Ymax,
        const float *__restrict__ Zmin, const float *__restrict__ Zmax,
        uint32_t n_sub,
        // Work queue output
        uint32_t *__restrict__ wq_ray_idx,
        uint16_t *__restrict__ wq_aabb_idx,
        uint32_t *__restrict__ queue_tail,
        uint32_t queue_capacity)
    {
        uint32_t ray_idx = blockIdx.x * blockDim.x + threadIdx.x;

        // Partial warp safety: invalid threads must NOT early-return before __ballot_sync.
        // They participate with has_hit=false in every iteration.
        bool valid = (ray_idx < n_ray_batch);

        float ox, oy, oz, dx_i, dy_i, dz_i;
        if (valid)
        {
            ox = d_Ox[ray_idx];
            oy = d_Oy[ray_idx];
            oz = d_Oz[ray_idx];
            float dx = d_Dx[ray_idx];
            float dy = d_Dy[ray_idx];
            float dz = d_Dz[ray_idx];
            dx_i = 1.0f / dx;
            dy_i = 1.0f / dy;
            dz_i = 1.0f / dz;
        }

        for (uint32_t i_sub = 0; i_sub < n_sub; ++i_sub)
        {
            bool has_hit = false;

            if (valid)
            {
                // Slab test — NaN-safe via conditional swaps (Section 4.1)
                float t0_lo = (Xmin[i_sub] - ox) * dx_i;
                float t0_hi = (Xmax[i_sub] - ox) * dx_i;
                if (t0_lo > t0_hi)
                {
                    float tmp = t0_lo;
                    t0_lo = t0_hi;
                    t0_hi = tmp;
                }

                float t1_lo = (Ymin[i_sub] - oy) * dy_i;
                float t1_hi = (Ymax[i_sub] - oy) * dy_i;
                if (t1_lo > t1_hi)
                {
                    float tmp = t1_lo;
                    t1_lo = t1_hi;
                    t1_hi = tmp;
                }

                float t2_lo = (Zmin[i_sub] - oz) * dz_i;
                float t2_hi = (Zmax[i_sub] - oz) * dz_i;
                if (t2_lo > t2_hi)
                {
                    float tmp = t2_lo;
                    t2_lo = t2_hi;
                    t2_hi = tmp;
                }

                // t_min = max of all lows, t_max = min of all highs (ordered comparisons)
                float t_min = (t0_lo > t1_lo) ? t0_lo : t1_lo;
                t_min = (t_min > t2_lo) ? t_min : t2_lo;
                float t_max = (t0_hi < t1_hi) ? t0_hi : t1_hi;
                t_max = (t_max < t2_hi) ? t_max : t2_hi;

                has_hit = (t_max > 0.0f) && (t_max >= t_min) && (t_min <= 1.0f);
            }

            // Warp-level compaction — all 32 lanes participate
            RTI_enqueue_warp(has_hit, ray_idx, (uint16_t)i_sub,
                             wq_ray_idx, wq_aabb_idx, queue_tail, queue_capacity);
        }
    }

    // ============================================================================
    // Kernel 2: RTI_moller_trumbore_fbs
    // First-bounce scatter — finds closest hit per ray via 64-bit atomicMin.
    // ============================================================================

    __global__ void __launch_bounds__(256, 2)
        RTI_moller_trumbore_fbs(
            // Sorted work queue
            const uint32_t *__restrict__ sorted_ray_idx,
            const uint16_t *__restrict__ sorted_aabb_idx,
            uint32_t queue_tail_val,
            // Ray data (batch)
            const float *__restrict__ d_Ox, const float *__restrict__ d_Oy, const float *__restrict__ d_Oz,
            const float *__restrict__ d_Dx, const float *__restrict__ d_Dy, const float *__restrict__ d_Dz,
            // Scene mesh
            const float *__restrict__ Tx, const float *__restrict__ Ty, const float *__restrict__ Tz,
            const float *__restrict__ E1x, const float *__restrict__ E1y, const float *__restrict__ E1z,
            const float *__restrict__ E2x, const float *__restrict__ E2y, const float *__restrict__ E2z,
            // Sub-mesh index (with sentinel)
            const uint32_t *__restrict__ SMI,
            // Outputs
            unsigned long long *__restrict__ fbs_packed, // uint64_t via atomicMin — use ULL for CUDA atomics
            uint32_t *__restrict__ hit_cnt_atomic,
            uint8_t *__restrict__ wq_had_hit)
    {
        uint32_t i = blockIdx.x * blockDim.x + threadIdx.x;
        if (i >= queue_tail_val)
            return; // safe: no warp-level intrinsics

        uint32_t ray_idx = sorted_ray_idx[i];
        uint16_t aabb_idx = sorted_aabb_idx[i];

        // Load ray — scattered access, one-time cost per work item
        float ox = d_Ox[ray_idx], oy = d_Oy[ray_idx], oz = d_Oz[ray_idx];
        float dx = d_Dx[ray_idx], dy = d_Dy[ray_idx], dz = d_Dz[ray_idx];

        // Face range — no branch, SMI has sentinel at n_sub
        uint32_t face_start = SMI[aabb_idx];
        uint32_t face_end = SMI[aabb_idx + 1u];

        float local_best_t = 1.0f;
        uint32_t local_best_face = 0xFFFFFFFFu;
        uint32_t local_hit_count = 0u;

        for (uint32_t i_face = face_start; i_face < face_end; ++i_face)
        {
            // Vector from V1 to origin
            float tx = ox - Tx[i_face];
            float ty = oy - Ty[i_face];
            float tz = oz - Tz[i_face];

            // Load edges
            float e1x = E1x[i_face], e1y = E1y[i_face], e1z = E1z[i_face];
            float e2x = E2x[i_face], e2y = E2y[i_face], e2z = E2z[i_face];

            // Möller–Trumbore — matching AVX2 FMA sequence exactly
            // PQ = cross(E2, D)
            float PQ_x = e2y * dz - e2z * dy;
            float PQ_y = e2z * dx - e2x * dz;
            float PQ_z = e2x * dy - e2y * dx;

            // DT = dot(E1, PQ)
            float DT = e1x * PQ_x + e1y * PQ_y + e1z * PQ_z;

            // U = dot(T, PQ)
            float U = tx * PQ_x + ty * PQ_y + tz * PQ_z;

            // QQ = cross(E1, T)  (reuse PQ variable names for clarity)
            float QQ_x = e1y * tz - e1z * ty;
            float QQ_y = e1z * tx - e1x * tz;
            float QQ_z = e1x * ty - e1y * tx;

            // V = dot(D, QQ)
            float V = dx * QQ_x + dy * QQ_y + dz * QQ_z;

            // W = dot(E2, QQ)
            float W = e2x * QQ_x + e2y * QQ_y + e2z * QQ_z;

            // Full-precision division (matches AVX2 default)
            float inv_DT = 1.0f / DT;
            U *= inv_DT;
            V *= inv_DT;
            W *= inv_DT;

            // Hit conditions (same as AVX2: U>=0, V>=0, U+V<=1, W>=0, W<1)
            if (U >= 0.0f && V >= 0.0f && (U + V) <= 1.0f && W >= 0.0f && W < 1.0f)
            {
                // Force positive zero to prevent negative-zero atomicMin bug (Section 7.1)
                W = fmaxf(W, 0.0f);

                local_hit_count++;
                if (W < local_best_t)
                {
                    local_best_t = W;
                    local_best_face = i_face;
                }
            }
        }

        // Write results via atomics
        if (local_best_face != 0xFFFFFFFFu)
        {
            uint64_t packed = RTI_pack_hit(local_best_t, local_best_face);
            atomicMin(fbs_packed + ray_idx, (unsigned long long)packed);
        }

        if (local_hit_count > 0u)
            atomicAdd(&hit_cnt_atomic[ray_idx], local_hit_count);

        // Set hit flag for CUB compaction
        wq_had_hit[i] = (local_hit_count > 0u) ? 1u : 0u;
    }

    // ============================================================================
    // Kernel 3: RTI_moller_trumbore_sbs
    // Second-bounce scatter — processes only compacted work items (had hit).
    // Skips the FBS face.
    // ============================================================================

    __global__ void __launch_bounds__(256, 2)
        RTI_moller_trumbore_sbs(
            // Compacted index array
            const uint32_t *__restrict__ compact_indices,
            uint32_t num_compact,
            // Sorted work queue (original, referenced via compact_indices)
            const uint32_t *__restrict__ sorted_ray_idx,
            const uint16_t *__restrict__ sorted_aabb_idx,
            // Ray data (batch)
            const float *__restrict__ d_Ox, const float *__restrict__ d_Oy, const float *__restrict__ d_Oz,
            const float *__restrict__ d_Dx, const float *__restrict__ d_Dy, const float *__restrict__ d_Dz,
            // Scene mesh
            const float *__restrict__ Tx, const float *__restrict__ Ty, const float *__restrict__ Tz,
            const float *__restrict__ E1x, const float *__restrict__ E1y, const float *__restrict__ E1z,
            const float *__restrict__ E2x, const float *__restrict__ E2y, const float *__restrict__ E2z,
            // Sub-mesh index (with sentinel)
            const uint32_t *__restrict__ SMI,
            // FBS packed (read-only here, to get fbs_face)
            const unsigned long long *__restrict__ fbs_packed,
            // SBS output
            unsigned long long *__restrict__ sbs_packed)
    {
        uint32_t j = blockIdx.x * blockDim.x + threadIdx.x;
        if (j >= num_compact)
            return;

        // Look up original sorted queue position via compact index
        uint32_t orig_idx = compact_indices[j];
        uint32_t ray_idx = sorted_ray_idx[orig_idx];
        uint16_t aabb_idx = sorted_aabb_idx[orig_idx];

        // Read the winning FBS face for this ray
        uint32_t fbs_face = RTI_unpack_face((uint64_t)fbs_packed[ray_idx]);

        // Load ray
        float ox = d_Ox[ray_idx], oy = d_Oy[ray_idx], oz = d_Oz[ray_idx];
        float dx = d_Dx[ray_idx], dy = d_Dy[ray_idx], dz = d_Dz[ray_idx];

        // Face range
        uint32_t face_start = SMI[aabb_idx];
        uint32_t face_end = SMI[aabb_idx + 1u];

        float local_best_t = 1.0f;
        uint32_t local_best_face = 0xFFFFFFFFu;

        for (uint32_t i_face = face_start; i_face < face_end; ++i_face)
        {
            if (i_face == fbs_face)
                continue;

            float tx = ox - Tx[i_face];
            float ty = oy - Ty[i_face];
            float tz = oz - Tz[i_face];

            float e1x = E1x[i_face], e1y = E1y[i_face], e1z = E1z[i_face];
            float e2x = E2x[i_face], e2y = E2y[i_face], e2z = E2z[i_face];

            float PQ_x = e2y * dz - e2z * dy;
            float PQ_y = e2z * dx - e2x * dz;
            float PQ_z = e2x * dy - e2y * dx;

            float DT = e1x * PQ_x + e1y * PQ_y + e1z * PQ_z;
            float U = tx * PQ_x + ty * PQ_y + tz * PQ_z;

            float QQ_x = e1y * tz - e1z * ty;
            float QQ_y = e1z * tx - e1x * tz;
            float QQ_z = e1x * ty - e1y * tx;

            float V = dx * QQ_x + dy * QQ_y + dz * QQ_z;
            float W = e2x * QQ_x + e2y * QQ_y + e2z * QQ_z;

            float inv_DT = 1.0f / DT;
            U *= inv_DT;
            V *= inv_DT;
            W *= inv_DT;

            if (U >= 0.0f && V >= 0.0f && (U + V) <= 1.0f && W >= 0.0f && W < 1.0f)
            {
                W = fmaxf(W, 0.0f); // negative-zero clamp
                if (W < local_best_t)
                {
                    local_best_t = W;
                    local_best_face = i_face;
                }
            }
        }

        // Write SBS via atomicMin
        if (local_best_face != 0xFFFFFFFFu)
        {
            uint64_t packed = RTI_pack_hit(local_best_t, local_best_face);
            atomicMin(sbs_packed + ray_idx, (unsigned long long)packed);
        }
    }

    // ============================================================================
    // Kernel 4: RTI_finalize_outputs
    // Unpacks packed FBS/SBS into user-facing Wf, Ws, If, Is, hit_cnt.
    // ============================================================================

    __global__ void RTI_finalize_outputs(
        const unsigned long long *__restrict__ fbs_packed,
        const unsigned long long *__restrict__ sbs_packed,
        const uint32_t *__restrict__ hit_cnt_atomic,
        float *__restrict__ d_Wf,
        float *__restrict__ d_Ws,
        uint32_t *__restrict__ d_If,
        uint32_t *__restrict__ d_Is,
        uint32_t *__restrict__ d_hit_cnt,
        uint32_t n_ray_batch,
        bool count_hits)
    {
        uint32_t ray_idx = blockIdx.x * blockDim.x + threadIdx.x;
        if (ray_idx >= n_ray_batch)
            return;

        uint64_t fbs = (uint64_t)fbs_packed[ray_idx];
        uint64_t sbs = (uint64_t)sbs_packed[ray_idx];

        float Wf_val = RTI_unpack_t(fbs);
        float Ws_val = RTI_unpack_t(sbs);
        uint32_t If_val = RTI_unpack_face(fbs);
        uint32_t Is_val = RTI_unpack_face(sbs);

        d_Wf[ray_idx] = Wf_val;
        d_Ws[ray_idx] = Ws_val;
        d_If[ray_idx] = (Wf_val < 1.0f) ? If_val + 1u : 0u; // 1-based, 0 = no hit
        d_Is[ray_idx] = (Ws_val < 1.0f) ? Is_val + 1u : 0u;

        if (count_hits)
            d_hit_cnt[ray_idx] = hit_cnt_atomic[ray_idx];
    }

    // ============================================================================
    // Kernel 5a/5b: double ↔ float conversion (one element per thread)
    // ============================================================================

    __global__ void RTI_d2f(const double *__restrict__ in, float *__restrict__ out, uint32_t n)
    {
        uint32_t i = blockIdx.x * blockDim.x + threadIdx.x;
        if (i < n)
            out[i] = __double2float_rn(in[i]);
    }

    __global__ void RTI_f2d(const float *__restrict__ in, double *__restrict__ out, uint32_t n)
    {
        uint32_t i = blockIdx.x * blockDim.x + threadIdx.x;
        if (i < n)
            out[i] = (double)in[i];
    }

    // ============================================================================
    // Kernel 6: subtract_inplace for dest-orig and edge computing
    // ============================================================================

    __global__ void RTI_subtract_inplace(float *__restrict__ a,
                                         const float *__restrict__ b,
                                         uint32_t n)
    {
        uint32_t i = blockIdx.x * blockDim.x + threadIdx.x;
        if (i < n)
            a[i] -= b[i];
    }

    // ============================================================================
    // RAII cleanup struct
    // Holds all device and pinned-host pointers. Destructor frees everything.
    // ============================================================================

    struct CudaBuffers
    {
        // Scene data (device, uploaded once)
        float *d_Tx = nullptr, *d_Ty = nullptr, *d_Tz = nullptr;
        float *d_E1x = nullptr, *d_E1y = nullptr, *d_E1z = nullptr;
        float *d_E2x = nullptr, *d_E2y = nullptr, *d_E2z = nullptr;
        uint32_t *d_SMI = nullptr;
        float *d_Xmin = nullptr, *d_Xmax = nullptr;
        float *d_Ymin = nullptr, *d_Ymax = nullptr;
        float *d_Zmin = nullptr, *d_Zmax = nullptr;

        // Per-stream buffers (index 0 and 1 for double buffering)
        // Ray input (device)
        float *d_Ox[2] = {}, *d_Oy[2] = {}, *d_Oz[2] = {};
        float *d_Dx[2] = {}, *d_Dy[2] = {}, *d_Dz[2] = {};

        // Ray output (device)
        float *d_Wf[2] = {}, *d_Ws[2] = {};
        uint32_t *d_If[2] = {}, *d_Is[2] = {};
        uint32_t *d_hit_cnt[2] = {};

        // Intermediate (device)
        unsigned long long *d_fbs_packed[2] = {}; // uint64_t via ULL for CUDA atomicMin
        unsigned long long *d_sbs_packed[2] = {};
        uint32_t *d_hit_cnt_atomic[2] = {};

        // Work queue (device) — A/B pairs for CUB DoubleBuffer
        uint32_t *d_wq_ray_idx_A[2] = {}, *d_wq_ray_idx_B[2] = {};
        uint16_t *d_wq_aabb_idx_A[2] = {}, *d_wq_aabb_idx_B[2] = {};
        uint32_t *d_queue_tail[2] = {};
        uint8_t *d_wq_had_hit[2] = {};
        uint32_t *d_compact_indices[2] = {};
        uint32_t *d_num_selected[2] = {};

        // CUB temp buffer (device)
        void *d_cub_temp[2] = {};

        // Pinned host memory — staging buffers for async H↔D
        // Input: 6 float arrays interleaved into one flat buffer
        float *h_ray_input_pinned[2] = {};
        // Output: 2 floats + 3 uints interleaved into one flat buffer
        char *h_ray_output_pinned[2] = {};

        // Double-precision staging (allocated only by double specialization)
        double *d_ray_input_d[2] = {}; // flat SoA: 6 * stride doubles
        double *d_Wf_d[2] = {};        // stride doubles
        double *d_Ws_d[2] = {};

        // Pinned host for double I/O
        double *h_ray_input_pinned_d[2] = {};
        char *h_ray_output_pinned_d[2] = {};
        size_t pinned_input_bytes_d = 0;
        size_t pinned_output_bytes_d = 0;

        // CUDA streams
        cudaStream_t stream[2] = {};
        bool streams_created = false;

        // Sizes (for freeing)
        size_t pinned_input_bytes = 0;
        size_t pinned_output_bytes = 0;

        ~CudaBuffers()
        {
            // Scene data
            cudaFree(d_Tx);
            cudaFree(d_Ty);
            cudaFree(d_Tz);
            cudaFree(d_E1x);
            cudaFree(d_E1y);
            cudaFree(d_E1z);
            cudaFree(d_E2x);
            cudaFree(d_E2y);
            cudaFree(d_E2z);
            cudaFree(d_SMI);
            cudaFree(d_Xmin);
            cudaFree(d_Xmax);
            cudaFree(d_Ymin);
            cudaFree(d_Ymax);
            cudaFree(d_Zmin);
            cudaFree(d_Zmax);

            for (int s = 0; s < 2; ++s)
            {
                cudaFree(d_Ox[s]);
                cudaFree(d_Oy[s]);
                cudaFree(d_Oz[s]);
                cudaFree(d_Dx[s]);
                cudaFree(d_Dy[s]);
                cudaFree(d_Dz[s]);
                cudaFree(d_Wf[s]);
                cudaFree(d_Ws[s]);
                cudaFree(d_If[s]);
                cudaFree(d_Is[s]);
                cudaFree(d_hit_cnt[s]);
                cudaFree(d_fbs_packed[s]);
                cudaFree(d_sbs_packed[s]);
                cudaFree(d_hit_cnt_atomic[s]);
                cudaFree(d_wq_ray_idx_A[s]);
                cudaFree(d_wq_ray_idx_B[s]);
                cudaFree(d_wq_aabb_idx_A[s]);
                cudaFree(d_wq_aabb_idx_B[s]);
                cudaFree(d_queue_tail[s]);
                cudaFree(d_wq_had_hit[s]);
                cudaFree(d_compact_indices[s]);
                cudaFree(d_num_selected[s]);
                cudaFree(d_cub_temp[s]);
                cudaFree(d_ray_input_d[s]);
                cudaFree(d_Wf_d[s]);
                cudaFree(d_Ws_d[s]);

                if (h_ray_input_pinned[s])
                    cudaFreeHost(h_ray_input_pinned[s]);
                if (h_ray_output_pinned[s])
                    cudaFreeHost(h_ray_output_pinned[s]);
                if (h_ray_input_pinned_d[s])
                    cudaFreeHost(h_ray_input_pinned_d[s]);
                if (h_ray_output_pinned_d[s])
                    cudaFreeHost(h_ray_output_pinned_d[s]);
            }

            if (streams_created)
            {
                cudaStreamDestroy(stream[0]);
                cudaStreamDestroy(stream[1]);
            }
        }
    };

    // ============================================================================
    // Helper: ceil(log2(n)) — number of bits needed to represent values 0..n-1
    // ============================================================================

    static inline int RTI_ceil_log2(uint32_t n)
    {
        if (n <= 1u)
            return 1;
        int bits = 0;
        uint32_t v = n - 1u;
        while (v > 0u)
        {
            v >>= 1;
            ++bits;
        }
        return bits;
    }

    // ============================================================================
    // Helper: upload scene host → device
    // ============================================================================

    template <typename dtype>
    static inline void RTI_upload_scene(float *&d_ptr, const dtype *h_ptr, size_t count)
    {
        CUDA_CHECK(cudaMalloc(&d_ptr, count * sizeof(float)));
        if constexpr (std::is_same_v<dtype, float>)
        {
            CUDA_CHECK(cudaMemcpy(d_ptr, h_ptr, count * sizeof(float), cudaMemcpyHostToDevice));
        }
        else
        {
            std::vector<float> tmp(count);
            for (size_t i = 0; i < count; ++i)
                tmp[i] = static_cast<float>(h_ptr[i]);
            CUDA_CHECK(cudaMemcpy(d_ptr, tmp.data(), count * sizeof(float), cudaMemcpyHostToDevice));
        }
    }

    // ============================================================================
    // Helper: stage ray input batch from user arrays into pinned buffer
    // Layout in pinned buffer: [Ox ... | Oy ... | Oz ... | Dx ... | Dy ... | Dz ...]
    // ============================================================================

    template <typename dtype>
    static inline void RTI_stage_ray_input(dtype *pinned, size_t batch_size,
                                           const dtype *Ox, const dtype *Oy, const dtype *Oz,
                                           const dtype *Dx, const dtype *Dy, const dtype *Dz,
                                           size_t offset, size_t count)
    {
        memcpy(pinned + 0 * batch_size, Ox + offset, count * sizeof(dtype));
        memcpy(pinned + 1 * batch_size, Oy + offset, count * sizeof(dtype));
        memcpy(pinned + 2 * batch_size, Oz + offset, count * sizeof(dtype));
        memcpy(pinned + 3 * batch_size, Dx + offset, count * sizeof(dtype));
        memcpy(pinned + 4 * batch_size, Dy + offset, count * sizeof(dtype));
        memcpy(pinned + 5 * batch_size, Dz + offset, count * sizeof(dtype));
    }

    // ============================================================================
    // Helper: copy ray output from pinned buffer to user arrays
    // Layout: [Wf ... | Ws ... | If ... | Is ... | hit_cnt ...]
    // ============================================================================

    template <typename dtype>
    static inline void RTI_unstage_ray_output(const char *pinned, size_t batch_size,
                                              dtype *Wf, dtype *Ws,
                                              unsigned *If, unsigned *Is,
                                              unsigned *hit_cnt, bool count_hits,
                                              size_t offset, size_t count)
    {
        size_t tW = batch_size * sizeof(dtype);    // Wf/Ws stride
        size_t u4 = batch_size * sizeof(uint32_t); // If/Is/hit_cnt stride

        memcpy(Wf + offset, pinned, count * sizeof(dtype));
        memcpy(Ws + offset, pinned + tW, count * sizeof(dtype));
        memcpy(If + offset, pinned + 2 * tW, count * sizeof(uint32_t));
        memcpy(Is + offset, pinned + 2 * tW + u4, count * sizeof(uint32_t));
        if (count_hits)
            memcpy(hit_cnt + offset, pinned + 2 * tW + 2 * u4, count * sizeof(uint32_t));
    }

} // end anonymous namespace --------------------------------------------------

// Public entry point — external linkage
template <typename dtype>
void qd_RTI_CUDA(const dtype *Tx, const dtype *Ty, const dtype *Tz,
                 const dtype *Ux, const dtype *Uy, const dtype *Uz,
                 const dtype *Vx, const dtype *Vy, const dtype *Vz,
                 const size_t n_mesh,
                 const unsigned *SMI,
                 const dtype *Xmin, const dtype *Xmax,
                 const dtype *Ymin, const dtype *Ymax,
                 const dtype *Zmin, const dtype *Zmax,
                 const size_t n_sub,
                 const dtype *Ox, const dtype *Oy, const dtype *Oz,
                 const dtype *Dx, const dtype *Dy, const dtype *Dz,
                 const size_t n_ray,
                 dtype *Wf, dtype *Ws,
                 unsigned *If, unsigned *Is,
                 unsigned *hit_cnt,
                 int gpu_id)
{
    constexpr bool is_double = std::is_same_v<dtype, double>;

    // --- Early returns (Section 8) ---
    if (n_ray == 0)
        return;

    if (n_sub == 0 || n_mesh == 0)
    {
        // Zero-fill all outputs on host — no GPU work needed
        for (size_t i = 0; i < n_ray; ++i)
        {
            Wf[i] = dtype(1.0);
            Ws[i] = dtype(1.0);
            If[i] = 0;
            Is[i] = 0;
        }
        if (hit_cnt)
            memset(hit_cnt, 0, n_ray * sizeof(unsigned));
        return;
    }

    // --- Range check: n_sub must fit in uint16 (Section 8) ---
    if (n_sub > 65535)
        throw std::invalid_argument("qd_RTI_CUDA: n_sub > 65535 not supported (uint16 AABB index).");

    bool count_hits = (hit_cnt != nullptr);

    // --- Set CUDA device ---
    CUDA_CHECK(cudaSetDevice(gpu_id));

    // --- RAII struct for all allocations ---
    CudaBuffers buf;

    // =====================================================================
    // Upload scene data (resident for the entire run)
    // =====================================================================

    RTI_upload_scene(buf.d_Tx, Tx, n_mesh);
    RTI_upload_scene(buf.d_Ty, Ty, n_mesh);
    RTI_upload_scene(buf.d_Tz, Tz, n_mesh);

    RTI_upload_scene(buf.d_E1x, Ux, n_mesh);
    RTI_upload_scene(buf.d_E1y, Uy, n_mesh);
    RTI_upload_scene(buf.d_E1z, Uz, n_mesh);
    RTI_upload_scene(buf.d_E2x, Vx, n_mesh);
    RTI_upload_scene(buf.d_E2y, Vy, n_mesh);
    RTI_upload_scene(buf.d_E2z, Vz, n_mesh);

    // Compute edges on device: E1 = U - T, E2 = V - T
    {
        uint32_t grid_mesh = ((uint32_t)n_mesh + BLOCK_SIZE - 1) / BLOCK_SIZE;
        RTI_subtract_inplace<<<grid_mesh, BLOCK_SIZE>>>(buf.d_E1x, buf.d_Tx, (uint32_t)n_mesh);
        RTI_subtract_inplace<<<grid_mesh, BLOCK_SIZE>>>(buf.d_E1y, buf.d_Ty, (uint32_t)n_mesh);
        RTI_subtract_inplace<<<grid_mesh, BLOCK_SIZE>>>(buf.d_E1z, buf.d_Tz, (uint32_t)n_mesh);
        RTI_subtract_inplace<<<grid_mesh, BLOCK_SIZE>>>(buf.d_E2x, buf.d_Tx, (uint32_t)n_mesh);
        RTI_subtract_inplace<<<grid_mesh, BLOCK_SIZE>>>(buf.d_E2y, buf.d_Ty, (uint32_t)n_mesh);
        RTI_subtract_inplace<<<grid_mesh, BLOCK_SIZE>>>(buf.d_E2z, buf.d_Tz, (uint32_t)n_mesh);
        CUDA_CHECK(cudaDeviceSynchronize());
    }

    // SMI sentinel: allocate n_sub+1 entries, set SMI[n_sub] = n_mesh
    {
        std::vector<uint32_t> smi_with_sentinel(n_sub + 1);
        for (size_t i = 0; i < n_sub; ++i)
            smi_with_sentinel[i] = (uint32_t)SMI[i];
        smi_with_sentinel[n_sub] = (uint32_t)n_mesh;

        CUDA_CHECK(cudaMalloc(&buf.d_SMI, (n_sub + 1) * sizeof(uint32_t)));
        CUDA_CHECK(cudaMemcpy(buf.d_SMI, smi_with_sentinel.data(),
                              (n_sub + 1) * sizeof(uint32_t), cudaMemcpyHostToDevice));
    }

    // AABB bounds
    RTI_upload_scene(buf.d_Xmin, Xmin, n_sub);
    RTI_upload_scene(buf.d_Xmax, Xmax, n_sub);
    RTI_upload_scene(buf.d_Ymin, Ymin, n_sub);
    RTI_upload_scene(buf.d_Ymax, Ymax, n_sub);
    RTI_upload_scene(buf.d_Zmin, Zmin, n_sub);
    RTI_upload_scene(buf.d_Zmax, Zmax, n_sub);

    // =====================================================================
    // Batch size calculation (Section 5.1)
    // =====================================================================

    RTI_dbg_mem("after scene upload");

    size_t free_mem = 0, total_mem = 0;
    CUDA_CHECK(cudaMemGetInfo(&free_mem, &total_mem));

    RTI_DBG("=== call start ===\n");
    RTI_DBG("dtype=%s n_ray=%zu n_mesh=%zu n_sub=%zu count_hits=%d\n",
            is_double ? "double" : "float", n_ray, n_mesh, n_sub, (int)count_hits);
    RTI_DBG("free=%zu MB total=%zu MB EST_AVG_HITS=%d\n",
            free_mem >> 20, total_mem >> 20, EST_AVG_HITS);

    // Per-ray memory budget
    const size_t E = EST_AVG_HITS;
    size_t per_ray_bytes = 6 * 4         // input: Ox,Oy,Oz,Dx,Dy,Dz
                           + 5 * 4       // output: Wf,Ws,If,Is,hit_cnt
                           + 2 * 8 + 4   // intermediate: fbs_packed(8), sbs_packed(8), hit_cnt_atomic(4)
                           + E * (4 + 2) // work queue A: ray_idx(4) + aabb_idx(2)
                           + E * (4 + 2) // work queue B: sort output
                           + E * 1       // had_hit flags
                           + E * 4;      // compact_indices

    if constexpr (is_double)
        per_ray_bytes += 6 * sizeof(double)    // d_ray_input_d
                         + 2 * sizeof(double); // d_Wf_d + d_Ws_d

    // Query CUB temp requirements at runtime, for a given number of queue entries
    auto cub_temp_for = [](size_t items) -> size_t
    {
        int n_items = (int)std::min(items, (size_t)INT32_MAX);

        size_t sort_temp = 0;
        cub::DeviceRadixSort::SortPairs(nullptr, sort_temp,
                                        (uint16_t *)nullptr, (uint16_t *)nullptr,
                                        (uint32_t *)nullptr, (uint32_t *)nullptr,
                                        n_items, 0, 16, (cudaStream_t)0);

        size_t compact_temp = 0;
        cub::DeviceSelect::Flagged(nullptr, compact_temp,
                                   cub::CountingInputIterator<uint32_t>(0),
                                   (uint8_t *)nullptr, (uint32_t *)nullptr, (uint32_t *)nullptr,
                                   n_items, (cudaStream_t)0);

        size_t bytes = (size_t)(std::max(sort_temp, compact_temp) * 1.2); // 20% margin
        return (bytes < 1024) ? (size_t)1024 : bytes;
    };

    // Use 75% of free memory, double-buffered
    size_t usable = (size_t)(free_mem * 0.75);

    auto derive_batch = [&](size_t cub_bytes) -> size_t
    {
        size_t fixed = 2 * cub_bytes;
        size_t b = (usable > fixed) ? (usable - fixed) / (2 * per_ray_bytes) : 0;
        b = std::min(b, n_ray);
        b = (b / BLOCK_SIZE) * BLOCK_SIZE; // align to block size
        return (b == 0) ? (size_t)BLOCK_SIZE : b; // minimum 1 block
    };

    // The CUB temp size depends on the queue capacity, which depends on the
    // batch size, which depends on the CUB temp size. Three passes settle it:
    // pass 1 uses a pessimistic bound, passes 2 and 3 use the real capacity.
    // Sizing it from n_ray instead (the original approach) reserved temp space
    // for a queue far larger than the one actually allocated.
    size_t cub_temp_per_stream = cub_temp_for((n_ray < 10000000) ? n_ray * E : 10000000ULL * E);
    size_t batch_size = derive_batch(cub_temp_per_stream);
    RTI_DBG("sizing pass 1: cub=%zu MB batch=%zu\n", cub_temp_per_stream >> 20, batch_size);

    cub_temp_per_stream = cub_temp_for(batch_size * E); // <= previous, so batch grows
    batch_size = derive_batch(cub_temp_per_stream);
    RTI_DBG("sizing pass 2: cub=%zu MB batch=%zu\n", cub_temp_per_stream >> 20, batch_size);

    cub_temp_per_stream = cub_temp_for(batch_size * E); // >= previous, so batch shrinks
    batch_size = derive_batch(cub_temp_per_stream);
    RTI_DBG("sizing pass 3: cub=%zu MB batch=%zu\n", cub_temp_per_stream >> 20, batch_size);

    // batch_size now fits inside `usable` together with the temp actually
    // allocated, and that temp covers the final (smaller or equal) capacity.
    size_t queue_capacity = batch_size * E;
    {
        const size_t bpe = 4 + 4 + 2 + 2 + 1 + 4; // work queue bytes per entry

        // A ray can enqueue at most one entry per sub-mesh, so batch_size * n_sub
        // is the worst case the queue could ever need.
        size_t worst_case = batch_size * n_sub;

        // Spend leftover budget on queue headroom. When n_ray is small the batch
        // is clamped by n_ray rather than by memory, which used to leave a queue
        // sized for E=10 next to gigabytes of unused VRAM — and a scene with a
        // high hit rate then had to re-run the batch several times to fit it.
        size_t base_bytes = 2 * cub_temp_per_stream + 2 * batch_size * per_ray_bytes;
        size_t spare = (usable > base_bytes) ? usable - base_bytes : 0;
        queue_capacity = std::min(worst_case, queue_capacity + spare / (2 * bpe));

        // Termination floor: the chunk can never shrink below one block, so the
        // queue must always hold one block's worst case. Otherwise a batch that
        // is already minimal keeps overflowing and the retry loop never exits.
        // BLOCK_SIZE * n_sub entries is well under a megabyte.
        queue_capacity = std::max(queue_capacity, (size_t)BLOCK_SIZE * n_sub);
    }

    // Allocation stride: fixed for the whole call. The per-batch chunk length
    // may shrink below this on queue overflow, but the buffers never move.
    const size_t stride = batch_size;

    // Rays per batch. Shrinks if a batch overflows the work queue.
    size_t chunk = batch_size;

#if RTI_DEBUG
    {
        const size_t bpe = 4 + 4 + 2 + 2 + 1 + 4; // work queue bytes per entry
        size_t queue_bytes = 2 * queue_capacity * bpe;
        size_t ray_bytes = 2 * batch_size * (per_ray_bytes - E * bpe);
        RTI_DBG("per_ray_bytes=%zu usable(75%%)=%zu MB batch_size=%zu queue_capacity=%zu\n",
                per_ray_bytes, usable >> 20, batch_size, queue_capacity);
        RTI_DBG("planned: queue=%zu MB ray=%zu MB cub=%zu MB total=%zu MB\n",
                queue_bytes >> 20, ray_bytes >> 20, (2 * cub_temp_per_stream) >> 20,
                (queue_bytes + ray_bytes + 2 * cub_temp_per_stream) >> 20);
    }
#endif

    // =====================================================================
    // Create streams
    // =====================================================================

    CUDA_CHECK(cudaStreamCreate(&buf.stream[0]));
    CUDA_CHECK(cudaStreamCreate(&buf.stream[1]));
    buf.streams_created = true;

    // =====================================================================
    // Allocate per-stream device buffers + pinned host memory
    // =====================================================================

    size_t ray_f_bytes = stride * sizeof(float);
    size_t ray_u_bytes = stride * sizeof(uint32_t);
    size_t ray_8_bytes = stride * sizeof(uint64_t);
    size_t wq_ray_bytes = queue_capacity * sizeof(uint32_t);
    size_t wq_aabb_bytes = queue_capacity * sizeof(uint16_t);
    size_t wq_flag_bytes = queue_capacity * sizeof(uint8_t);
    size_t wq_comp_bytes = queue_capacity * sizeof(uint32_t);

    buf.pinned_input_bytes = 6 * ray_f_bytes;
    // Output: Wf(float) + Ws(float) + If(uint32) + Is(uint32) + hit_cnt(uint32)
    buf.pinned_output_bytes = 2 * ray_f_bytes + 3 * ray_u_bytes;

    for (int s = 0; s < 2; ++s)
    {
        // Ray input
        CUDA_CHECK(cudaMalloc(&buf.d_Ox[s], ray_f_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_Oy[s], ray_f_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_Oz[s], ray_f_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_Dx[s], ray_f_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_Dy[s], ray_f_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_Dz[s], ray_f_bytes));

        // Ray output
        CUDA_CHECK(cudaMalloc(&buf.d_Wf[s], ray_f_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_Ws[s], ray_f_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_If[s], ray_u_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_Is[s], ray_u_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_hit_cnt[s], ray_u_bytes));

        // Intermediate
        CUDA_CHECK(cudaMalloc(&buf.d_fbs_packed[s], ray_8_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_sbs_packed[s], ray_8_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_hit_cnt_atomic[s], ray_u_bytes));

        // Work queue
        CUDA_CHECK(cudaMalloc(&buf.d_wq_ray_idx_A[s], wq_ray_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_wq_ray_idx_B[s], wq_ray_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_wq_aabb_idx_A[s], wq_aabb_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_wq_aabb_idx_B[s], wq_aabb_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_queue_tail[s], sizeof(uint32_t))); // own alloc for cache line isolation
        CUDA_CHECK(cudaMalloc(&buf.d_wq_had_hit[s], wq_flag_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_compact_indices[s], wq_comp_bytes));
        CUDA_CHECK(cudaMalloc(&buf.d_num_selected[s], sizeof(uint32_t)));

        // CUB temp
        CUDA_CHECK(cudaMalloc(&buf.d_cub_temp[s], cub_temp_per_stream));

        // Pinned host memory
        if constexpr (is_double)
        {
            CUDA_CHECK(cudaMalloc(&buf.d_ray_input_d[s], 6 * stride * sizeof(double)));
            CUDA_CHECK(cudaMalloc(&buf.d_Wf_d[s], stride * sizeof(double)));
            CUDA_CHECK(cudaMalloc(&buf.d_Ws_d[s], stride * sizeof(double)));

            buf.pinned_input_bytes_d = 6 * stride * sizeof(double);
            buf.pinned_output_bytes_d = 2 * stride * sizeof(double) + 3 * ray_u_bytes;

            CUDA_CHECK(cudaMallocHost(&buf.h_ray_input_pinned_d[s], buf.pinned_input_bytes_d));
            CUDA_CHECK(cudaMallocHost(&buf.h_ray_output_pinned_d[s], buf.pinned_output_bytes_d));
        }
        else
        {
            CUDA_CHECK(cudaMallocHost(&buf.h_ray_input_pinned[s], buf.pinned_input_bytes));
            CUDA_CHECK(cudaMallocHost(&buf.h_ray_output_pinned[s], buf.pinned_output_bytes));
        }
    }

    RTI_dbg_mem("after per-stream allocation");

    // =====================================================================
    // Compute number of bits for CUB radix sort
    // =====================================================================

    int num_aabb_bits = RTI_ceil_log2((uint32_t)n_sub);
    if (num_aabb_bits > 16)
        num_aabb_bits = 16;

    // =====================================================================
    // Batching loop — double-buffered async pipeline (Section 5.2)
    // =====================================================================

    // Host-side readback values (one per stream)
    uint32_t h_queue_tail[2] = {0, 0};
    uint32_t h_num_compact[2] = {0, 0};

    // What each stream currently has in flight. Chunk lengths are no longer
    // uniform, so the D→H unstage cannot recompute them from the batch index.
    size_t inflight_offset[2] = {0, 0};
    size_t inflight_count[2] = {0, 0};
    int last_stream = 0;

    // Rays staged in the pinned buffer for the batch about to be processed
    size_t staged_count = std::min(chunk, n_ray);

    // Stage batch 0 into pinned memory BEFORE the loop
    {
        if constexpr (is_double)
            RTI_stage_ray_input(buf.h_ray_input_pinned_d[0], stride, Ox, Oy, Oz, Dx, Dy, Dz, 0, staged_count);
        else
            RTI_stage_ray_input(buf.h_ray_input_pinned[0], stride, Ox, Oy, Oz, Dx, Dy, Dz, 0, staged_count);
    }

    for (size_t batch_idx = 0, ray_offset = 0; ray_offset < n_ray; ++batch_idx)
    {
        int s = (int)(batch_idx % 2);        // current stream
        int sp = (int)((batch_idx - 1) % 2); // previous stream (wraps safely since unsigned)
        last_stream = s;

        size_t n_ray_batch = staged_count;
        uint32_t n_ray_batch_u = (uint32_t)n_ray_batch;

        // --- Wait for previous batch's D→H to finish, then copy to user arrays ---
        if (batch_idx > 0)
        {
            CUDA_CHECK(cudaStreamSynchronize(buf.stream[sp]));

            size_t prev_offset = inflight_offset[sp];
            size_t prev_count = inflight_count[sp];

            if constexpr (is_double)
                RTI_unstage_ray_output(buf.h_ray_output_pinned_d[sp], stride,
                                       Wf, Ws, If, Is, hit_cnt, count_hits,
                                       prev_offset, prev_count);
            else
                RTI_unstage_ray_output(buf.h_ray_output_pinned[sp], stride,
                                       Wf, Ws, If, Is, hit_cnt, count_hits,
                                       prev_offset, prev_count);
        }

        // --- H→D: upload ray data for this batch ---
        // Layout in pinned: [Ox | Oy | Oz | Dx | Dy | Dz], each `stride` floats
        cudaStream_t cs = buf.stream[s];

        if constexpr (is_double)
        {
            // Upload doubles to device staging buffer
            double *d_in = buf.d_ray_input_d[s];
            double *h_in = buf.h_ray_input_pinned_d[s];
            for (int k = 0; k < 6; ++k)
                CUDA_CHECK(cudaMemcpyAsync(d_in + k * stride,
                                           h_in + k * stride,
                                           n_ray_batch * sizeof(double),
                                           cudaMemcpyHostToDevice, cs));

            // d2f conversion → fills existing float device arrays
            uint32_t grid_cvt = (n_ray_batch_u + BLOCK_SIZE - 1) / BLOCK_SIZE;
            float *d_float[6] = {buf.d_Ox[s], buf.d_Oy[s], buf.d_Oz[s], buf.d_Dx[s], buf.d_Dy[s], buf.d_Dz[s]};
            for (int k = 0; k < 6; ++k)
                RTI_d2f<<<grid_cvt, BLOCK_SIZE, 0, cs>>>(d_in + k * stride, d_float[k], n_ray_batch_u);
        }
        else
        {
            CUDA_CHECK(cudaMemcpyAsync(buf.d_Ox[s], buf.h_ray_input_pinned[s] + 0 * stride,
                                       n_ray_batch * sizeof(float), cudaMemcpyHostToDevice, cs));
            CUDA_CHECK(cudaMemcpyAsync(buf.d_Oy[s], buf.h_ray_input_pinned[s] + 1 * stride,
                                       n_ray_batch * sizeof(float), cudaMemcpyHostToDevice, cs));
            CUDA_CHECK(cudaMemcpyAsync(buf.d_Oz[s], buf.h_ray_input_pinned[s] + 2 * stride,
                                       n_ray_batch * sizeof(float), cudaMemcpyHostToDevice, cs));
            CUDA_CHECK(cudaMemcpyAsync(buf.d_Dx[s], buf.h_ray_input_pinned[s] + 3 * stride,
                                       n_ray_batch * sizeof(float), cudaMemcpyHostToDevice, cs));
            CUDA_CHECK(cudaMemcpyAsync(buf.d_Dy[s], buf.h_ray_input_pinned[s] + 4 * stride,
                                       n_ray_batch * sizeof(float), cudaMemcpyHostToDevice, cs));
            CUDA_CHECK(cudaMemcpyAsync(buf.d_Dz[s], buf.h_ray_input_pinned[s] + 5 * stride,
                                       n_ray_batch * sizeof(float), cudaMemcpyHostToDevice, cs));
        }

        // Compute direction on device: D = Dest - Orig
        {
            uint32_t grid_dir = (n_ray_batch_u + BLOCK_SIZE - 1) / BLOCK_SIZE;
            RTI_subtract_inplace<<<grid_dir, BLOCK_SIZE, 0, cs>>>(buf.d_Dx[s], buf.d_Ox[s], n_ray_batch_u);
            RTI_subtract_inplace<<<grid_dir, BLOCK_SIZE, 0, cs>>>(buf.d_Dy[s], buf.d_Oy[s], n_ray_batch_u);
            RTI_subtract_inplace<<<grid_dir, BLOCK_SIZE, 0, cs>>>(buf.d_Dz[s], buf.d_Oz[s], n_ray_batch_u);
        }

        // --- Kernel 0: init per-ray state ---
        uint32_t grid0 = (n_ray_batch_u + BLOCK_SIZE - 1) / BLOCK_SIZE; // reassigned if the chunk shrinks
        RTI_init_per_ray_state<<<grid0, BLOCK_SIZE, 0, cs>>>(
            (uint64_t *)buf.d_fbs_packed[s],
            (uint64_t *)buf.d_sbs_packed[s],
            buf.d_hit_cnt_atomic[s],
            buf.d_queue_tail[s],
            n_ray_batch_u);

        // --- Kernel 1: AABB test + enqueue ---
        RTI_aabb_test_and_enqueue<<<grid0, BLOCK_SIZE, 0, cs>>>(
            buf.d_Ox[s], buf.d_Oy[s], buf.d_Oz[s],
            buf.d_Dx[s], buf.d_Dy[s], buf.d_Dz[s],
            n_ray_batch_u,
            buf.d_Xmin, buf.d_Xmax,
            buf.d_Ymin, buf.d_Ymax,
            buf.d_Zmin, buf.d_Zmax,
            (uint32_t)n_sub,
            buf.d_wq_ray_idx_A[s], buf.d_wq_aabb_idx_A[s],
            buf.d_queue_tail[s],
            (uint32_t)queue_capacity);

        // --- Read queue_tail back to host (4 bytes — sync point 1) ---
        CUDA_CHECK(cudaMemcpyAsync(&h_queue_tail[s], buf.d_queue_tail[s],
                                   sizeof(uint32_t), cudaMemcpyDeviceToHost, cs));
        CUDA_CHECK(cudaStreamSynchronize(cs));

        // --- Queue overflow: shrink the batch, never grow the queue ---
        // RTI_enqueue_warp counts every candidate with atomicAdd and only guards
        // the writes, so queue_tail is the exact number of entries this batch
        // needs even when it exceeded capacity. Scaling the chunk by cap/tail
        // makes the batch fit the queue that is already allocated: no
        // reallocation, so this path cannot run out of memory. The shrink is
        // kept for all later batches, so it self-calibrates to the scene and
        // EST_AVG_HITS only has to be a reasonable starting guess.
        while (h_queue_tail[s] > (uint32_t)queue_capacity)
        {
            CUDA_CHECK(cudaStreamSynchronize(buf.stream[0]));
            CUDA_CHECK(cudaStreamSynchronize(buf.stream[1]));

            // 10% margin: the hit rate varies from batch to batch
            double scale = (double)queue_capacity / ((double)h_queue_tail[s] * 1.1);
            size_t new_chunk = (size_t)((double)n_ray_batch * scale);
            new_chunk = (new_chunk / BLOCK_SIZE) * BLOCK_SIZE;

            // Always make progress, even if rounding or a pathological batch
            // would otherwise leave the chunk unchanged
            if (new_chunk == 0 || new_chunk >= n_ray_batch)
                new_chunk = (n_ray_batch / 2 / BLOCK_SIZE) * BLOCK_SIZE;
            if (new_chunk == 0)
                new_chunk = BLOCK_SIZE;

            // One block is the floor. The queue is sized to hold a full block's
            // worst case (BLOCK_SIZE * n_sub), so this is unreachable — but
            // failing loudly beats looping forever or silently dropping entries.
            if (n_ray_batch <= (size_t)BLOCK_SIZE)
                throw std::runtime_error("qd_RTI_CUDA: work queue too small for a single block");

            RTI_DBG("*** OVERFLOW batch %zu: n_ray_batch=%zu tail=%u cap=%zu hits/ray=%.2f -> chunk=%zu\n",
                    batch_idx, n_ray_batch, h_queue_tail[s], queue_capacity,
                    (double)h_queue_tail[s] / (double)(n_ray_batch ? n_ray_batch : 1), new_chunk);

            chunk = new_chunk; // applies to every later batch too
            n_ray_batch = new_chunk;
            n_ray_batch_u = (uint32_t)n_ray_batch;
            grid0 = (n_ray_batch_u + BLOCK_SIZE - 1) / BLOCK_SIZE;

            // The rays are already staged and uploaded; a shorter chunk is just
            // a prefix of what is on the device, so no re-upload is needed.
            RTI_init_per_ray_state<<<grid0, BLOCK_SIZE, 0, cs>>>(
                (uint64_t *)buf.d_fbs_packed[s],
                (uint64_t *)buf.d_sbs_packed[s],
                buf.d_hit_cnt_atomic[s],
                buf.d_queue_tail[s],
                n_ray_batch_u);

            RTI_aabb_test_and_enqueue<<<grid0, BLOCK_SIZE, 0, cs>>>(
                buf.d_Ox[s], buf.d_Oy[s], buf.d_Oz[s],
                buf.d_Dx[s], buf.d_Dy[s], buf.d_Dz[s],
                n_ray_batch_u,
                buf.d_Xmin, buf.d_Xmax,
                buf.d_Ymin, buf.d_Ymax,
                buf.d_Zmin, buf.d_Zmax,
                (uint32_t)n_sub,
                buf.d_wq_ray_idx_A[s], buf.d_wq_aabb_idx_A[s],
                buf.d_queue_tail[s],
                (uint32_t)queue_capacity);

            CUDA_CHECK(cudaMemcpyAsync(&h_queue_tail[s], buf.d_queue_tail[s],
                                       sizeof(uint32_t), cudaMemcpyDeviceToHost, cs));
            CUDA_CHECK(cudaStreamSynchronize(cs));
        }

        // Record what this stream now has in flight (chunk may have shrunk)
        inflight_offset[s] = ray_offset;
        inflight_count[s] = n_ray_batch;

        uint32_t qt = h_queue_tail[s];

        if (batch_idx < 3 || (batch_idx % 25) == 0)
            RTI_DBG("batch %zu: offset=%zu n_ray_batch=%zu tail=%u cap=%zu hits/ray=%.2f\n",
                    batch_idx, ray_offset, n_ray_batch, qt, queue_capacity,
                    (double)qt / (double)(n_ray_batch ? n_ray_batch : 1));

        // --- CUB radix sort: work queue by aabb_idx (Section 6) ---
        // Use DoubleBuffer to avoid explicit input/output management
        cub::DoubleBuffer<uint16_t> d_sort_keys(buf.d_wq_aabb_idx_A[s], buf.d_wq_aabb_idx_B[s]);
        cub::DoubleBuffer<uint32_t> d_sort_vals(buf.d_wq_ray_idx_A[s], buf.d_wq_ray_idx_B[s]);

        if (qt > 0)
        {
            size_t sort_temp_bytes = cub_temp_per_stream;
            cub::DeviceRadixSort::SortPairs(
                buf.d_cub_temp[s], sort_temp_bytes,
                d_sort_keys, d_sort_vals,
                (int)qt,
                0, num_aabb_bits,
                cs);
        }

        // After sort, current buffers:
        uint16_t *sorted_aabb = d_sort_keys.Current();
        uint32_t *sorted_ray = d_sort_vals.Current();

        // --- Kernel 2: Möller–Trumbore FBS ---
        if (qt > 0)
        {
            uint32_t grid2 = (qt + BLOCK_SIZE - 1) / BLOCK_SIZE;
            RTI_moller_trumbore_fbs<<<grid2, BLOCK_SIZE, 0, cs>>>(
                sorted_ray, sorted_aabb, qt,
                buf.d_Ox[s], buf.d_Oy[s], buf.d_Oz[s],
                buf.d_Dx[s], buf.d_Dy[s], buf.d_Dz[s],
                buf.d_Tx, buf.d_Ty, buf.d_Tz,
                buf.d_E1x, buf.d_E1y, buf.d_E1z,
                buf.d_E2x, buf.d_E2y, buf.d_E2z,
                buf.d_SMI,
                buf.d_fbs_packed[s],
                buf.d_hit_cnt_atomic[s],
                buf.d_wq_had_hit[s]);
        }

        // --- CUB compaction: DeviceSelect::Flagged (Section 4.2a) ---
        if (qt > 0)
        {
            cub::CountingInputIterator<uint32_t> iota(0);
            size_t compact_temp_bytes = cub_temp_per_stream;

            cub::DeviceSelect::Flagged(
                buf.d_cub_temp[s], compact_temp_bytes,
                iota,
                buf.d_wq_had_hit[s],
                buf.d_compact_indices[s],
                buf.d_num_selected[s],
                (int)qt,
                cs);
        }
        else
        {
            // No queue entries → zero compacted
            CUDA_CHECK(cudaMemsetAsync(buf.d_num_selected[s], 0, sizeof(uint32_t), cs));
        }

        // Read num_selected to host (4 bytes — sync point 2)
        CUDA_CHECK(cudaMemcpyAsync(&h_num_compact[s], buf.d_num_selected[s],
                                   sizeof(uint32_t), cudaMemcpyDeviceToHost, cs));

        // --- CPU staging window: GPU is busy with sort + K2 + compact ---
        // Stage NEXT batch into pinned memory (overlaps with GPU work)
        size_t next_offset = ray_offset + n_ray_batch;
        if (next_offset < n_ray)
        {
            int next_s = (int)((batch_idx + 1) % 2);
            size_t next_count = std::min(chunk, n_ray - next_offset);
            if constexpr (is_double)
                RTI_stage_ray_input(buf.h_ray_input_pinned_d[next_s], stride, Ox, Oy, Oz, Dx, Dy, Dz, next_offset, next_count);
            else
                RTI_stage_ray_input(buf.h_ray_input_pinned[next_s], stride, Ox, Oy, Oz, Dx, Dy, Dz, next_offset, next_count);
            staged_count = next_count;
        }

        CUDA_CHECK(cudaStreamSynchronize(cs)); // need num_compact for K3 grid

        uint32_t nc = h_num_compact[s];

        // --- Kernel 3: Möller–Trumbore SBS (only compacted work items) ---
        if (nc > 0)
        {
            uint32_t grid3 = (nc + BLOCK_SIZE - 1) / BLOCK_SIZE;
            RTI_moller_trumbore_sbs<<<grid3, BLOCK_SIZE, 0, cs>>>(
                buf.d_compact_indices[s], nc,
                sorted_ray, sorted_aabb,
                buf.d_Ox[s], buf.d_Oy[s], buf.d_Oz[s],
                buf.d_Dx[s], buf.d_Dy[s], buf.d_Dz[s],
                buf.d_Tx, buf.d_Ty, buf.d_Tz,
                buf.d_E1x, buf.d_E1y, buf.d_E1z,
                buf.d_E2x, buf.d_E2y, buf.d_E2z,
                buf.d_SMI,
                buf.d_fbs_packed[s],
                buf.d_sbs_packed[s]);
        }

        // --- Kernel 4: finalize outputs ---
        RTI_finalize_outputs<<<grid0, BLOCK_SIZE, 0, cs>>>(
            buf.d_fbs_packed[s],
            buf.d_sbs_packed[s],
            buf.d_hit_cnt_atomic[s],
            buf.d_Wf[s], buf.d_Ws[s],
            buf.d_If[s], buf.d_Is[s],
            buf.d_hit_cnt[s],
            n_ray_batch_u,
            count_hits);

        // --- D→H: download results ---
        // Layout in pinned output: [Wf | Ws | If | Is | hit_cnt]
        if constexpr (is_double)
        {
            // Convert Wf, Ws float → double on device
            uint32_t grid_cvt = (n_ray_batch_u + BLOCK_SIZE - 1) / BLOCK_SIZE;
            RTI_f2d<<<grid_cvt, BLOCK_SIZE, 0, cs>>>(buf.d_Wf[s], buf.d_Wf_d[s], n_ray_batch_u);
            RTI_f2d<<<grid_cvt, BLOCK_SIZE, 0, cs>>>(buf.d_Ws[s], buf.d_Ws_d[s], n_ray_batch_u);

            // D→H into double-typed pinned output: [Wf_d | Ws_d | If | Is | hit_cnt]
            char *out = buf.h_ray_output_pinned_d[s];
            size_t dW = stride * sizeof(double);
            size_t u4 = stride * sizeof(uint32_t);
            size_t off = 0;
            CUDA_CHECK(cudaMemcpyAsync(out + off, buf.d_Wf_d[s], n_ray_batch * sizeof(double), cudaMemcpyDeviceToHost, cs));
            off += dW;
            CUDA_CHECK(cudaMemcpyAsync(out + off, buf.d_Ws_d[s], n_ray_batch * sizeof(double), cudaMemcpyDeviceToHost, cs));
            off += dW;
            CUDA_CHECK(cudaMemcpyAsync(out + off, buf.d_If[s], n_ray_batch * sizeof(uint32_t), cudaMemcpyDeviceToHost, cs));
            off += u4;
            CUDA_CHECK(cudaMemcpyAsync(out + off, buf.d_Is[s], n_ray_batch * sizeof(uint32_t), cudaMemcpyDeviceToHost, cs));
            off += u4;
            if (count_hits)
                CUDA_CHECK(cudaMemcpyAsync(out + off, buf.d_hit_cnt[s], n_ray_batch * sizeof(uint32_t), cudaMemcpyDeviceToHost, cs));
        }
        else
        {
            // Original float download (unchanged)
            size_t out_off = 0;
            CUDA_CHECK(cudaMemcpyAsync(buf.h_ray_output_pinned[s] + out_off,
                                       buf.d_Wf[s], n_ray_batch * sizeof(float), cudaMemcpyDeviceToHost, cs));
            out_off += stride * sizeof(float);
            CUDA_CHECK(cudaMemcpyAsync(buf.h_ray_output_pinned[s] + out_off,
                                       buf.d_Ws[s], n_ray_batch * sizeof(float), cudaMemcpyDeviceToHost, cs));
            out_off += stride * sizeof(float);
            CUDA_CHECK(cudaMemcpyAsync(buf.h_ray_output_pinned[s] + out_off,
                                       buf.d_If[s], n_ray_batch * sizeof(uint32_t), cudaMemcpyDeviceToHost, cs));
            out_off += stride * sizeof(uint32_t);
            CUDA_CHECK(cudaMemcpyAsync(buf.h_ray_output_pinned[s] + out_off,
                                       buf.d_Is[s], n_ray_batch * sizeof(uint32_t), cudaMemcpyDeviceToHost, cs));
            out_off += stride * sizeof(uint32_t);
            if (count_hits)
                CUDA_CHECK(cudaMemcpyAsync(buf.h_ray_output_pinned[s] + out_off,
                                           buf.d_hit_cnt[s], n_ray_batch * sizeof(uint32_t), cudaMemcpyDeviceToHost, cs));
        }

        ray_offset = next_offset;
    }

    // --- Drain last batch ---
    {
        CUDA_CHECK(cudaStreamSynchronize(buf.stream[last_stream]));

        if constexpr (is_double)
            RTI_unstage_ray_output(buf.h_ray_output_pinned_d[last_stream], stride,
                                   Wf, Ws, If, Is, hit_cnt, count_hits,
                                   inflight_offset[last_stream], inflight_count[last_stream]);
        else
            RTI_unstage_ray_output(buf.h_ray_output_pinned[last_stream], stride,
                                   Wf, Ws, If, Is, hit_cnt, count_hits,
                                   inflight_offset[last_stream], inflight_count[last_stream]);
    }

    RTI_dbg_mem("call end");
    RTI_DBG("=== call done ===\n");

    // RAII destructor handles all cleanup
}

template void qd_RTI_CUDA<float>(const float *, const float *, const float *,
                                 const float *, const float *, const float *, const float *, const float *, const float *,
                                 size_t, const unsigned *,
                                 const float *, const float *, const float *, const float *, const float *, const float *, size_t,
                                 const float *, const float *, const float *, const float *, const float *, const float *, size_t,
                                 float *, float *, unsigned *, unsigned *, unsigned *, int);

template void qd_RTI_CUDA<double>(const double *, const double *, const double *,
                                  const double *, const double *, const double *, const double *, const double *, const double *,
                                  size_t, const unsigned *,
                                  const double *, const double *, const double *, const double *, const double *, const double *, size_t,
                                  const double *, const double *, const double *, const double *, const double *, const double *, size_t,
                                  double *, double *, unsigned *, unsigned *, unsigned *, int);