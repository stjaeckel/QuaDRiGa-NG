// SPDX-License-Identifier: Apache-2.0
// Copyright (C) 2022-2026 Stephan Jaeckel (http://quadriga-lib.org)
// Part of quadriga-lib — see LICENSE for terms.

#include "quadriga_lib.hpp"

// This is supposed to run on 64-bit only
static_assert(sizeof(arma::uword) == sizeof(unsigned long long), "arma::uword and unsigned long long have different sizes");
static_assert(sizeof(size_t) == sizeof(unsigned long long), "size_t and unsigned long long have different sizes");
static_assert(std::is_nothrow_move_constructible_v<quadriga_lib::path>, "path must have a noexcept move ctor, otherwise vector deep-copies on realloc");

// HELPER: Calculate length
static inline float calc_length(float Dx, float Dy, float Dz, // Destination
                                float Ox, float Oy, float Oz) // Origin
{
    float a = Dx - Ox;
    float b = a * a;
    a = Dy - Oy, b += a * a;
    a = Dz - Oz, b += a * a;
    return std::sqrt(b);
}

// HELPER: Calculate direction from O to D
static inline float calc_direction(float Dx, float Dy, float Dz,    // Destination
                                   float Ox, float Oy, float Oz,    // Origin
                                   float &Vx, float &Vy, float &Vz) // Out: normalized direction
{
    Vx = Dx - Ox, Vy = Dy - Oy, Vz = Dz - Oz;
    float len = std::sqrt(Vx * Vx + Vy * Vy + Vz * Vz);
    float scl = (len < 1.0e-30f) ? 0.0f : 1.0f / len;
    Vx *= scl, Vy *= scl, Vz *= scl;
    return len;
}

// HELPER: Vector compaction
template <typename dtype>
static inline arma::Col<dtype> compact(const arma::Col<dtype> &data,
                                       const arma::u32_vec &ind,
                                       arma::uword ind_count)
{
    if (data.empty())
        return arma::Col<dtype>();

    const long long n_ind = (long long)ind_count;
    arma::Col<dtype> out(ind_count, arma::fill::none);

    const dtype *__restrict p_data = data.memptr();
    const arma::u32 *p_ind = ind.memptr();
    dtype *__restrict p_out = out.memptr();

#pragma omp parallel for schedule(static) if (n_ind >= 51200)
    for (long long i = 0; i < n_ind; ++i)
        p_out[i] = p_data[p_ind[i]];

    return out;
}

// HELPER: std::vector compaction
template <typename dtype>
static inline std::vector<dtype> compact(const std::vector<dtype> &data,
                                         const arma::u32_vec &ind,
                                         arma::uword ind_count)
{
    if (data.empty())
        return std::vector<dtype>();

    const long long n_ind = (long long)ind_count;
    std::vector<dtype> out(ind_count);

    const dtype *__restrict p_data = data.data();
    const arma::u32 *p_ind = ind.memptr();
    dtype *__restrict p_out = out.data();

#pragma omp parallel for schedule(static) if (n_ind >= 51200)
    for (long long i = 0; i < n_ind; ++i)
        p_out[i] = p_data[p_ind[i]];

    return out;
}

// Helper: Matrix compaction
template <typename dtype>
static inline arma::Mat<dtype> compact(const arma::Mat<dtype> &data,
                                       const arma::u32_vec &ind, // row or col indices
                                       arma::uword ind_count,    // number of used indices
                                       bool compact_rows = true) // switch for dimension
{
    if (data.empty())
        return arma::Mat<dtype>();

    const long long n_ind = (long long)ind_count;
    const long long n_rows = (long long)data.n_rows;
    const long long n_cols = (long long)data.n_cols;

    arma::Mat<dtype> out(compact_rows ? ind_count : data.n_rows,
                         compact_rows ? data.n_cols : ind_count,
                         arma::fill::none);

    const dtype *__restrict p_data = data.memptr();
    const arma::u32 *p_ind = ind.memptr();
    dtype *__restrict p_out = out.memptr();

    if (compact_rows) // strided gather within each column
    {
#pragma omp parallel for schedule(static) if (n_ind * n_cols >= 51200)
        for (long long i = 0; i < n_ind; ++i)
        {
            const long long src = (long long)p_ind[i];
            for (long long c = 0; c < n_cols; ++c)
                p_out[c * n_ind + i] = p_data[c * n_rows + src];
        }
    }
    else // whole columns are contiguous, copy them in one block
    {
#pragma omp parallel for schedule(static) if (n_ind * n_rows >= 51200)
        for (long long i = 0; i < n_ind; ++i)
            std::memcpy(p_out + i * n_rows,
                        p_data + (long long)p_ind[i] * n_rows,
                        (size_t)n_rows * sizeof(dtype));
    }

    return out;
}

// HELPER: commit a [k, n_out] ray-major launch buffer into an [n_out, k] Armadillo object.
// Source ray i occupies src[k*i .. k*i+k-1]; destination element (i, c) lands at d[i + c*n_out].
// Blocked so the k output streams stay resident while a tile of the source is hot in L1.
template <typename dtype, typename outT>
static inline void commit(outT &out, const dtype *src, arma::uword k, arma::uword n_out)
{
    out.set_size(n_out, k);
    if (n_out == 0 || src == nullptr)
        return;

    dtype *__restrict d = out.memptr();
    const long long n = (long long)n_out;
    const long long kk = (long long)k;

    if (kk == 1) // no transpose needed
    {
        std::memcpy(d, src, (size_t)n * sizeof(dtype));
        return;
    }

    constexpr long long block = 256; // 256 rays x 9 floats = 9 kB, fits L1

#pragma omp parallel for schedule(static) if (n * kk >= 32768)
    for (long long b = 0; b < n; b += block)
    {
        const long long e = (b + block < n) ? b + block : n;
        for (long long c = 0; c < kk; ++c)
        {
            dtype *__restrict dc = d + c * n;
            const dtype *__restrict s = src + kk * b + c;
            for (long long i = b; i < e; ++i, s += kk)
                dc[i] = *s;
        }
    }
}

/*!SECTION
Site-specific simulation tools
SECTION!*/

/*!MD
# ray_progress
Advance a ray set by one interaction, spawning reflected, transmitted, and subdivided rays

- Consumes a launch configuration (origins, destinations, per-ray medium state, and [[path]] storage) and
  returns the next iteration: for every ray that hits the mesh, its reflected and/or transmitted
  continuation(s), plus the four sub-beams of any ray flagged for subdivision. Rays that miss, fall below
  `min_gain_dB`, or reach an interaction, reflection or transmission limit are terminated — unless they
  are flagged for subdivision, which takes precedence and is evaluated first.
- The full pipeline per call is: intersect ([[ray_triangle_intersect]]) → subdivision flag ([[ray_subdivide_flag]])
  → subdivision ([[subdivide_rays]]) → compaction → interaction ([[ray_mesh_interact]]) → state resolve
  ([[ray_state_update]]) for a reflection pass and a transmission/refraction pass → assembly.
- The subdivision decision is taken on the full ray set, before the interaction is evaluated and before the
  launch configuration is compacted. A flagged ray is split and does not take part in the interaction passes
  this generation; its sub-beams are re-intersected in the next one.
- The function returns per-stage counts (see Returns); the new configuration holds `n_out = 4·n_subdiv + n_reflect + n_transmit`
  rays, which may exceed or fall short of the `n_ray` passed in.
- An empty returned launch configuration (`orig.n_rows == 0`) signals end of trace; a subsequent call with an empty orig throws.
- Memory is sized for the worst case but committed lazily: the output is built in a worst-case-sized buffer
  committed on first write, the launch configuration is compacted once — on the intersect result and the
  subdivision flag together — before the expensive passes, and dead intermediates are released as the
  function proceeds, so peak footprint stays close to one generation.
  Designed for `n_ray` up to ~10^8; the ray index is 32-bit, so `n_ray` is capped at 2^32-1.
- Geometry is traced once, at the reference frequency `center_frequency[0]`. For the remaining frequencies
  only the polarization/gain coefficient is recomputed and folded into each [[path]]; the per-frequency
  refracted direction and in-medium distance are approximated by the reference-frequency values (see the
  note on `center_frequency`).
- Beam subdivision and beam-front updates are active only when `trivec` and `tridir` are supplied;
  otherwise rays are traced as infinitesimal.
- The ray-mesh intersection can be delegated: pass `no_interact_in`, `fbs_ind_in` and `sbs_ind_in`
  to reuse a [[ray_triangle_intersect]] result. When the intersection is delegated, `sub_mesh_index` and `aabb` are unused —
  they only accelerate the internal intersector — validation is skipped in this case and the parameters may be omitted.
- The subdivision decision can likewise be delegated via `subdiv_flag_in`, which a shading pass needs so it
  does not commit beams that reappear as sub-beams. When supplied it is the authority on what gets split;
  see the input description for what that overrides.
- [[ray_subdivide_flag]] never flags a ray with `fbs_ind` = 0, because there is no face to project the beam
  tube onto. The internal decision therefore never subdivides a ray that missed the mesh; only a delegated
  flag reaches that case.

## Declaration:
```
std::array<unsigned, 4> quadriga_lib::ray_progress(
    const arma::fmat &mesh,
    const arma::uvec &mtl_ind,
    const std::unordered_map<std::string, std::vector<float>> &mtl_prop,
    const arma::fvec &center_frequency,
    float Ox, float Oy, float Oz,
    arma::fmat &orig,
    arma::fmat &dest,
    arma::Col<short> &mtl_ind_prev,
    arma::Col<short> &mtl_ind_current,
    arma::Col<short> &mtl_ind_buffer,
    arma::fcube &path_dir_prev,
    arma::fmat &acc_dist,
    std::vector<quadriga_lib::path> &paths,
    arma::fmat *trivec = nullptr,
    arma::fmat *tridir = nullptr,
    const arma::u32_vec *sub_mesh_index = nullptr,
    const arma::fmat *aabb = nullptr,
    uint8_t max_no_interactions = 20,
    uint8_t max_no_reflections = 10,
    uint8_t max_no_transmissions = 10,
    uint8_t max_no_subdivisions = 2,
    float min_gain_dB = -140.0f,
    float subdivision_tolerance_m = 3.0f,
    float thin_slab_threshold = 0.15f,
    bool refraction_mode = true,
    bool scalar_mode = false,
    const arma::u32_vec *no_interact_in = nullptr,
    const arma::u32_vec *fbs_ind_in = nullptr,
    const arma::u32_vec *sbs_ind_in = nullptr,
    const std::vector<bool> *subdiv_flag_in = nullptr);
```

## Inputs:
- **`mesh`** — Triangle mesh faces; see [[obj_file_read]]; `[n_mesh, 9]`
- **`mtl_ind`** — 1-based material index per face (the `csv_ind` output of [[obj_file_read]]); `[n_mesh]`. 0 = air
- **`mtl_prop`** — Material properties keyed by column name (the `csv_prop` output of [[obj_file_read]]); each value has length `n_mtl` (max 16383)
- **`center_frequency`** — Center frequencies in [Hz]; `[n_freq]`, 1 to 127 entries. `center_frequency[0]` is the reference frequency that defines the traced geometry
- **`Ox`**, **`Oy`**, **`Oz`** — Point-source (transmitter) position in GCS [m]; used to recompute path length at new sub-beam origins
- **`sub_mesh_index`** *(optional)* — Sub-mesh partition offsets for the accelerated intersect; 0-based, strictly increasing,
  first entry 0; passed to [[ray_triangle_intersect]]; `[n_sub]`. NULL → no partitioning
- **`aabb`** *(optional)* — Axis-aligned bounding box per sub-mesh; `[n_sub, 6]`. Requires `sub_mesh_index`.
  NULL with a partition present → boxes are computed internally via [[triangle_mesh_aabb]]
- **`max_no_interactions`** — Total interactions (segments) per ray before termination, 0 to 255. 0 disables tracing (returns 0 rays)
- **`max_no_reflections`** — Reflections per ray, 0 to 255. 0 skips the reflection pass
- **`max_no_transmissions`** — Transmissions / refractions per ray, 0 to 255. 0 skips the transmission pass
- **`max_no_subdivisions`** — Beam subdivisions per ray, 0 to 255. 0 (or no beam mode) disables subdivision.
  Not applied when `subdiv_flag_in` is given — the caller owns termination in that case, and the per-path
  counter `nSUB` saturates at 255 instead of wrapping
- **`min_gain_dB`** — Path gain below which a continuation is not launched, in dB (linear-power threshold applied to the accumulated per-path gain × interaction gain)
- **`subdivision_tolerance_m`** — Maximum beam-tube edge length before a ray is subdivided, in [m]; must be > 0
- **`thin_slab_threshold`** — Thin-slab (Fabry-Pérot) resolve threshold forwarded to [[ray_state_update]] as its `eps`; see there. Default 0.15
- **`refraction_mode`** — `true` = refraction (Snell-bent transmission), `false` = straight-path transmission
- **`scalar_mode`** — `true` = scalar (acoustic) layout, `false` = EM (2×2 Jones). Must match the layout of `paths`
- **`no_interact_in`** *(optional)* — Externally computed intersection count per ray from [[ray_triangle_intersect]]; `[n_ray]`.
  When given, the internal intersector is skipped and `fbs_ind_in` and `sbs_ind_in` become mandatory
- **`fbs_ind_in`** *(optional)* — Externally computed 1-based index of the first intersected mesh element, 0 = none; `[n_ray]`.
  Must be non-zero wherever `no_interact_in` is non-zero.
- **`sbs_ind_in`** *(optional)* — Externally computed 1-based index of the second intersected mesh element, 0 = none; `[n_ray]`
- **`subdiv_flag_in`** *(optional)* — Flags that mark rays for subdivision; `[n_ray]`, indexed in the full ray
  set (unlike everything else, which is compacted first). When supplied it is the authority on what gets
  subdivided: a flagged ray is split regardless of whether it hit the mesh, how often it has already been
  subdivided, or whether it is travelling inside a medium, and `subdivision_tolerance_m` is unused. Pass the
  output of [[ray_subdivide_flag]] to reproduce the internal decision exactly; a hand-built list overrides it.
  Requires beam mode; conflicts with `max_no_subdivisions` = 0

## In/out (launch configuration, updated in place; [n_ray, …] on entry, [n_out, …] on return):
- **`orig`** — Ray origins in GCS; `[n_ray, 3]`. Defines `n_ray`; must be non-empty
- **`dest`** — Ray destinations in GCS; `[n_ray, 3]`
- **`mtl_ind_prev`**, **`mtl_ind_current`**, **`mtl_ind_buffer`** — Medium-state words (bit-masked: `mat = w & 0x3FFF`, flags in bits 14 and 15, see [[ray_state_update]]); `[n_ray]`
- **`path_dir_prev`** — Physical ray direction entering the current segment (unit vectors), one slice per
  frequency; `[n_ray, 3, n_freq]`. The Snell bend that defines this direction depends on the material at the
  evaluation frequency, so a dispersive medium gives a different direction in every slice. Outside a medium
  all slices hold the same geometric direction
- **`acc_dist`** — Accumulated in-layer distance; `[n_ray, 1 + n_freq]`; col 0 = geometric distance,
  col `1+f` = refracted distance at frequency `f`. The geometric column is shared because the traced polyline
  is the base-frequency geometry by construction; only the refracted length varies with frequency. Inside a
  medium both include the relaunch offset of the last event (a few float ulp of the coordinate, about 1 µm
  per metre), so the leg the next event measures from `orig` adds up to the leg from the hit point
- **`paths`** — Per-ray [[path]] objects; `n_ray` entries. Frequency count and layout must match
  `center_frequency` and `scalar_mode`. Terminated paths are freed; surviving paths carry the appended
  interaction segment and the updated polarization product
- **`trivec`** *(optional)* — Beam wavefront triangle vertices relative to origin; `[n_ray, 9]`. Must be supplied together with `tridir`; empty / NULL disables beam tracing
- **`tridir`** *(optional)* — Vertex-ray directions, Cartesian; `[n_ray, 9]`

## Returns:
- Per-stage ray counts `{n_interact, n_subdiv, n_reflect, n_transmit}`:
  - **`n_interact`** — rays that hit the mesh, i.e. `no_interact != 0`, counted before any compaction
  - **`n_subdiv`** — rays flagged for subdivision, each expanded into 4 sub-beams. Not a subset of
    `n_interact`: a delegated flag may mark rays that missed the mesh, so the two counts are independent
  - **`n_reflect`** — reflected continuations launched
  - **`n_transmit`** — transmitted / refracted continuations launched
- Only rays that hit the mesh *and* were not subdivided reach the interaction passes, so
  `n_reflect + n_transmit` is bounded by twice that number, not by `2·n_interact`.

## See also:
- [[ray_init]] (produces the initial launch configuration this function advances)
- [[ray_triangle_intersect]] (first/second interaction points)
- [[ray_mesh_interact]] (per-interaction Fresnel/Jones result)
- [[ray_state_update]] (inside/outside state machine and thin-slab resolution)
- [[ray_subdivide_flag]] (per-ray subdivision decision, delegated via `subdiv_flag_in`)
- [[subdivide_rays]] (adaptive beam-tube refinement)
- [[path]] (per-ray storage object accumulated across generations)
MD!*/

std::array<unsigned, 4> quadriga_lib::ray_progress(const arma::fmat &mesh,
                                                   const arma::uvec &mtl_ind,
                                                   const std::unordered_map<std::string, std::vector<float>> &mtl_prop,
                                                   const arma::fvec &center_frequency,
                                                   float Ox, float Oy, float Oz,
                                                   arma::fmat &orig,
                                                   arma::fmat &dest,
                                                   arma::Col<short> &mtl_ind_prev,
                                                   arma::Col<short> &mtl_ind_current,
                                                   arma::Col<short> &mtl_ind_buffer,
                                                   arma::fcube &path_dir_prev,
                                                   arma::fmat &acc_dist,
                                                   std::vector<quadriga_lib::path> &paths,
                                                   arma::fmat *trivec,
                                                   arma::fmat *tridir,
                                                   const arma::u32_vec *sub_mesh_index,
                                                   const arma::fmat *aabb,
                                                   uint8_t max_no_interactions,
                                                   uint8_t max_no_reflections,
                                                   uint8_t max_no_transmissions,
                                                   uint8_t max_no_subdivisions,
                                                   float min_gain_dB,
                                                   float subdivision_tolerance_m,
                                                   float thin_slab_threshold,
                                                   bool refraction_mode,
                                                   bool scalar_mode,
                                                   const arma::u32_vec *no_interact_in,
                                                   const arma::u32_vec *fbs_ind_in,
                                                   const arma::u32_vec *sbs_ind_in,
                                                   const std::vector<bool> *subdiv_flag_in)
{
    // Mesh validation
    const arma::uword n_mesh = mesh.n_rows;
    if (n_mesh == 0)
        throw std::invalid_argument("Input 'mesh' cannot be empty.");
    if (mesh.n_cols != 9)
        throw std::invalid_argument("Input 'mesh' must have 9 columns containing x,y,z coordinates of 3 vertices.");
    if (mtl_ind.n_elem != n_mesh)
        throw std::invalid_argument("Length of 'mtl_ind' must match the number of mesh faces.");

    // Delegated ray-mesh intersection: all three arrays or none
    bool run_intersector = (no_interact_in == nullptr && fbs_ind_in == nullptr && sbs_ind_in == nullptr);
    if (!run_intersector && (no_interact_in == nullptr || fbs_ind_in == nullptr || sbs_ind_in == nullptr))
        throw std::invalid_argument("Inputs 'no_interact_in', 'fbs_ind_in' and 'sbs_ind_in' must be provided together.");

    // Validate mtl_prop
    arma::uword n_mtl = 0;
    for (const auto &kv : mtl_prop)
        if (!kv.second.empty())
        {
            n_mtl = (arma::uword)kv.second.size();
            break;
        }
    if (n_mtl > 16383) // the state words carry a 14-bit material index
        throw std::invalid_argument("Number of materials cannot exceed 16383.");
    if (mtl_ind.max() > n_mtl)
        throw std::invalid_argument("Entries of 'mtl_ind' cannot exceed the number of materials.");

    // Frequencies; the path storage layout supports 1 to 127 frequencies
    const arma::uword n_freq = center_frequency.n_elem;
    if (n_freq == 0)
        throw std::invalid_argument("Input 'center_frequency' cannot be empty.");
    if (n_freq > 127)
        throw std::invalid_argument("Input 'center_frequency' cannot have more than 127 elements.");
    if (center_frequency.min() <= 0.0f)
        throw std::invalid_argument("Input 'center_frequency' must be > 0.");
    float fRef_Hz = center_frequency[0];
    float fRef_GHz = fRef_Hz * 1e-9f;

    // Ray count is defined by 'orig'; all other per-ray inputs must match it
    const arma::uword n_ray = orig.n_rows;
    if (n_ray == 0)
        throw std::invalid_argument("Input 'orig' cannot be empty.");
    if (orig.n_cols != 3)
        throw std::invalid_argument("Input 'orig' must have 3 columns.");
    if (n_ray > 4294967295ull)
        throw std::invalid_argument("Number of rays cannot exceed 2^32-1.");

    if (dest.n_rows != n_ray || dest.n_cols != 3)
        throw std::invalid_argument("Input 'dest' must have size [n_ray, 3].");

    // Medium state words, bit-masked (mat = w & 0x3FFF, flags in bits 14 and 15), so negative values are legal
    if (mtl_ind_prev.n_elem != n_ray)
        throw std::invalid_argument("Input 'mtl_ind_prev' must have n_ray elements.");

    if (mtl_ind_current.n_elem != n_ray)
        throw std::invalid_argument("Input 'mtl_ind_current' must have n_ray elements.");

    if (mtl_ind_buffer.n_elem != n_ray)
        throw std::invalid_argument("Input 'mtl_ind_buffer' must have n_ray elements.");

    if (path_dir_prev.n_rows != n_ray || path_dir_prev.n_cols != 3 || path_dir_prev.n_slices != n_freq)
        throw std::invalid_argument("Input 'path_dir_prev' must have size [n_ray, 3, n_freq].");

    if (acc_dist.n_rows != n_ray || acc_dist.n_cols != 1 + n_freq)
        throw std::invalid_argument("Input 'acc_dist' must have size [n_ray, 1+n_freq].");

    // Path storage must match the ray count and the requested layout
    if (paths.size() != n_ray)
        throw std::invalid_argument("Input 'paths' must have n_ray elements.");

    if (paths[0].n_freq() != n_freq) // Quick check first path, deep check later
        throw std::invalid_argument("Number of frequencies in 'paths' must match 'center_frequency'.");
    if (paths[0].is_scalar() != scalar_mode)
        throw std::invalid_argument("Layout of 'paths' must match 'scalar_mode'.");
    const arma::uword nXPR = scalar_mode ? 2 : 8;

    // Optional beam tracing; 'trivec' and 'tridir' must be given together
    const bool has_trivec = trivec && trivec->n_elem != 0;
    const bool has_tridir = tridir && tridir->n_elem != 0;
    const bool beam_mode = has_trivec || has_tridir;

    if (beam_mode && (!has_trivec || !has_tridir))
        throw std::invalid_argument("Inputs 'trivec' and 'tridir' must be provided together.");

    if (beam_mode)
    {
        if (trivec->n_rows != n_ray || trivec->n_cols != 9)
            throw std::invalid_argument("Input 'trivec' must have size [n_ray, 9].");

        if (tridir->n_rows != n_ray || tridir->n_cols != 9)
            throw std::invalid_argument("Input 'tridir' must have size [n_ray, 9] (Cartesian).");
    }

    // Optional sub-mesh partitioning, 0-based start indices into the mesh rows
    arma::uword n_sub = 0;
    if (run_intersector && sub_mesh_index && sub_mesh_index->n_elem != 0)
    {
        n_sub = sub_mesh_index->n_elem;
        const unsigned *p_sub = sub_mesh_index->memptr();

        if (p_sub[0] != 0u)
            throw std::invalid_argument("First element of 'sub_mesh_index' must be 0.");

        for (arma::uword i_sub = 0; i_sub < n_sub; ++i_sub)
        {
            if ((arma::uword)p_sub[i_sub] >= n_mesh)
                throw std::invalid_argument("Entries of 'sub_mesh_index' cannot exceed the number of mesh faces.");
            if (i_sub != 0 && p_sub[i_sub] <= p_sub[i_sub - 1])
                throw std::invalid_argument("Entries of 'sub_mesh_index' must be strictly increasing.");
        }
    }

    // Optional axis-aligned bounding boxes, one per sub-mesh
    arma::fmat aabb_local;
    const arma::fmat *aabb_ptr = nullptr;
    if (run_intersector && aabb && aabb->n_elem != 0)
    {
        if (n_sub == 0)
            throw std::invalid_argument("Input 'aabb' requires 'sub_mesh_index'.");
        if (aabb->n_rows != n_sub || aabb->n_cols != 6)
            throw std::invalid_argument("Input 'aabb' must have size [n_sub, 6].");
        aabb_ptr = aabb;
    }
    else if (n_sub)
    {
        aabb_local = quadriga_lib::triangle_mesh_aabb(&mesh, sub_mesh_index);
        aabb_ptr = &aabb_local;
    }

    if (!std::isfinite(min_gain_dB))
        throw std::invalid_argument("Input 'min_gain_dB' must be finite.");
    float min_gain_linear = std::pow(10.0f, 0.1f * min_gain_dB);

    if (subdivision_tolerance_m <= 0.0f)
        throw std::invalid_argument("Input 'subdivision_tolerance_m' must be > 0.");

    if (thin_slab_threshold < 0.0f || thin_slab_threshold > 1.0f)
        throw std::invalid_argument("Input 'thin_slab_threshold' must be >= 0 and <= 1.");

    // Validate optional inputs, deep-check done by ray_mesh_interact
    if (!run_intersector)
    {
        if (no_interact_in->n_elem != n_ray)
            throw std::invalid_argument("Number of elements in 'no_interact_in' does not match number of rows in 'orig'.");
        if (fbs_ind_in->n_elem != n_ray)
            throw std::invalid_argument("Number of elements in 'fbs_ind_in' does not match number of rows in 'orig'.");
        if (sbs_ind_in->n_elem != n_ray)
            throw std::invalid_argument("Number of elements in 'sbs_ind_in' does not match number of rows in 'orig'.");
    }

    // Delegated subdivision flag. Unlike the intersect arrays this one stays in full-ray-set indexing
    // throughout: the subdivision runs before the compaction.
    if (subdiv_flag_in)
    {
        if (subdiv_flag_in->size() != n_ray)
            throw std::invalid_argument("Number of elements in 'subdiv_flag_in' does not match number of rows in 'orig'.");
        if (!beam_mode)
            throw std::invalid_argument("Input 'subdiv_flag_in' requires beam mode ('trivec' and 'tridir').");
        if (max_no_subdivisions == 0)
            throw std::invalid_argument("Input 'subdiv_flag_in' conflicts with 'max_no_subdivisions' = 0.");
    }

    // Launch config data
    // Buffers are allocated once at the worst case and never grow. "new T[n]" (no parens)
    // default-initializes, so the POD arrays are not zero-filled and untouched pages stay
    // uncommitted on Linux; resize() only advances the committed ray count.
    // NOTE: nothing pre-clears these buffers, so every committed slot MUST be fully written
    // before it is read. Subdivision writes [0, 4*n_subdiv), each update_launch_config pass
    // writes [offset, offset+n_rays); trivec/tridir are only touched in beam mode.
    struct launch_config
    {
        std::unique_ptr<float[]> orig, dest, trivec, tridir, path_dir_prev, acc_dist;
        std::unique_ptr<short[]> mtl_ind_prev, mtl_ind_current, mtl_ind_buffer;
        std::vector<quadriga_lib::path> paths; // std::vector so the caller can steal it with one move

        size_t n_max = 0;  // reserved ray slots
        size_t n_used = 0; // committed ray slots
        size_t nf = 1;     // frequency count, sets the per-ray stride of path_dir_prev and acc_dist
        bool beam_mode_flag = false;

        size_t size() const { return n_used; }

        launch_config(size_t sz, size_t n_freq, bool beam_mode = true) : n_max(sz), nf(n_freq), beam_mode_flag(beam_mode)
        {
            orig.reset(new float[3 * sz]);
            dest.reset(new float[3 * sz]);
            if (beam_mode)
                trivec.reset(new float[9 * sz]), tridir.reset(new float[9 * sz]);
            mtl_ind_prev.reset(new short[sz]);
            mtl_ind_current.reset(new short[sz]);
            mtl_ind_buffer.reset(new short[sz]);
            path_dir_prev.reset(new float[3 * n_freq * sz]);
            acc_dist.reset(new float[(1 + n_freq) * sz]);
            paths.reserve(sz);
        }

        void resize(size_t sz) // Commit ray slots; the memory is already there
        {
            if (sz < n_used)
                throw std::invalid_argument("Launch buffer size cannot shrink.");
            if (sz > n_max)
                throw std::logic_error("Launch buffer exceeds reserved worst case.");

            paths.resize(sz);
            n_used = sz;
        }

        // Raw pointers
        float *origP(size_t offset = 0) { return orig.get() + 3 * offset; }
        float *destP(size_t offset = 0) { return dest.get() + 3 * offset; }
        float *trivecP(size_t offset = 0) { return beam_mode_flag ? trivec.get() + 9 * offset : nullptr; }
        float *tridirP(size_t offset = 0) { return beam_mode_flag ? tridir.get() + 9 * offset : nullptr; }
        short *prevP(size_t offset = 0) { return mtl_ind_prev.get() + offset; }
        short *currentP(size_t offset = 0) { return mtl_ind_current.get() + offset; }
        short *bufferP(size_t offset = 0) { return mtl_ind_buffer.get() + offset; }
        float *dirP(size_t offset = 0) { return path_dir_prev.get() + 3 * nf * offset; }
        float *accP(size_t offset = 0) { return acc_dist.get() + (1 + nf) * offset; }
        quadriga_lib::path *pathP(size_t offset = 0) { return paths.data() + offset; }
    };

    // Ray-mesh intersections: computed here, or supplied by the caller
    arma::u32_vec no_interact, fbs_ind, sbs_ind; // FBS and SBS indices, 1-based, 0 = no hit
    std::vector<bool> subdiv_flag;               // Internally computed flag, empty when delegated

    const arma::u32_vec *p_ni = nullptr; // Intersect count, full ray set
    const arma::u32_vec *p_fi = nullptr; // FBS face index, full ray set
    const arma::u32_vec *p_si = nullptr; // SBS face index, full ray set
    const std::vector<bool> *p_sf = nullptr;
    bool has_flag = false;

    arma::uword n_hit = 0;    // Rays that hit the mesh, reported as n_interact
    arma::uword n_subdiv = 0; // Rays flagged for subdivision, may or may not have hit
    arma::uword n_keep = 0;   // Rays that hit and were not subdivided, i.e. go to the interaction passes

    if (max_no_interactions) // 0 disables tracing outright, no intersect and no subdivision
    {
        if (run_intersector)
            quadriga_lib::ray_triangle_intersect<float>(&orig, &dest, &mesh, nullptr, nullptr, &no_interact,
                                                        &fbs_ind, &sbs_ind, sub_mesh_index, aabb_ptr);

        // Delegated arrays are read in place, never copied
        p_ni = run_intersector ? &no_interact : no_interact_in;
        p_fi = run_intersector ? &fbs_ind : fbs_ind_in;
        p_si = run_intersector ? &sbs_ind : sbs_ind_in;

        // Flag rays for subdivision, in full-ray-set indexing. The decision needs only the launch
        // configuration and the FBS face, so it is taken before the interaction is evaluated.
        // ray_subdivide_flag never flags a ray with fbs_ind == 0 (no face to project the beam tube
        // onto), so the internal decision never subdivides a ray that missed the mesh. A delegated
        // flag is authoritative and may.
        if (beam_mode && max_no_subdivisions && subdiv_flag_in == nullptr)
            subdiv_flag = quadriga_lib::ray_subdivide_flag(mesh, orig, dest, *p_fi, *trivec, *tridir,
                                                           paths, mtl_ind_current, max_no_interactions,
                                                           max_no_subdivisions, subdivision_tolerance_m);

        p_sf = (subdiv_flag_in != nullptr) ? subdiv_flag_in : &subdiv_flag;
        has_flag = (p_sf->size() == n_ray);

        // Pass 1: count. Reading a bit-packed vector concurrently is safe, writing it is not.
        // The induction variable must be signed for OpenMP 2.0; the reduction variables need not be.
        const arma::u32 *p_ni_m = p_ni->memptr();

#pragma omp parallel for schedule(static) reduction(+ : n_hit, n_subdiv, n_keep) if (n_ray >= 51200)
        for (long long i = 0; i < (long long)n_ray; ++i)
        {
            const bool hit = p_ni_m[i] != 0u;
            const bool sub = has_flag && (*p_sf)[(size_t)i];
            n_hit += hit ? 1u : 0u;
            n_subdiv += sub ? 1u : 0u;
            n_keep += (hit && !sub) ? 1u : 0u;
        }
    }

    if (n_hit == 0 && n_subdiv == 0) // Nothing continues, all paths are terminated
    {
        orig.set_size(0, 3);
        dest.set_size(0, 3);
        mtl_ind_prev.reset();
        mtl_ind_current.reset();
        mtl_ind_buffer.reset();
        path_dir_prev.set_size(0, 3, n_freq);
        acc_dist.set_size(0, 1 + n_freq);
        if (beam_mode)
            trivec->set_size(0, 9), tridir->set_size(0, 9);
        paths.clear();
        paths.shrink_to_fit(); // Release the 64 byte per ray headers
        return std::array<unsigned, 4>();
    }

    // Pass 2: scatter into the two disjoint index lists, both in full-ray-set indexing. Serial, the
    // write cursors are a running prefix sum. Sizing both exactly keeps their combined footprint at
    // 4 bytes per ray. Rays that neither continue nor subdivide release their path data here: they
    // would otherwise stay alive until the compaction below, which is well past the subdivision.
    arma::u32_vec subdiv_ind, keep_ind;
    subdiv_ind.set_size(n_subdiv);
    keep_ind.set_size(n_keep);
    {
        const arma::u32 *p_ni_m = p_ni->memptr();
        unsigned *p_subdiv_ind = subdiv_ind.memptr();
        unsigned *p_keep_ind = keep_ind.memptr();
        arma::uword c_sub = 0, c_keep = 0;

        for (arma::uword i = 0; i < n_ray; ++i)
            if (has_flag && (*p_sf)[(size_t)i])
                p_subdiv_ind[c_sub++] = (unsigned)i;
            else if (p_ni_m[i])
                p_keep_ind[c_keep++] = (unsigned)i;
            else
                paths[i].free();
    }
    p_sf = nullptr;
    std::vector<bool>().swap(subdiv_flag); // deallocate, the index lists carry the decision now

    // Buffer for the next state
    // Worst case: every sub-beam plus a reflected and a transmitted continuation per kept ray.
    // n_subdiv is no longer a subset of the rays that hit, so the two counts are independent.
    arma::uword n_out_max = 4 * n_subdiv + 2 * n_keep;
    auto L = launch_config(n_out_max, (size_t)n_freq, beam_mode); // Allocate worst case, commit lazily

    // Subdivision
    if (n_subdiv)
    {
        // Commit ray slots
        L.resize(4 * n_subdiv);

        // Subdivision of origs, dest, trivec, tridir
        arma::fmat L_orig(L.origP(), 3, 4 * n_subdiv, false, true);
        arma::fmat L_dest(L.destP(), 3, 4 * n_subdiv, false, true);
        arma::fmat L_trivec(L.trivecP(), 9, 4 * n_subdiv, false, true);
        arma::fmat L_tridir(L.tridirP(), 9, 4 * n_subdiv, false, true);
        const arma::u32_vec subdiv_ind_view(subdiv_ind.memptr(), n_subdiv, false, true);
        quadriga_lib::subdivide_rays<float>(orig, *trivec, *tridir, &dest, &L_orig, &L_trivec, &L_tridir, &L_dest, &subdiv_ind_view, true);

        // Read pointers. All source arrays are still the full ray set here, so the column stride
        // is n_ray and p_subdiv_ind holds full-ray-set indices.
        const unsigned *p_subdiv_ind = subdiv_ind.memptr(); // i_subdiv to i_ray map
        const float *p_orig = L.origP();                    // Updated origins
        const float *p_dest = L.destP();                    // Updated destinations
        const short *cP = mtl_ind_prev.memptr();
        const short *cC = mtl_ind_current.memptr();
        const short *cB = mtl_ind_buffer.memptr();
        const float *pD = path_dir_prev.memptr();
        const float *pA = acc_dist.memptr();

        // Write pointers
        short *pP = L.prevP();
        short *pC = L.currentP();
        short *pB = L.bufferP();
        float *p_dir = L.dirP();
        float *p_acc = L.accP();

        // Update path storage, state words, directions
#pragma omp parallel for schedule(static) if (n_subdiv >= 64)
        for (long long i_subdiv = 0; i_subdiv < (long long)n_subdiv; ++i_subdiv)
        {
            const arma::uword i_ray = p_subdiv_ind[i_subdiv]; // Ray index, full ray set
            size_t n_seg = paths[i_ray].n_seg();
            const bool outside = (cC[i_ray] == 0); // Travelling outside a medium

            // Create the 4 sub-beams
            for (arma::uword i_sub = 0; i_sub < 4; ++i_sub)
            {
                const arma::uword i_out = 4 * (arma::uword)i_subdiv + i_sub; // Index of the ray in the output
                const arma::uword i_out3 = 3 * i_out;

                L.paths[i_out] = paths[i_ray]; // Deep copy (copy assignment)

                // Increase subdivision counter. A delegated subdiv_flag_in is authoritative and does
                // not apply max_no_subdivisions, so saturate rather than wrap: a wrapped nSUB reads
                // as 0 and would let the same beam be split without bound.
                if (L.paths[i_out].nSUB != 255)
                    ++L.paths[i_out].nSUB;

                // New origin at subdivision point
                float Sx = p_orig[i_out3];
                float Sy = p_orig[i_out3 + 1];
                float Sz = p_orig[i_out3 + 2];

                if (n_seg) // Update last interaction point
                {
                    float *crd = L.paths[i_out].coord(n_seg - 1);
                    crd[0] = Sx, crd[1] = Sy, crd[2] = Sz;
                }

                // Update length
                float length = (n_seg <= 1) ? calc_length(Sx, Sy, Sz, Ox, Oy, Oz)
                                            : L.paths[i_out].calc_length(Sx, Sy, Sz, Ox, Oy, Oz);
                L.paths[i_out].set_length(length);

                // Copy interaction state
                pP[i_out] = cP[i_ray];
                pC[i_out] = cC[i_ray];
                pB[i_out] = cB[i_ray];

                // Outside a medium the physical direction is the geometric one, so every sub-beam
                // gets its own recomputed direction and a cleared in-object accumulator. Inside a
                // medium the tracked direction is the refracted one and deliberately differs from
                // the geometric continuation, and the accumulator holds both in-layer distances
                // travelled so far, so all are inherited from the parent. ray_subdivide_flag only
                // ever flags rays outside a medium, but a delegated subdiv_flag_in is authoritative
                // and may flag either state, so both branches are reachable.
                const size_t dbase = 3 * (size_t)n_freq * i_out; // path_dir_prev, ray-major, 3 floats per frequency
                const size_t abase = (1 + (size_t)n_freq) * i_out; // acc_dist, geometric then one per frequency

                if (outside)
                {
                    float Vx, Vy, Vz;
                    calc_direction(p_dest[i_out3], p_dest[i_out3 + 1], p_dest[i_out3 + 2], Sx, Sy, Sz, Vx, Vy, Vz);
                    p_acc[abase] = 0.0f;
                    for (arma::uword f = 0; f < n_freq; ++f) // Outside, every frequency shares the geometric direction
                    {
                        p_dir[dbase + 3 * f] = Vx;
                        p_dir[dbase + 3 * f + 1] = Vy;
                        p_dir[dbase + 3 * f + 2] = Vz;
                        p_acc[abase + 1 + f] = 0.0f;
                    }
                }
                else
                {
                    p_acc[abase] = pA[i_ray];
                    for (arma::uword f = 0; f < n_freq; ++f)
                    {
                        p_dir[dbase + 3 * f] = pD[i_ray + (3 * f) * n_ray];
                        p_dir[dbase + 3 * f + 1] = pD[i_ray + (3 * f + 1) * n_ray];
                        p_dir[dbase + 3 * f + 2] = pD[i_ray + (3 * f + 2) * n_ray];
                        p_acc[abase + 1 + f] = pA[i_ray + (1 + f) * n_ray];
                    }
                }
            }

            // The 4 deep copies are done and a subdivided ray is never kept, so the parent path
            // data is dead. Releasing it here keeps it out of the compaction below.
            paths[i_ray].free();
        }
    }
    subdiv_ind.reset(); // No longer needed

    // Compact the launch configuration onto the rays that continue: hit the mesh and were not
    // subdivided. This is the only compaction in the pipeline. Because it is unconditional, no ray
    // in the compacted set is subdivided, so the subdivision flag is not needed downstream.
    // Source and target are the same object for no_interact / fbs_ind / sbs_ind when the intersector
    // ran here; compact() completes its result before the move-assignment, so the read finishes
    // first. p_ni / p_fi / p_si are dangling after this point.
    orig = compact(orig, keep_ind, n_keep);
    dest = compact(dest, keep_ind, n_keep);
    mtl_ind_prev = compact(mtl_ind_prev, keep_ind, n_keep);
    mtl_ind_current = compact(mtl_ind_current, keep_ind, n_keep);
    mtl_ind_buffer = compact(mtl_ind_buffer, keep_ind, n_keep);
    // path_dir_prev is a cube [n_ray, 3, n_freq] whose memory is identical to an [n_ray, 3*n_freq]
    // matrix, so compact it through an alias and work on the matrix from here on. Slice f then lives
    // in columns 3f..3f+2, which stays contiguous and lets each per-frequency call take a view.
    arma::fmat dir_prev;
    {
        const arma::fmat dir_view(path_dir_prev.memptr(), n_ray, 3 * n_freq, false, true);
        dir_prev = compact(dir_view, keep_ind, n_keep);
    }
    path_dir_prev.reset(); // Rebuilt from the launch buffer at the end
    acc_dist = compact(acc_dist, keep_ind, n_keep);
    no_interact = compact(*p_ni, keep_ind, n_keep);
    fbs_ind = compact(*p_fi, keep_ind, n_keep);
    sbs_ind = compact(*p_si, keep_ind, n_keep);
    p_ni = nullptr, p_fi = nullptr, p_si = nullptr;

    if (beam_mode)
    {
        *trivec = compact(*trivec, keep_ind, n_keep);
        *tridir = compact(*tridir, keep_ind, n_keep);
    }

    // Path storage, moved in place: keep_ind is strictly increasing, so source >= target. Every
    // path not moved down is either already freed above or released by the resize below.
    {
        const unsigned *p_keep = keep_ind.memptr();
        for (size_t i = 0; i < n_keep; ++i)
            if ((size_t)p_keep[i] != i)
                paths[i] = std::move(paths[p_keep[i]]);
    }
    paths.resize(n_keep); // Delete tail after compaction

    arma::uword n_interact = n_keep; // Stride of every per-ray array from here on
    keep_ind.reset();                // No longer needed, reused as scratch by check_gains

    // Views onto the per-frequency propagation state. ray_state_update evaluates one frequency at a
    // time, so every call gets a zero-copy view: the direction slice for that frequency and its own
    // refracted-distance column. The geometric column is shared across frequencies. These are strict
    // aliases over dir_prev / acc_dist: they own no memory and are never resized, so they must not
    // outlive their owners in use.
    const arma::fvec acc_geo(acc_dist.colptr(0), n_interact, false, true);
    const arma::fmat dir_0(dir_prev.colptr(0), n_interact, 3, false, true);
    const arma::fvec acc_ref_0(acc_dist.colptr(1), n_interact, false, true);

    // Build material indices
    arma::Col<short> mtl_ind_fbs, mtl_ind_sbs;
    if (n_interact) // All rays may be subdivided
        for (int i = 0; i < 2; ++i)
        {
            arma::Col<short> buf = arma::Col<short>(n_interact, arma::fill::none);
            const arma::uword *rL = mtl_ind.memptr();
            const unsigned *rU = i ? sbs_ind.memptr() : fbs_ind.memptr();
            short *wS = buf.memptr();

#pragma omp parallel for schedule(static) if (n_interact >= 51200)
            for (long long i_int = 0; i_int < (long long)n_interact; ++i_int)
            {
                unsigned i_XBS = rU[i_int];                   // FBS or SBS index
                wS[i_int] = i_XBS ? (short)rL[i_XBS - 1] : 0; // corresponding MTL index
            }

            if (i)
                mtl_ind_sbs = std::move(buf);
            else
                mtl_ind_fbs = std::move(buf);
        }

    // Storage for new ray state
    arma::uword n_reflect = 0, n_transmit = 0;
    arma::fmat origN, destN;                   // Origin and destination after mesh interaction
    arma::fmat fbsN, sbsN;                     // FBS and SBS recomputed with higher precision
    arma::fvec gainN;                          // Interaction gain
    arma::fmat xprmatN;                        // Polarization transfer function
    arma::fmat trivecN, tridirN;               // Beam front geometry after mesh interaction
    arma::fvec fbs_angleN;                     // Incidence angle at FBS in rad
    arma::fmat normal_vecN;                    // FBS and SBS normal vectors
    std::vector<uint8_t> interact_type;        // Interaction type code
    arma::fmat path_dirN;                      // Refraction-correct path direction
    arma::Col<short> prevN, currentN, bufferN; // New state words
    arma::fvec acc_geoN;                       // Updated accumulated geometric distance
    arma::fvec acc_refN;                       // Updated accumulated refracted (VBS) distance
    std::vector<uint8_t> verdictN;             // Where the base frequency summed a bounce series

    // Compute existing gains @ reference freq
    // calc_gain (sqrt + divide) is hoisted out of check_gains, which is serial because it
    // builds a compacted index with a running counter. Recomputing it there would cost two
    // serial sqrt passes over n_interact. If check_gains is ever parallelized, drop this
    // array and compute the gain inline instead.
    arma::fvec pre_interaction_gains;
    auto ensure_pre_gains = [&]()
    {
        if (!pre_interaction_gains.is_empty() || n_interact == 0)
            return;

        if (n_interact && (max_no_reflections || max_no_transmissions))
        {
            pre_interaction_gains.set_size(n_interact);
            const float *p_orig = orig.memptr();
            const float *p_fbs = fbsN.memptr();
            float *p_gain = pre_interaction_gains.memptr();

#pragma omp parallel for schedule(static) if (n_interact >= 4096)
            for (long long i_int = 0; i_int < (long long)n_interact; ++i_int)
            {
                size_t iY = (size_t)i_int + n_interact;
                size_t iZ = iY + n_interact;

                // Total source-to-FBS distance. A path with no segments has travelled a straight
                // line from the point source, so measure from O directly; after the first interaction
                // the accumulated polyline plus the current leg is the only correct form.
                float length = (paths[i_int].n_seg() == 0)
                                   ? calc_length(p_fbs[i_int], p_fbs[iY], p_fbs[iZ], Ox, Oy, Oz)
                                   : calc_length(p_fbs[i_int], p_fbs[iY], p_fbs[iZ], p_orig[i_int], p_orig[iY], p_orig[iZ]) + paths[i_int].length();

                p_gain[i_int] = paths[i_int].calc_gain(fRef_GHz, 0, length);
            }
        }
    };

    // Lambda to determine which paths to keep based on the gain, used by reflect and transmit pass
    auto check_gains = [&](bool reflect_pass) -> arma::uword
    {
        // Read pointers
        const float *p_gainO = pre_interaction_gains.memptr();
        const float *p_gainN = gainN.memptr();

        // Write indices
        keep_ind.set_size(n_interact);
        unsigned *p_keep_ind = keep_ind.memptr();

        arma::uword cnt = 0;
        for (unsigned i_int = 0; i_int < n_interact; ++i_int)
        {
            float gain = p_gainO[i_int] * p_gainN[i_int];
            if (gain > min_gain_linear && paths[i_int].n_seg() < (size_t)max_no_interactions)
            {
                if (reflect_pass)
                {
                    if (paths[i_int].nREF < max_no_reflections)
                        p_keep_ind[cnt++] = i_int;
                }
                else if (paths[i_int].nTRA < max_no_transmissions)
                    p_keep_ind[cnt++] = i_int;
            }
        }
        return cnt;
    };

    // Lambda to attach paths marked by "keep_ind" to the new launch config
    auto update_launch_config = [&](bool reflect_pass)
    {
        arma::uword n_rays = reflect_pass ? n_reflect : n_transmit;
        if (!n_rays)
            return;

        arma::uword offset = L.size(); // Current size
        L.resize(offset + n_rays);     // Make space for new paths

        // Read pointers
        const unsigned *p_keep_ind = keep_ind.memptr();
        const float *p_origN = origN.memptr();
        const float *p_destN = destN.memptr();
        const float *p_trivecN = beam_mode ? trivecN.memptr() : nullptr;
        const float *p_tridirN = beam_mode ? tridirN.memptr() : nullptr;
        const short *cP = prevN.memptr();
        const short *cC = currentN.memptr();
        const short *cB = bufferN.memptr();
        const float *p_fbs = fbsN.memptr();
        const float *p_xpr = xprmatN.memptr();
        const uint8_t *p_type = interact_type.data();

        // Write pointers
        float *p_orig = L.origP(offset);
        float *p_dest = L.destP(offset);
        float *p_trivec = L.trivecP(offset);
        float *p_tridir = L.tridirP(offset);
        short *pP = L.prevP(offset);
        short *pC = L.currentP(offset);
        short *pB = L.bufferP(offset);
        float *p_dir = L.dirP(offset);
        float *p_acc = L.accP(offset);
        quadriga_lib::path *p_path = L.pathP(offset);

        // Scatter the propagation state of one frequency into the launch buffer. The direction slice
        // and the refracted distance are per-frequency; the geometric distance is shared and written
        // on the base pass only. path_dirN / acc_refN are re-used by every pass, so this must be
        // called while the outputs of that frequency's ray_state_update are still live.
        auto scatter_freq = [&](arma::uword i_freq)
        {
            const float *p_dirN = path_dirN.memptr();
            const float *p_refN = acc_refN.memptr();
            const float *p_geoN = (i_freq == 0) ? acc_geoN.memptr() : nullptr;

#pragma omp parallel for schedule(static) if (n_rays >= 2048)
            for (long long i_ray = 0; i_ray < (long long)n_rays; ++i_ray)
            {
                const size_t i_out = (size_t)i_ray;
                const size_t iX = (size_t)p_keep_ind[i_ray];

                float *d = p_dir + 3 * (size_t)n_freq * i_out + 3 * (size_t)i_freq;
                d[0] = p_dirN[iX];
                d[1] = p_dirN[iX + n_interact];
                d[2] = p_dirN[iX + 2 * n_interact];

                p_acc[(1 + (size_t)n_freq) * i_out + 1 + (size_t)i_freq] = p_refN[iX];
                if (p_geoN)
                    p_acc[(1 + (size_t)n_freq) * i_out] = p_geoN[iX];
            }
        };

#pragma omp parallel for schedule(static) if (n_rays >= 256)
        for (long long i_ray = 0; i_ray < (long long)n_rays; ++i_ray)
        {
            const size_t i_out = (size_t)i_ray;
            const arma::uword i_out3 = 3 * i_out;
            const arma::uword i_out9 = 9 * i_out;
            const size_t iX = (size_t)p_keep_ind[i_ray];
            const size_t iY = iX + n_interact;
            const size_t iZ = iY + n_interact;

            // Update orig and dest
            p_orig[i_out3] = p_origN[iX];
            p_orig[i_out3 + 1] = p_origN[iY];
            p_orig[i_out3 + 2] = p_origN[iZ];

            p_dest[i_out3] = p_destN[iX];
            p_dest[i_out3 + 1] = p_destN[iY];
            p_dest[i_out3 + 2] = p_destN[iZ];

            // Update trivec and tridir
            if (beam_mode)
                for (size_t i = 0; i < 9; ++i)
                {
                    p_trivec[i_out9 + i] = p_trivecN[iX + i * n_interact];
                    p_tridir[i_out9 + i] = p_tridirN[iX + i * n_interact];
                }

            // Update interaction state
            pP[i_out] = cP[iX];
            pC[i_out] = cC[iX];
            pB[i_out] = cB[iX];

            // Add new segment to path storage and left-multiply XPR matrix at base frequency
            paths[iX].extend(p_path[i_out], p_fbs[iX], p_fbs[iY], p_fbs[iZ], p_type[iX]);
            if (paths[iX].n_seg() == 0) // source -> new interaction point: derive the first leg (no previous coordinate)
                p_path[i_out].set_length(calc_length(p_fbs[iX], p_fbs[iY], p_fbs[iZ], Ox, Oy, Oz));

            p_path[i_out].xpr_update(&p_xpr[nXPR * iX]);
            if (reflect_pass)
                ++p_path[i_out].nREF;
            else
                ++p_path[i_out].nTRA;
        }

        // Base frequency. Must run before the loop below overwrites path_dirN / acc_refN.
        scatter_freq(0);

        // Update xprmat for other frequencies. Each one re-evaluates the interface from its own
        // direction slice and refracted accumulator, so a dispersive medium now bends and attenuates
        // correctly per band instead of inheriting the base-frequency Snell angle.
        //
        // With refraction_mode the traced polyline was bent at the base frequency, and it is the one
        // path of every frequency: at f != f0 the wave leaves a medium beside it. Each coefficient
        // is the field of its frequency at the point the polyline leaves at, so no geometry is per
        // frequency. Undeviated tracing (types 1/4) is the same statement with a straight polyline.
        int interaction_type = scalar_mode ? (refraction_mode ? 5 : 4) : (refraction_mode ? 2 : 1);
        if (reflect_pass)
            interaction_type = scalar_mode ? 3 : 0;

        for (arma::uword i_freq = 1; i_freq < n_freq; ++i_freq)
        {
            // Note: fbsN, sbsN, fbs_angleN, normal_vecN are re-used from the reflection / subdivision pass
            // trivec and tridir are needed as input to evaluate TIR conditions for the entire ray tube and not just he spine
            quadriga_lib::ray_mesh_interact<float>(interaction_type, center_frequency[i_freq], &orig, &dest,
                                                   &mesh, &mtl_ind, &mtl_prop, &fbs_ind, &sbs_ind,
                                                   (beam_mode ? trivec : nullptr), (beam_mode ? tridir : nullptr),
                                                   nullptr, nullptr, nullptr, nullptr, nullptr, &xprmatN, nullptr, nullptr,
                                                   nullptr, nullptr, nullptr, nullptr, &interact_type, &path_dirN, false);

            // Zero-copy views of this frequency's incoming state. The geometric accumulator is shared
            // and its output is not requested here: the traced polyline is the base-frequency geometry,
            // so its arc length is the base-frequency value by definition.
            const arma::fmat dir_f(dir_prev.colptr(3 * i_freq), n_interact, 3, false, true);
            const arma::fvec acc_ref_f(acc_dist.colptr(1 + i_freq), n_interact, false, true);

            quadriga_lib::ray_state_update<float>(interaction_type, center_frequency[i_freq], &orig, &dest,
                                                  &fbsN, &sbsN, &no_interact, &fbs_angleN, &normal_vecN,
                                                  &interact_type, &mtl_prop, &mtl_ind_fbs, &mtl_ind_sbs,
                                                  &mtl_ind_prev, &mtl_ind_current, &mtl_ind_buffer,
                                                  &dir_f, &acc_geo, &acc_ref_f, nullptr, nullptr, nullptr,
                                                  nullptr, &xprmatN, &path_dirN, nullptr, &acc_refN,
                                                  nullptr, nullptr, (double)thin_slab_threshold,
                                                  nullptr, nullptr, nullptr, nullptr,
                                                  &verdictN); // the paths are the base frequency's, and so is the verdict on each series

            scatter_freq(i_freq);

            const float *p_xpr_freq = xprmatN.memptr();

#pragma omp parallel for schedule(static) if (n_rays >= 2048)
            for (long long i_ray = 0; i_ray < (long long)n_rays; ++i_ray)
            {
                const size_t iX = (size_t)p_keep_ind[i_ray];
                p_path[i_ray].xpr_update(&p_xpr_freq[nXPR * iX], 1.0, i_freq);
            }
        }
    };

    // Add reflected paths to launch config
    if (max_no_reflections && n_interact)
    {
        quadriga_lib::ray_mesh_interact<float>((scalar_mode ? 3 : 0),
                                               fRef_Hz, &orig, &dest, &mesh, &mtl_ind, &mtl_prop,
                                               &fbs_ind, &sbs_ind,
                                               (beam_mode ? trivec : nullptr),
                                               (beam_mode ? tridir : nullptr),
                                               &origN, &destN, &fbsN, &sbsN, &gainN, &xprmatN,
                                               (beam_mode ? &trivecN : nullptr),
                                               (beam_mode ? &tridirN : nullptr),
                                               &fbs_angleN, nullptr, nullptr,
                                               &normal_vecN, &interact_type, &path_dirN, false);

        if (fbsN.n_rows != n_interact) // Check that stream compaction is really OFF
            throw std::runtime_error("ray_mesh_interact compacted the stream.");

        // Resolve ray state for reflection pass
        quadriga_lib::ray_state_update<float>((scalar_mode ? 3 : 0),
                                              fRef_Hz, &orig, &dest, &fbsN, &sbsN,
                                              &no_interact, &fbs_angleN, &normal_vecN, &interact_type,
                                              &mtl_prop, &mtl_ind_fbs, &mtl_ind_sbs,
                                              &mtl_ind_prev, &mtl_ind_current, &mtl_ind_buffer,
                                              &dir_0, &acc_geo, &acc_ref_0,
                                              &prevN, &currentN, &bufferN,
                                              &gainN, &xprmatN, &path_dirN, &acc_geoN, &acc_refN,
                                              &interact_type, // Aliasing OK and deliberate
                                              nullptr, (double)thin_slab_threshold,
                                              nullptr, nullptr, nullptr, nullptr, nullptr, &verdictN);

        ensure_pre_gains();
        n_reflect = check_gains(true); // Parse gainN and build keep_ind
        gainN.reset();                 // No longer needed
        update_launch_config(true);    // Add paths
    }

    // Add transmitted paths to launch config
    if (max_no_transmissions && n_interact)
    {
        // Compute transmission / refraction into medium
        const bool need_shared = (max_no_reflections == 0); // reflection pass did not fill these
        quadriga_lib::ray_mesh_interact<float>((scalar_mode ? (refraction_mode ? 5 : 4) : (refraction_mode ? 2 : 1)),
                                               fRef_Hz, &orig, &dest, &mesh, &mtl_ind, &mtl_prop,
                                               &fbs_ind, &sbs_ind,
                                               (beam_mode ? trivec : nullptr),
                                               (beam_mode ? tridir : nullptr),
                                               &origN, &destN, &fbsN, &sbsN, &gainN, &xprmatN,
                                               (beam_mode ? &trivecN : nullptr),
                                               (beam_mode ? &tridirN : nullptr),
                                               (need_shared ? &fbs_angleN : nullptr), nullptr, nullptr,
                                               (need_shared ? &normal_vecN : nullptr), &interact_type, &path_dirN, false);

        if (need_shared && fbsN.n_rows != n_interact)
            throw std::runtime_error("ray_mesh_interact compacted the stream.");

        // Resolve ray state for transmission pass
        quadriga_lib::ray_state_update<float>((scalar_mode ? (refraction_mode ? 5 : 4) : (refraction_mode ? 2 : 1)),
                                              fRef_Hz, &orig, &dest, &fbsN, &sbsN,
                                              &no_interact, &fbs_angleN, &normal_vecN, &interact_type,
                                              &mtl_prop, &mtl_ind_fbs, &mtl_ind_sbs,
                                              &mtl_ind_prev, &mtl_ind_current, &mtl_ind_buffer,
                                              &dir_0, &acc_geo, &acc_ref_0,
                                              &prevN, &currentN, &bufferN,
                                              &gainN, &xprmatN, &path_dirN, &acc_geoN, &acc_refN,
                                              &interact_type, // Aliasing OK and deliberate
                                              nullptr, (double)thin_slab_threshold,
                                              &origN, &destN, // the segment follows the direction written out of a lossy medium
                                              (beam_mode ? tridir : nullptr),
                                              (beam_mode ? &tridirN : nullptr),
                                              nullptr, &verdictN);

        ensure_pre_gains();
        n_transmit = check_gains(false); // Parse gainN and build keep_ind
        gainN.reset();                   // No longer needed
        update_launch_config(false);     // Add paths
    }

    // Free memory
    std::vector<uint8_t>().swap(interact_type); // deallocate
    pre_interaction_gains.reset();
    orig.reset(), dest.reset(), dir_prev.reset(), acc_dist.reset();
    mtl_ind_prev.reset(), mtl_ind_current.reset(), mtl_ind_buffer.reset();
    origN.reset(), destN.reset(), fbsN.reset(), sbsN.reset(), xprmatN.reset();
    prevN.reset(), currentN.reset(), bufferN.reset();
    path_dirN.reset(), acc_geoN.reset(), acc_refN.reset(), normal_vecN.reset(), fbs_angleN.reset();
    no_interact.reset(), fbs_ind.reset(), sbs_ind.reset();
    mtl_ind_fbs.reset(), mtl_ind_sbs.reset(), keep_ind.reset();
    if (beam_mode)
        trivec->reset(), tridir->reset(), trivecN.reset(), tridirN.reset();

    // Copy paths to new launch config
    const arma::uword n_out = (arma::uword)L.size();

    commit(orig, L.origP(), 3, n_out);
    L.orig.reset();

    commit(dest, L.destP(), 3, n_out);
    L.dest.reset();

    commit(mtl_ind_prev, L.prevP(), 1, n_out);
    L.mtl_ind_prev.reset();

    commit(mtl_ind_current, L.currentP(), 1, n_out);
    L.mtl_ind_current.reset();

    commit(mtl_ind_buffer, L.bufferP(), 1, n_out);
    L.mtl_ind_buffer.reset();

    // Rebuild the cube from the ray-major launch buffer through an [n_out, 3*n_freq] alias, so the
    // blocked transpose in commit() is reused unchanged.
    path_dir_prev.set_size(n_out, 3, n_freq);
    if (n_out)
    {
        arma::fmat dir_out(path_dir_prev.memptr(), n_out, 3 * n_freq, false, true);
        commit(dir_out, L.dirP(), 3 * n_freq, n_out);
    }
    L.path_dir_prev.reset();

    commit(acc_dist, L.accP(), 1 + n_freq, n_out);
    L.acc_dist.reset();

    paths = std::move(L.paths);
    if (beam_mode)
    {
        commit(*trivec, L.trivecP(), 9, n_out);
        L.trivec.reset();
        commit(*tridir, L.tridirP(), 9, n_out);
        L.tridir.reset();
    }

    // Statistics
    std::array<unsigned, 4> stats = {(unsigned)n_hit, (unsigned)n_subdiv, (unsigned)n_reflect, (unsigned)n_transmit};
    return stats;
}