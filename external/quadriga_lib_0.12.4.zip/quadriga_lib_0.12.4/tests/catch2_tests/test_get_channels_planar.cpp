// SPDX-License-Identifier: Apache-2.0
// Copyright (C) 2022-2026 Stephan Jaeckel (http://quadriga-lib.org)
// Part of quadriga-lib — see LICENSE for terms.

#include <catch2/catch_test_macros.hpp>

#include "quadriga_lib.hpp"

#include <iostream>
#include <string>

TEST_CASE("Get Channels Planar - Minimal test")
{

    float pi = 3.141592653589793f, pid180 = 0.017453292519943f;

    // Generate test antenna
    auto ant = quadriga_lib::generate_arrayant_omni<float>();
    ant.copy_element(0, 1);
    ant.element_pos(1, 0) = 1.0;
    ant.element_pos(1, 1) = -1.0;
    ant.e_theta_re.slice(1) *= 2;

    arma::fvec aod(2), eod(2), aoa(2), eoa(2), path_gain(2), path_length(2);

    //     FBS @ 11 m height
    //      |
    //     10 m
    //      |           FBS LOS @ x = 10 m
    //     TX --------------d = 20 m------------------ RX

    aod(0) = 0.0;
    aod(1) = 90.0 * pid180;

    eod(0) = 0.0;
    eod(1) = 45.0 * pid180;

    aoa(0) = pi;
    aoa(1) = pi - std::atan(10.0 / 20.0);

    eoa(0) = 0.0;
    eoa(1) = std::atan(10.0 / std::sqrt(10.0 * 10.0 + 20.0 * 20.0));

    path_gain(0) = 1;
    path_gain(1) = 0.25;

    path_length(0) = 20.0;
    path_length(1) = std::sqrt(10.0 * 10.0 + 10.0 * 10.0) + std::sqrt(10.0 * 10.0 + 20.0 * 20.0 + 10.0 * 10.0);

    arma::fmat M(8, 2);
    M(0, 0) = 1.0;
    M(0, 1) = 1.0;
    M(6, 0) = -1.0;
    M(6, 1) = -1.0;

    // Shortest path length is automatically obtained from FBS / LBS
    arma::fcube coeff_re, coeff_im, delay;
    arma::fvec rx_Doppler;

    quadriga_lib::get_channels_planar<float>(&ant, &ant,
                                             0.0, 0.0, 1.0, 0.0, 0.0, 0.0,
                                             20.0, 0.0, 1.0, 0.0, 0.0, 0.0,
                                             &aod, &eod, &aoa, &eoa, &path_gain, &path_length, &M,
                                             &coeff_re, &coeff_im, &delay, 2997924580.0, true, false,
                                             &rx_Doppler);

    // Check amplitude
    arma::fcube amp = arma::sqrt(coeff_re % coeff_re + coeff_im % coeff_im);
    CHECK(std::abs(amp.at(0, 0, 0) - 1.0f) < 1.0e-6f);
    CHECK(std::abs(amp.at(1, 0, 0) - 2.0f) < 1.0e-6f);
    CHECK(std::abs(amp.at(0, 1, 0) - 2.0f) < 1.0e-6f);
    CHECK(std::abs(amp.at(1, 1, 0) - 4.0f) < 1.0e-6f);
    CHECK(std::abs(amp.at(0, 0, 1) - 0.5f) < 1.0e-4f);
    CHECK(std::abs(amp.at(1, 0, 1) - 1.0f) < 1.0e-4f);
    CHECK(std::abs(amp.at(0, 1, 1) - 1.0f) < 1.0e-4f);
    CHECK(std::abs(amp.at(1, 1, 1) - 2.0f) < 1.0e-4f);

    // Check delays
    float C = 299792458.0;
    float d0 = 20.0;
    float e0 = (std::sqrt(9.0 * 9.0 + 10.0 * 10.0) + std::sqrt(9.0 * 9.0 + 20.0 * 20.0 + 10.0 * 10.0));
    float e1 = (std::sqrt(9.0 * 9.0 + 10.0 * 10.0) + std::sqrt(11.0 * 11.0 + 20.0 * 20.0 + 10.0 * 10.0));
    float e2 = (std::sqrt(11.0 * 11.0 + 10.0 * 10.0) + std::sqrt(9.0 * 9.0 + 20.0 * 20.0 + 10.0 * 10.0));
    float e3 = (std::sqrt(11.0 * 11.0 + 10.0 * 10.0) + std::sqrt(11.0 * 11.0 + 20.0 * 20.0 + 10.0 * 10.0));
    CHECK(std::abs(delay.at(0, 0, 0) - d0 / C) < 1.0e-13f);
    CHECK(std::abs(delay.at(1, 0, 0) - d0 / C) < 1.0e-13f);
    CHECK(std::abs(delay.at(0, 1, 0) - d0 / C) < 1.0e-13f);
    CHECK(std::abs(delay.at(1, 1, 0) - d0 / C) < 1.0e-13f);
    CHECK(std::abs(delay.at(0, 0, 1) - e0 / C) < 1.2e-10f);
    CHECK(std::abs(delay.at(1, 0, 1) - e1 / C) < 1.2e-10f);
    CHECK(std::abs(delay.at(0, 1, 1) - e2 / C) < 1.2e-10f);
    CHECK(std::abs(delay.at(1, 1, 1) - e3 / C) < 1.2e-10f);

    // Check Doppler
    float Doppler = std::cos(aoa.at(1)) * std::cos(eoa.at(1));
    REQUIRE(rx_Doppler.n_elem == 2);
    CHECK(std::abs(rx_Doppler.at(0) + 1.0f) < 1.0e-6f);
    CHECK(std::abs(rx_Doppler.at(1) - Doppler) < 1.0e-6f);
}

TEST_CASE("Get Channels Planar - Fake LOS")
{

    float pi = 3.141592653589793f, pid180 = 0.017453292519943f;
    auto ant = quadriga_lib::generate_arrayant_omni<float>();

    // LOS-Path and LBS / FBS are reversed

    arma::fvec aod(2), eod(2), aoa(2), eoa(2), path_gain(2), path_length(2);

    aod(1) = 0.0;
    aod(0) = 90.0 * pid180;

    eod(1) = 0.0;
    eod(0) = 45.0 * pid180;

    aoa(1) = pi;
    aoa(0) = pi - std::atan(10.0 / 20.0);

    eoa(1) = 0.0;
    eoa(0) = std::atan(10.0 / std::sqrt(10.0 * 10.0 + 20.0 * 20.0));

    path_gain(1) = 1;
    path_gain(0) = 0.25;

    path_length(1) = 20.0;
    path_length(0) = std::sqrt(10.0 * 10.0 + 10.0 * 10.0) + std::sqrt(10.0 * 10.0 + 20.0 * 20.0 + 10.0 * 10.0);

    arma::fmat M(8, 2);
    M(0, 0) = 1.0;
    M(0, 1) = 1.0;
    M(6, 0) = -1.0;
    M(6, 1) = -1.0;

    // Shortest path length is automatically obtained from FBS / LBS
    arma::fcube coeff_re, coeff_im, delay;

    quadriga_lib::get_channels_planar<float>(&ant, &ant,
                                             0.0, 0.0, 1.0, 0.0, 0.0, 0.0,
                                             20.0, 0.0, 1.0, 0.0, 0.0, 0.0,
                                             &aod, &eod, &aoa, &eoa, &path_gain, &path_length, &M,
                                             &coeff_re, &coeff_im, &delay, 2997924580.0, true, true);

    REQUIRE(coeff_re.n_slices == 3);
    REQUIRE(coeff_im.n_slices == 3);
    REQUIRE(delay.n_slices == 3);

    // Check amplitude
    arma::fcube amp = arma::sqrt(coeff_re % coeff_re + coeff_im % coeff_im);
    CHECK(std::abs(amp.at(0, 0, 0) - 1.0f) < 1.0e-6f);
    CHECK(std::abs(amp.at(0, 0, 1) - 0.5f) < 1.0e-6f);
    CHECK(std::abs(amp.at(0, 0, 2) - 0.0f) < 1.0e-6f);

    // Check delays
    float C = 299792458.0;
    float d0 = 20.0;
    float e0 = (std::sqrt(10.0 * 10.0 + 10.0 * 10.0) + std::sqrt(10.0 * 10.0 + 20.0 * 20.0 + 10.0 * 10.0));
    CHECK(std::abs(delay.at(0, 0, 0) - d0 / C) < 1.0e-13f);
    CHECK(std::abs(delay.at(0, 0, 1) - e0 / C) < 1.2e-13f);
    CHECK(std::abs(delay.at(0, 0, 2) - d0 / C) < 1.0e-13f);
}

TEST_CASE("Get Channels Planar - Coupling")
{
    float pi = 3.141592653589793f;

    auto ant = quadriga_lib::generate_arrayant_omni<double>();
    ant.copy_element(0, 2);
    ant.element_pos(1, 0) = 1.0;
    ant.element_pos(1, 2) = -1.0;

    arma::vec aod(1), eod(1), aoa(1), eoa(1), path_gain(1), path_length(1);
    aoa.at(0) = pi;
    path_length(0) = 20.0;
    path_gain(0) = 1;

    arma::mat M(8, 1);
    M(0, 0) = 1.0;
    M(6, 0) = -1.0;

    // Shortest path length is automatically obtained from FBS / LBS
    arma::cube coeff_re, coeff_im, delay;

    // Case 1 : No coupling (identity matrix)
    quadriga_lib::get_channels_planar<double>(&ant, &ant,
                                              0.0, 0.0, 1.0, 0.0, 0.0, 0.0,
                                              20.0, 0.0, 1.0, 0.0, 0.0, 0.0,
                                              &aod, &eod, &aoa, &eoa, &path_gain, &path_length, &M,
                                              &coeff_re, &coeff_im, &delay, 0.0, false, true);

    REQUIRE(coeff_re.n_slices == 2);
    REQUIRE(coeff_im.n_slices == 2);
    REQUIRE(delay.n_slices == 2);

    // Possible delay offsets
    double da = (std::sqrt(20.0 * 20.0 + 0.0) - 20.0) / 299792458.0;
    double db = (std::sqrt(20.0 * 20.0 + 0.0) - 20.0) / 299792458.0;

    arma::mat T(3, 3); // Zeros
    CHECK(arma::approx_equal(coeff_im.slice(0), T, "absdiff", 1e-14));
    CHECK(arma::approx_equal(coeff_im.slice(1), T, "absdiff", 1e-14));
    CHECK(arma::approx_equal(coeff_re.slice(1), T, "absdiff", 1e-14));
    T.at(0, 0) = 1.0;
    T.at(0, 2) = 1.0;
    T.at(2, 0) = 1.0;
    T.at(2, 2) = 1.0;
    CHECK(arma::approx_equal(coeff_re.slice(0), T, "absdiff", 1e-14));

    T = {{0.0, da, db}, {da, 0.0, da}, {db, da, 0.0}};
    CHECK(arma::approx_equal(delay.slice(0), T, "absdiff", 1e-14));
    CHECK(arma::approx_equal(delay.slice(1), T, "absdiff", 1e-14));

    arma::mat dd = delay.slice(0) - T;

    // Case 2: n_ports == n_elements
    ant.coupling_re.zeros();
    ant.coupling_re.col(0).ones();
    ant.coupling_im.reset();

    quadriga_lib::get_channels_planar<double>(&ant, &ant,
                                              0.0, 0.0, 1.0, 0.0, 0.0, 0.0,
                                              20.0, 0.0, 1.0, 0.0, 0.0, 0.0,
                                              &aod, &eod, &aoa, &eoa, &path_gain, &path_length, &M,
                                              &coeff_re, &coeff_im, &delay, 0.0, true, false);
    CHECK(coeff_re.n_slices == 1);
    CHECK(coeff_im.n_slices == 1);
    CHECK(delay.n_slices == 1);

    T.zeros();
    CHECK(arma::approx_equal(coeff_im.slice(0), T, "absdiff", 1e-14));

    T.at(0, 0) = 4.0;
    CHECK(arma::approx_equal(coeff_re.slice(0), T, "absdiff", 1e-14));

    T.ones();
    double dx = (4.0 * da + 2.0 * db) / 9.0 + 20.0 / 299792458.0;
    T = T * dx;
    CHECK(arma::approx_equal(delay.slice(0), T, "absdiff", 1e-14));

    // Case 3: n_ports != n_elements
    delay.zeros();
    ant.coupling_re.ones(3, 1);
    ant.coupling_re *= 2.0;

    quadriga_lib::get_channels_planar<double>(&ant, &ant,
                                              0.0, 0.0, 1.0, 0.0, 0.0, 0.0,
                                              20.0, 0.0, 1.0, 0.0, 0.0, 0.0,
                                              &aod, &eod, &aoa, &eoa, &path_gain, &path_length, &M,
                                              &coeff_re, &coeff_im, &delay, 0.0, true, false);

    CHECK(coeff_re.n_elem == 1);
    CHECK(coeff_im.n_elem == 1);
    CHECK(delay.n_elem == 1);
    CHECK(aod.n_elem == 1);
    CHECK(eod.n_elem == 1);
    CHECK(aoa.n_elem == 1);

    CHECK(std::abs(coeff_re.at(0, 0, 0) - 16.0) < 1.0e-14f);
    CHECK(std::abs(coeff_im.at(0, 0, 0) - 0.0) < 1.0e-14f);
    CHECK(std::abs(delay.at(0, 0, 0) - dx) < 1.0e-14f);
}

TEST_CASE("Get Channels Planar - add_fake_los_path layout")
{
    // Always one extra output path; slot 0 holds the LOS path (zero power if none was found);
    // if a LOS path was present, its original slot holds a zero-power path.
    const double C = 299792458.0;
    auto omni = quadriga_lib::generate_arrayant_omni<double>(10.0);
    arma::vec aod = {0.5, 0.0, -0.4}, eod = {0.0, 0.0, 0.1}, aoa = {2.5, arma::datum::pi, -2.7}, eoa = {0.0, 0.0, 0.1};
    arma::vec G = {0.5, 1.0, 0.25};
    arma::mat M(8, 3, arma::fill::zeros);
    M.row(0).fill(1.0), M.row(6).fill(-1.0);
    arma::cube cr, ci, dl;

    // Case 1: LOS path at input index 1 (path_length = TX-RX distance 50 m)
    arma::vec PL = {60.0, 50.0, 70.0};
    quadriga_lib::get_channels_planar<double>(&omni, &omni, 0, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0,
                                              &aod, &eod, &aoa, &eoa, &G, &PL, &M, &cr, &ci, &dl, 1e9, true, true);
    REQUIRE(cr.n_slices == 4);
    arma::vec p = arma::vectorise(arma::square(cr) + arma::square(ci));
    CHECK(std::abs(p(0) - 1.0) < 1e-9);
    CHECK(std::abs(p(1) - 0.5) < 1e-9);
    CHECK(p(2) == 0.0);
    CHECK(std::abs(p(3) - 0.25) < 1e-9);
    CHECK(std::abs(dl(0) * C - 50.0) < 1e-6);
    CHECK(std::abs(dl(2) * C - 50.0) < 1e-6);

    // Case 2: no LOS path
    PL(1) = 55.0;
    quadriga_lib::get_channels_planar<double>(&omni, &omni, 0, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0,
                                              &aod, &eod, &aoa, &eoa, &G, &PL, &M, &cr, &ci, &dl, 1e9, true, true);
    REQUIRE(cr.n_slices == 4);
    p = arma::vectorise(arma::square(cr) + arma::square(ci));
    CHECK(p(0) == 0.0);
    CHECK(std::abs(p(1) - 0.5) < 1e-9);
    CHECK(std::abs(p(2) - 1.0) < 1e-9);
    CHECK(std::abs(p(3) - 0.25) < 1e-9);
    CHECK(std::abs(dl(0) * C - 50.0) < 1e-6);
    CHECK(std::abs(dl(2) * C - 55.0) < 1e-6);
}

TEST_CASE("Get Channels Planar - 0 paths with add_fake_los_path")
{
    // The output holds exactly the zero-power LOS path; its delays per antenna pair equal those of a real LOS path
    // with the same geometry (which is moved to slot 0); without add_fake_los_path, the outputs are empty
    const double C = 299792458.0;
    auto tx = quadriga_lib::generate_arrayant_omni<double>(10.0);
    tx.copy_element(0, 1);
    tx.element_pos = {{0.3, -0.2}, {0.1, 0.4}, {0.0, 0.2}};
    auto rx = tx;
    rx.coupling_re = arma::vec({1.0, 0.5}); // 2 elements, 1 port
    rx.coupling_im = arma::vec({0.0, 0.2});

    const double Tx = 1, Ty = 2, Tz = 3, Rx = 11, Ry = -3, Rz = 5;
    const double dx = Rx - Tx, dy = Ry - Ty, dz = Rz - Tz, dist = std::sqrt(dx * dx + dy * dy + dz * dz);
    arma::vec e, aod = {std::atan2(dy, dx)}, eod = {std::atan2(dz, std::sqrt(dx * dx + dy * dy))};
    arma::vec aoa = {std::atan2(-dy, -dx)}, eoa = {-eod(0)}, gain = {1.0}, len = {dist};
    arma::mat M0(8, 0), M = {1.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0, 0.0};
    M = M.t();

    for (bool abs_delays : {true, false})
    {
        arma::cube cr, ci, dl, crL, ciL, dlL;
        arma::vec dop, dopL;
        quadriga_lib::get_channels_planar<double>(&tx, &rx, Tx, Ty, Tz, 0, 0, 0.3, Rx, Ry, Rz, 0, 0, -0.2,
                                                  &e, &e, &e, &e, &e, &e, &M0, &cr, &ci, &dl, 3e9, abs_delays, true, &dop);
        quadriga_lib::get_channels_planar<double>(&tx, &rx, Tx, Ty, Tz, 0, 0, 0.3, Rx, Ry, Rz, 0, 0, -0.2,
                                                  &aod, &eod, &aoa, &eoa, &gain, &len, &M, &crL, &ciL, &dlL, 3e9, abs_delays, true, &dopL);
        REQUIRE(cr.n_rows == 1);
        REQUIRE(cr.n_cols == 2);
        REQUIRE(cr.n_slices == 1);
        REQUIRE(dl.n_slices == 1);
        REQUIRE(dop.n_elem == 1);
        CHECK(arma::all(arma::vectorise(cr) == 0.0));
        CHECK(arma::all(arma::vectorise(ci) == 0.0));
        CHECK(dop(0) == 0.0);
        CHECK(arma::approx_equal(dl.slice(0), dlL.slice(0), "absdiff", 1e-18));
        if (abs_delays)
            CHECK(std::abs(arma::mean(arma::vectorise(dl)) * C - dist) < 0.5);
        else
            CHECK(std::abs(arma::mean(arma::vectorise(dl)) * C) < 0.5);
    }

    // Single-element antennas: delay = TX-RX distance / c, or 0 for relative delays
    auto omni = quadriga_lib::generate_arrayant_omni<double>(10.0);
    arma::cube cr, ci, dl;
    quadriga_lib::get_channels_planar<double>(&omni, &omni, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0,
                                              &e, &e, &e, &e, &e, &e, &M0, &cr, &ci, &dl, 1e9, true, true);
    REQUIRE(dl.n_elem == 1);
    CHECK(std::abs(dl(0) - 10.0 / C) < 1e-20);
    CHECK(cr(0) == 0.0);
    CHECK(ci(0) == 0.0);
    quadriga_lib::get_channels_planar<double>(&omni, &omni, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0,
                                              &e, &e, &e, &e, &e, &e, &M0, &cr, &ci, &dl, 1e9, false, true);
    CHECK(dl(0) == 0.0);
    quadriga_lib::get_channels_planar<double>(&omni, &omni, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0,
                                              &e, &e, &e, &e, &e, &e, &M0, &cr, &ci, &dl, 1e9, true, false);
    CHECK(dl.n_slices == 0); // without add_fake_los_path: empty outputs
}

TEST_CASE("Get Channels Planar - 0 paths without add_fake_los_path")
{
    // Empty outputs of size [n_rx_ports, n_tx_ports, 0], also into outputs that held data before
    auto tx = quadriga_lib::generate_arrayant_omni<double>(10.0);
    tx.copy_element(0, 1);
    auto rx = tx;
    rx.coupling_re = arma::vec({1.0, 0.5}); // 2 elements, 1 port
    rx.coupling_im = arma::vec({0.0, 0.2});
    arma::vec e, dop(3, arma::fill::ones);
    arma::mat M0(8, 0), Mx; // M may also be 0x0
    arma::cube cr(2, 2, 5, arma::fill::ones), ci, dl;
    for (const arma::mat *M : {&M0, &Mx})
    {
        quadriga_lib::get_channels_planar<double>(&tx, &rx, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0,
                                                  &e, &e, &e, &e, &e, &e, M, &cr, &ci, &dl, 1e9, true, false, &dop);
        for (const arma::cube *c : {&cr, &ci, &dl})
        {
            CHECK(c->n_rows == 1);
            CHECK(c->n_cols == 2);
            CHECK(c->n_slices == 0);
        }
        CHECK(dop.n_elem == 0);
    }
    // Inconsistent path counts remain an error
    arma::vec one = {1.0};
    CHECK_THROWS_AS(quadriga_lib::get_channels_planar<double>(&tx, &rx, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0,
                                                              &one, &e, &e, &e, &e, &e, &M0, &cr, &ci, &dl, 1e9, true, false),
                    std::invalid_argument);
}
