clear all
close all

no_mesh = 1e7;
no_pos  = 1e7;

use_sub_mesh = 1; % 1 or 0

% Cube
cube = [  -1     1     1   ,    1    -1     1   ,    1     1     1;   %  1 Top NorthEast
           1    -1     1   ,   -1    -1    -1   ,    1    -1    -1;   %  2 South Lower
          -1    -1     1   ,   -1     1    -1   ,   -1    -1    -1;   %  3 West Lower
           1     1    -1   ,   -1    -1    -1   ,   -1     1    -1;   %  4 Bottom NorthWest
           1     1     1   ,    1    -1    -1   ,    1     1    -1;   %  5 East Lower
          -1     1     1   ,    1     1    -1   ,   -1     1    -1;   %  6 North Lower
          -1     1     1   ,   -1    -1     1   ,    1    -1     1;   %  7 Top SouthWest
           1    -1     1   ,   -1    -1     1   ,   -1    -1    -1;   %  8 South Upper
          -1    -1     1   ,   -1     1     1   ,   -1     1    -1;   %  9 West Upper
           1     1    -1   ,    1    -1    -1   ,   -1    -1    -1;   % 10 Bottom SouthEast
           1     1     1   ,    1    -1     1   ,    1    -1    -1;   % 11 East Upper
          -1     1     1   ,    1     1     1   ,    1     1    -1 ]; % 12 North Upper

% Plane
cube(:,[1,2,4,5,7,8]) = cube(:,[1,2,4,5,7,8]) * 100;
%cube = cube([1,7],:);

% Subdivide
mesh = quadriga_lib.subdivide_triangles(cube, round(sqrt(no_mesh/12)));

sub_mesh_index = [];
if use_sub_mesh
    target_size = max(1024, sqrt(no_mesh) );
    tic 
    [ mesh, sub_mesh_index ] = quadriga_lib.triangle_mesh_segmentation( mesh, target_size, 8 );
    toc
end

x_min = -99; x_max = 99; y_min = -99; y_max = 99;   % Map edges (set by model size)
pixel_size = 198 / round(sqrt(no_pos));                 % in [m]

% Generate a grid of receiver positions
x = x_min : pixel_size : x_max;
y = y_min : pixel_size : y_max;
[X,Y] = meshgrid(x,y);
orig = [X(:), Y(:), ones(numel(X),1)*20];
dest = [X(:), Y(:), -ones(numel(X),1)*20];

tic
[ fbs, sbs, no_hit, ifbs, isbs ] = quadriga_lib.ray_triangle_intersect( orig, dest, mesh, sub_mesh_index );
toc


