function test_get_channels_irs()

% Antenna configs
n_el=3; n_az=4; n_elem_tx=2; n_ports_tx=2;
n_elem_rx=2; n_ports_rx=2;
n_elem_irs=2; n_ports_irs=2;

ant_tx = make_ant(n_el,n_az,n_elem_tx,n_ports_tx,1.0);                  % isotropic-like, real
ant_rx = make_ant(n_el,n_az,n_elem_rx,n_ports_rx,1.0);
ant_irs = make_ant(n_el,n_az,n_elem_irs,n_ports_irs,1.0);               % default IRS
ant_irs_diff = make_ant(n_el,n_az,n_elem_irs,n_ports_irs,0.3);          % for asymmetry / i_irs effect

% Geometry (meters) & orientations (radians)
tx_pos=[0;0;1]; rx_pos=[20;10;1]; irs_pos=[10;0;5];
tx_ori=[0;0;0]; rx_ori=[0;0;0]; irs_ori=[0;0;0];

% Scatterers (two paths each leg)
fbs_pos_1 = [ 2  4; 0 1; 3 4 ];
lbs_pos_1 = [ 6  8; 0 1; 4 5 ];
fbs_pos_2 = [12 15; 1 2; 5 6 ];
lbs_pos_2 = [16 18; 5 6; 4 3 ];

% Path lengths consistent with geometry
path_length_1 = zeros(1,2);
for k=1:2
    path_length_1(k)=norm(tx_pos-fbs_pos_1(:,k))+norm(fbs_pos_1(:,k)-lbs_pos_1(:,k))+norm(lbs_pos_1(:,k)-irs_pos);
end
path_length_2 = zeros(1,2);
for k=1:2
    path_length_2(k)=norm(irs_pos-fbs_pos_2(:,k))+norm(fbs_pos_2(:,k)-lbs_pos_2(:,k))+norm(lbs_pos_2(:,k)-rx_pos);
end

% Gains (linear)
path_gain_1 = [1.0, 0.2];
path_gain_2 = [1.0, 0.05];

% Polarization transfer matrices (real -> no phase when f0=0)
M_1 = zeros(8,2);
M_1([1,3,5,7],:) = 1;
M_2 = M_1;

% Convenience
all_mask = true(1, numel(path_gain_1)*numel(path_gain_2));
some_mask = [true true true false]; % length 4

% ---------- 1) Basic call; all paths kept; f0=0 ----------
i_irs = 1; thr_keep_all = -300; f0_zero = 0; use_abs=false; active_path_in=[];
[cr0,ci0,D0,act0,aod0,eod0,aoa0,eoa0] = quadriga_lib.get_channels_irs( ...
    ant_tx, ant_rx, ant_irs, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    i_irs, thr_keep_all, f0_zero, use_abs, active_path_in, [] );

% Sizes
assertEqual(size(cr0), [n_ports_rx, n_ports_tx, 4]);
assertEqual(size(ci0), [n_ports_rx, n_ports_tx, 4]);
assertEqual(size(D0),  [n_ports_rx, n_ports_tx, 4]);
assertEqual(size(aod0),[n_ports_rx, n_ports_tx, 4]);
assertEqual(size(eod0),[n_ports_rx, n_ports_tx, 4]);
assertEqual(size(aoa0),[n_ports_rx, n_ports_tx, 4]);
assertEqual(size(eoa0),[n_ports_rx, n_ports_tx, 4]);
assertEqual(numel(act0), 4);
assertTrue(islogical(act0));

% Coefficients: imaginary part ~ 0 when center_freq==0 and real patterns/M
assertTrue(max(abs(ci0(:))) < 1e-12);
assertTrue(any(abs(cr0(:))>0));

% Angles finite, within expected ranges
assertTrue(all(isfinite(aod0(:)) & isfinite(eod0(:)) & isfinite(aoa0(:)) & isfinite(eoa0(:))));
assertTrue(all(aod0(:)>=-pi & aod0(:)<=pi));
assertTrue(all(aoa0(:)>=-pi & aoa0(:)<=pi));
assertTrue(all(eod0(:)>=-pi/2 & eod0(:)<=pi/2));
assertTrue(all(eoa0(:)>=-pi/2 & eoa0(:)<=pi/2));

% ---------- 2) Phase enabled when center_freq>0 ----------
f0 = 3.5e9;
[~,ci1,~,~,~,~,~,~] = quadriga_lib.get_channels_irs( ...
    ant_tx, ant_rx, ant_irs, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    i_irs, thr_keep_all, f0, use_abs, active_path_in, [] );
assertTrue(any(abs(ci1(:))>1e-8));

% ---------- 3) Absolute delays add a constant offset ----------
use_abs=true;
[~,~,D_abs,~,~,~,~,~]= quadriga_lib.get_channels_irs( ...
    ant_tx, ant_rx, ant_irs, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    i_irs, thr_keep_all, f0, use_abs, active_path_in, [] );
use_abs=false;
[~,~,D_rel,~,~,~,~,~]= quadriga_lib.get_channels_irs( ...
    ant_tx, ant_rx, ant_irs, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    i_irs, thr_keep_all, f0, use_abs, active_path_in, [] );
delta = D_abs - D_rel;
assertTrue(all(abs(delta(:)-delta(1))<1e-12));  % same offset everywhere

% ---------- 4) active_path selection overrides threshold ----------
thr_drop_all = +100; % would drop everything if used
[cr_sel,ci_sel,~,act_sel] = quadriga_lib.get_channels_irs( ...
    ant_tx, ant_rx, ant_irs, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    i_irs, thr_drop_all, f0_zero, false, some_mask, [] );
assertEqual(size(cr_sel,3), sum(some_mask));
assertEqual(size(ci_sel,3), sum(some_mask));
assertEqual(numel(act_sel), numel(some_mask));
assertTrue(islogical(act_sel));
assertEqual(sum(act_sel), sum(some_mask));
assertTrue(all(~act_sel | some_mask(:))); % used paths must be a subset of requested

% ---------- 5) i_irs index changes coefficients when IRS has multiple ports ----------
i_irs0 = 1;   % 1-based codebook port
i_irs1 = 2;
[cr_i0,~,~,~,~,~,~,~] = quadriga_lib.get_channels_irs( ...
    ant_tx, ant_rx, ant_irs, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    i_irs0, thr_keep_all, f0_zero, false, all_mask, [] );
[cr_i1,~,~,~,~,~,~,~] = quadriga_lib.get_channels_irs( ...
    ant_tx, ant_rx, ant_irs, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    i_irs1, thr_keep_all, f0_zero, false, all_mask, [] );
assertTrue(any(abs(cr_i0(:)-cr_i1(:))>1e-12));

% ---------- 6) Asymmetric IRS (ant_irs_2) changes result ----------
[cr_sym,~,~,~,~,~,~,~] = quadriga_lib.get_channels_irs( ...
    ant_tx, ant_rx, ant_irs, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    i_irs0, thr_keep_all, f0_zero, false, all_mask, [] );
[cr_asym,~,~,~,~,~,~,~] = quadriga_lib.get_channels_irs( ...
    ant_tx, ant_rx, ant_irs, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    i_irs0, thr_keep_all, f0_zero, false, all_mask, ant_irs_diff );
assertTrue(any(abs(cr_sym(:)-cr_asym(:))>1e-12));

% ---------- 7a) Threshold filtering reduces output paths ----------
% path_gain_1 = [1, 0.2], path_gain_2 = [1, 0.05] → combined gains span a wide range;
% a moderate threshold should drop the weakest combinations.
thr_mid = -10;
[cr_thr,~,~,act_thr] = quadriga_lib.get_channels_irs( ...
    ant_tx, ant_rx, ant_irs, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    i_irs, thr_mid, f0_zero, false, [], [] );
assertEqual(size(cr_thr,3), sum(act_thr));   % n_path_irs == #active
assertTrue(sum(act_thr) >= 1 && sum(act_thr) < 4);  % some kept, some dropped

% ---------- 7b) Absolute delay magnitude matches geometry ----------
% Shortest combined path delay = (min(path_length_1) + min(path_length_2)) / c,
% up to small element-position offsets.
C = 299792458.0;
[~,~,D_abs_chk] = quadriga_lib.get_channels_irs( ...
    ant_tx, ant_rx, ant_irs, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    1, thr_keep_all, f0_zero, true, [], [] );
expected_min_delay = (min(path_length_1) + min(path_length_2)) / C;
assertTrue(abs(min(D_abs_chk(:)) - expected_min_delay) < 5e-9);

% ---------- 7c) Optional fields can be omitted on antennas ----------
ant_tx2 = rmfield(ant_tx,  'element_pos');
ant_rx2 = rmfield(ant_rx,  'element_pos');
ant_irs2 = rmfield(ant_irs, 'element_pos');
[~] = quadriga_lib.get_channels_irs( ...
    ant_tx2, ant_rx2, ant_irs2, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    1, thr_keep_all, f0_zero, false, [], [] );

ant_tx2 = rmfield(ant_tx2, 'coupling_re');
ant_tx2 = rmfield(ant_tx2, 'coupling_im');
[~] = quadriga_lib.get_channels_irs( ...
    ant_tx2, ant_rx2, ant_irs2, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    1, thr_keep_all, f0_zero, false, [], [] );

% ---------- 7d) Subset of outputs (only first three) ----------
[cr_s, ci_s, D_s] = quadriga_lib.get_channels_irs( ...
    ant_tx, ant_rx, ant_irs, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
    1, thr_keep_all, f0_zero, false, [], [] );
assertEqual(size(cr_s,3), 4);
assertEqual(size(ci_s,3), 4);
assertEqual(size(D_s,3),  4);

% ---------- 8) Error: M_1 size mismatch (segment 1 path count mismatch) ----------
M_1_bad = ones(8,1); % should be 8x2
try
    [~] = quadriga_lib.get_channels_irs( ...
        ant_tx, ant_rx, ant_irs, ...
        fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1_bad, ...
        fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
        tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
        1, thr_keep_all, f0_zero, false, [], [] );
    error('moxunit:exceptionNotRaised', 'Expected an error!');
catch ME
    expectedErrorMessage = 'Inputs ''fbs_pos'', ''lbs_pos'', ''path_gain'', ''path_length'', and ''M'' must have the same number of columns (n_paths).';
    if strcmp(ME.identifier, 'moxunit:exceptionNotRaised') || isempty(strfind(ME.message, expectedErrorMessage))
        error('moxunit:exceptionNotRaised', ['EXPECTED: "', expectedErrorMessage, '", GOT: "',ME.message,'"']);
    end
end

% ---------- 9) Error: segment 2 path count mismatch ----------
fbs_pos_2_bad = [fbs_pos_2, fbs_pos_2(:,1)]; % 3 cols vs 2 elsewhere
try
    [~] = quadriga_lib.get_channels_irs( ...
        ant_tx, ant_rx, ant_irs, ...
        fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
        fbs_pos_2_bad, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
        tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
        1, thr_keep_all, f0_zero, false, [], [] );
    error('moxunit:exceptionNotRaised', 'Expected an error!');
catch ME
    expectedErrorMessage = 'Inputs ''fbs_pos'', ''lbs_pos'', ''path_gain'', ''path_length'', and ''M'' must have the same number of columns (n_paths).';
    if strcmp(ME.identifier, 'moxunit:exceptionNotRaised') || isempty(strfind(ME.message, expectedErrorMessage))
        error('moxunit:exceptionNotRaised', ['EXPECTED: "', expectedErrorMessage, '", GOT: "',ME.message,'"']);
    end
end

% ---------- 10) Error: wrong size of tx_pos ----------
try
    [~] = quadriga_lib.get_channels_irs( ...
        ant_tx, ant_rx, ant_irs, ...
        fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
        fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
        [0;0;1;1], tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
        1, thr_keep_all, f0_zero, false, [], [] );
    error('moxunit:exceptionNotRaised', 'Expected an error!');
catch ME
    expectedErrorMessage = 'Input ''tx_pos'' has incorrect number of elements.';
    if strcmp(ME.identifier, 'moxunit:exceptionNotRaised') || isempty(strfind(ME.message, expectedErrorMessage))
        error('moxunit:exceptionNotRaised', ['EXPECTED: "', expectedErrorMessage, '", GOT: "',ME.message,'"']);
    end
end

% ---------- 11) Error: wrong size of irs_pos ----------
try
    [~] = quadriga_lib.get_channels_irs( ...
        ant_tx, ant_rx, ant_irs, ...
        fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
        fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
        tx_pos, tx_ori, rx_pos, rx_ori, [10;0], irs_ori, ...
        1, thr_keep_all, f0_zero, false, [], [] );
    error('moxunit:exceptionNotRaised', 'Expected an error!');
catch ME
    expectedErrorMessage = 'Input ''irs_pos'' has incorrect number of elements.';
    if strcmp(ME.identifier, 'moxunit:exceptionNotRaised') || isempty(strfind(ME.message, expectedErrorMessage))
        error('moxunit:exceptionNotRaised', ['EXPECTED: "', expectedErrorMessage, '", GOT: "',ME.message,'"']);
    end
end

% ---------- 12) Error: wrong size of irs_orientation ----------
try
    [~] = quadriga_lib.get_channels_irs( ...
        ant_tx, ant_rx, ant_irs, ...
        fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
        fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
        tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, [0;0], ...
        1, thr_keep_all, f0_zero, false, [], [] );
    error('moxunit:exceptionNotRaised', 'Expected an error!');
catch ME
    expectedErrorMessage = 'Input ''irs_orientation'' has incorrect number of elements.';
    if strcmp(ME.identifier, 'moxunit:exceptionNotRaised') || isempty(strfind(ME.message, expectedErrorMessage))
        error('moxunit:exceptionNotRaised', ['EXPECTED: "', expectedErrorMessage, '", GOT: "',ME.message,'"']);
    end
end

% ---------- 13) Error: active_path wrong length ----------
bad_mask = true(1, 3); % should be n_path_1 * n_path_2 = 4
try
    [~] = quadriga_lib.get_channels_irs( ...
        ant_tx, ant_rx, ant_irs, ...
        fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
        fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
        tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
        1, thr_keep_all, f0_zero, false, bad_mask, [] );
    error('moxunit:exceptionNotRaised', 'Expected an error!');
catch ME
    expectedErrorMessage = 'Optional input ''active_path'' does not have the correct number of elements.';
    if strcmp(ME.identifier, 'moxunit:exceptionNotRaised') || isempty(strfind(ME.message, expectedErrorMessage))
        error('moxunit:exceptionNotRaised', ['EXPECTED: "', expectedErrorMessage, '", GOT: "',ME.message,'"']);
    end
end

% ---------- 14) Error: TX coupling_im without coupling_re ----------
ant_tx_bad = ant_tx;
ant_tx_bad = rmfield(ant_tx_bad,'coupling_re');
try
    [~] = quadriga_lib.get_channels_irs( ...
        ant_tx_bad, ant_rx, ant_irs, ...
        fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
        fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
        tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
        1, thr_keep_all, f0_zero, false, [], [] );
    error('moxunit:exceptionNotRaised', 'Expected an error!');
catch ME
    expectedErrorMessage = 'Transmit antenna: Imaginary part of coupling matrix (phase component) defined without real part (absolute component)';
    if strcmp(ME.identifier, 'moxunit:exceptionNotRaised') || isempty(strfind(ME.message, expectedErrorMessage))
        error('moxunit:exceptionNotRaised', ['EXPECTED: "', expectedErrorMessage, '", GOT: "',ME.message,'"']);
    end
end

% ---------- 15) Error: IRS coupling_im without coupling_re ----------
ant_irs_bad = ant_irs;
ant_irs_bad = rmfield(ant_irs_bad,'coupling_re');
try
    [~] = quadriga_lib.get_channels_irs( ...
        ant_tx, ant_rx, ant_irs_bad, ...
        fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
        fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
        tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, ...
        1, thr_keep_all, f0_zero, false, [], [] );
    error('moxunit:exceptionNotRaised', 'Expected an error!');
catch ME
    expectedErrorMessage = 'IRS array: Imaginary part of coupling matrix (phase component) defined without real part (absolute component)';
    if strcmp(ME.identifier, 'moxunit:exceptionNotRaised') || isempty(strfind(ME.message, expectedErrorMessage))
        error('moxunit:exceptionNotRaised', ['EXPECTED: "', expectedErrorMessage, '", GOT: "',ME.message,'"']);
    end
end


% ---------- 11) i_irs is a 1-based codebook port index, default 1 ----------
args = {ant_tx, ant_rx, ant_irs_diff, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    fbs_pos_2, lbs_pos_2, path_gain_2, path_length_2, M_2, ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori};
cr_def = quadriga_lib.get_channels_irs( args{:} );
cr_p1 = quadriga_lib.get_channels_irs( args{:}, 1 );
cr_p2 = quadriga_lib.get_channels_irs( args{:}, 2 );
cr_e = quadriga_lib.get_channels_irs( args{:}, [] );
assertEqual( cr_def, cr_p1 );
assertEqual( cr_e, cr_p1 );
assertTrue( any(abs(cr_p1(:) - cr_p2(:)) > 1e-12) );
% Port 1 uses the first coupling column only: an IRS whose first column equals port 2 of ant_irs_diff gives cr_p2
ant_sw = ant_irs_diff;
ant_sw.coupling_re = ant_irs_diff.coupling_re(:, [2 1]);
ant_sw.coupling_im = ant_irs_diff.coupling_im(:, [2 1]);
args_sw = args; args_sw{3} = ant_sw;
assertEqual( quadriga_lib.get_channels_irs( args_sw{:}, 1 ), cr_p2 );
for bad = [0, 3]
    failed = false;
    try
        [~] = quadriga_lib.get_channels_irs( args{:}, bad );
    catch ME
        failed = ~isempty(strfind(ME.message, 'i_irs')) && ~isempty(strfind(ME.message, '1 to 2'));
    end
    assertTrue( failed );
end

% ---------- 12) A segment without paths gives empty outputs [n_ports_rx, n_ports_tx, 0] ----------
o0 = cell(1, 8);
[o0{:}] = quadriga_lib.get_channels_irs( ant_tx, ant_rx, ant_irs, ...
    fbs_pos_1, lbs_pos_1, path_gain_1, path_length_1, M_1, ...
    zeros(3,0), zeros(3,0), zeros(1,0), zeros(1,0), zeros(8,0), ...
    tx_pos, tx_ori, rx_pos, rx_ori, irs_pos, irs_ori, 1 );
for k = [1:3, 5:8]
    assertEqual( [size(o0{k}, 1), size(o0{k}, 2), size(o0{k}, 3)], [n_ports_rx, n_ports_tx, 0] );
end
assertTrue( isempty(o0{4}) );

% ---------- helpers ----------
    function ant = make_ant(nel,naz,nelem,nports,scale)
        ant.e_theta_re = ones(nel,naz,nelem)*scale;
        ant.e_theta_im = zeros(nel,naz,nelem);
        ant.e_phi_re   = ones(nel,naz,nelem)*scale;
        ant.e_phi_im   = zeros(nel,naz,nelem);
        ant.azimuth_grid   = linspace(-pi,pi,naz);
        ant.elevation_grid = linspace(-pi/2,pi/2,nel);
        ant.element_pos = [linspace(0,(nelem-1)*0.5,nelem); zeros(1,nelem); zeros(1,nelem)];
        % simple coupling: element k -> port k (or scaled second port for IRS variety)
        C = zeros(nelem,nports);
        for k=1:min(nelem,nports), C(k,k)=1; end
        % Add slight port scaling so i_irs effect is observable
        if nports>=2, C(:,2)=C(:,2)*0.5*scale; end
        ant.coupling_re = C;
        ant.coupling_im = zeros(size(C));
    end
end
